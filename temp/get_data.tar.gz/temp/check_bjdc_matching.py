# -*- coding: utf-8 -*-
"""检查BJDC匹配逻辑为什么会匹配到错误的比赛"""

# TCZQ API返回的队名
tczq_matches = [
    {
        'id': 78,
        'match_id': 2039369,
        'bjdc_match_id': 1362638,
        'tczq_home': 'AIK索尔纳',
        'tczq_away': '马尔默',
        'bjdc_home': 'MP米凯利',
        'bjdc_away': '孔斯温厄尔'
    },
    {
        'id': 84,
        'match_id': 2039404,
        'bjdc_match_id': 1407201,
        'tczq_home': '巴黎圣日尔曼',
        'tczq_away': '拜仁慕尼黑',
        'bjdc_home': '埃弗顿VM',
        'bjdc_away': '哈洛贾特'
    }
]

print("=" * 80)
print("检查BJDC匹配逻辑")
print("=" * 80)

for match in tczq_matches:
    print(f"\nTCZQ ID {match['id']} (match_id={match['match_id']}, bjdc_match_id={match['bjdc_match_id']}):")
    
    # 检查主队匹配
    tczq_home = match['tczq_home']
    bjdc_home = match['bjdc_home']
    
    home_match = (
        tczq_home[:4] in bjdc_home or
        bjdc_home[:4] in tczq_home
    )
    
    print(f"  主队: TCZQ='{tczq_home}' vs BJDC='{bjdc_home}'")
    print(f"    TCZQ前4字符: '{tczq_home[:4]}'")
    print(f"    BJDC前4字符: '{bjdc_home[:4]}'")
    print(f"    '{tczq_home[:4]}' in '{bjdc_home}': {tczq_home[:4] in bjdc_home}")
    print(f"    '{bjdc_home[:4]}' in '{tczq_home}': {bjdc_home[:4] in tczq_home}")
    print(f"    主队匹配结果: {home_match}")
    
    # 检查客队匹配
    tczq_away = match['tczq_away']
    bjdc_away = match['bjdc_away']
    
    away_match = (
        tczq_away[:4] in bjdc_away or
        bjdc_away[:4] in tczq_away
    )
    
    print(f"  客队: TCZQ='{tczq_away}' vs BJDC='{bjdc_away}'")
    print(f"    TCZQ前4字符: '{tczq_away[:4]}'")
    print(f"    BJDC前4字符: '{bjdc_away[:4]}'")
    print(f"    '{tczq_away[:4]}' in '{bjdc_away}': {tczq_away[:4] in bjdc_away}")
    print(f"    '{bjdc_away[:4]}' in '{tczq_away}': {bjdc_away[:4] in tczq_away}")
    print(f"    客队匹配结果: {away_match}")
    
    print(f"  最终匹配: {'✓ 匹配成功' if home_match and away_match else '✗ 不匹配'}")
