# -*- coding: utf-8 -*-
"""
球队名称匹配优化 - 48小时效果检查脚本
运行时间：修改代码后48小时
"""
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.database import localdb, Team, TeamAlias
from datetime import datetime, timedelta

print("=" * 80)
print("球队名称匹配优化 - 48小时效果检查")
print("=" * 80)
print(f"检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print()

# 1. 统计总球队数
total_teams = localdb.query(Team).count()
print(f"[STAT] 球队总数: {total_teams}")

# 2. 统计别名总数
total_aliases = localdb.query(TeamAlias).count()
print(f"[STAT] 别名总数: {total_aliases}")

# 3. 检查最近48小时新增的球队
cutoff_time = datetime.now() - timedelta(hours=48)
new_teams = localdb.query(Team).filter(Team.created_at >= cutoff_time).all()
print(f"\n[NEW] 最近48小时新增球队: {len(new_teams)} 支")

if new_teams:
    print("\n   新增球队列表:")
    for team in new_teams[:20]:  # 只显示前20个
        print(f"   - ID={team.id}, 名称='{team.team_full_name}', 创建时间={team.created_at}")
    if len(new_teams) > 20:
        print(f"   ... 还有 {len(new_teams) - 20} 支")

# 4. 检查是否有相似名称的球队（潜在重复）
print(f"\n[CHECK] 检查潜在重复球队...")

# 查找名称相似的球队对
potential_duplicates = []
all_teams = localdb.query(Team).all()

for i, t1 in enumerate(all_teams):
    for t2 in all_teams[i+1:]:
        # 检查是否前4个字符相同且长度差异<=3
        if len(t1.team_full_name) >= 4 and len(t2.team_full_name) >= 4:
            prefix1 = t1.team_full_name[:4]
            prefix2 = t2.team_full_name[:4]
            
            if prefix1 == prefix2:
                length_diff = abs(len(t1.team_full_name) - len(t2.team_full_name))
                if length_diff <= 3 and t1.team_full_name != t2.team_full_name:
                    potential_duplicates.append((t1, t2, length_diff))

if potential_duplicates:
    print(f"\n[WARN] 发现 {len(potential_duplicates)} 对潜在重复球队:")
    for t1, t2, diff in potential_duplicates[:10]:  # 只显示前10对
        print(f"   - '{t1.team_full_name}' (ID:{t1.id}) vs '{t2.team_full_name}' (ID:{t2.id}), 长度差={diff}")
    if len(potential_duplicates) > 10:
        print(f"   ... 还有 {len(potential_duplicates) - 10} 对")
else:
    print(f"\n[OK] 未发现潜在重复球队")

# 5. 统计各数据源的别名数量
print(f"\n[STAT] 别名分布统计:")
from sqlalchemy import func
source_stats = localdb.query(
    TeamAlias.source_type,
    func.count(TeamAlias.id)
).group_by(TeamAlias.source_type).all()

for row in source_stats:
    if len(row) >= 2:
        source = row[0]
        count = row[1]
        print(f"   - {source or '未指定'}: {count} 个别名")

# 6. 检查跨数据源别名使用情况
print(f"\n[STAT] 跨数据源别名使用:")
cross_source_count = localdb.query(TeamAlias).filter(
    TeamAlias.remark.like('%跨数据源%')
).count()
print(f"   跨数据源匹配的别名: {cross_source_count} 个")

# 7. 检查包含关系匹配的别名
containment_count = localdb.query(TeamAlias).filter(
    TeamAlias.remark.like('%包含关系匹配%')
).count()
print(f"   包含关系匹配的别名: {containment_count} 个")

print("\n" + "=" * 80)
print("检查完成")
print("=" * 80)

localdb.close()
