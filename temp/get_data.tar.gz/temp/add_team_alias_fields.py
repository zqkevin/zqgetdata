# -*- coding: utf-8 -*-
"""
为team表添加alias1和alias2字段
"""
import sys
sys.path.insert(0, 'E:\\my_prog\\zqgetdata')

from app.database import localdb
from sqlalchemy import text

def add_team_alias_fields():
    """添加alias1和alias2字段到team表"""
    
    print("=" * 80)
    print("为 team 表添加 alias1 和 alias2 字段")
    print("=" * 80)
    
    try:
        with localdb.engine.connect() as conn:
            # 检查alias1字段是否已存在
            result = conn.execute(text("""
                SELECT COUNT(*) as count 
                FROM information_schema.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = 'team' 
                AND COLUMN_NAME = 'alias1'
            """))
            
            row = result.fetchone()
            if row and row[0] > 0:
                print("✅ alias1 字段已存在")
            else:
                # 添加alias1字段
                conn.execute(text("""
                    ALTER TABLE team 
                    ADD COLUMN alias1 VARCHAR(100) NULL COMMENT '别名1（用于匹配不同来源的队名）'
                """))
                print("✅ 成功添加 alias1 字段")
            
            # 检查alias2字段是否已存在
            result = conn.execute(text("""
                SELECT COUNT(*) as count 
                FROM information_schema.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = 'team' 
                AND COLUMN_NAME = 'alias2'
            """))
            
            row = result.fetchone()
            if row and row[0] > 0:
                print("✅ alias2 字段已存在")
            else:
                # 添加alias2字段
                conn.execute(text("""
                    ALTER TABLE team 
                    ADD COLUMN alias2 VARCHAR(100) NULL COMMENT '别名2（用于匹配不同来源的队名）'
                """))
                print("✅ 成功添加 alias2 字段")
            
            conn.commit()
        
        print("\n完成！")
        return True
        
    except Exception as e:
        print(f"❌ 添加字段失败: {e}")
        import traceback
        traceback.print_exc()
        localdb.rollback()
        return False
    finally:
        localdb.close()

if __name__ == '__main__':
    success = add_team_alias_fields()
    if not success:
        sys.exit(1)
