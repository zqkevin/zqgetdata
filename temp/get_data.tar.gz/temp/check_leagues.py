# -*- coding: utf-8 -*-
"""检查爬取结果中的联赛分布"""
import json
from collections import Counter

with open('temp/bjdc_crawled_results.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 统计联赛分布
leagues = Counter([m.get('leagueName', '未知') for m in data])

print("=" * 100)
print("爬取结果中的联赛分布（前30个）")
print("=" * 100)

for league, count in leagues.most_common(30):
    print(f"{league}: {count} 场")

print(f"\n总计: {len(data)} 场比赛")
print(f"唯一联赛数: {len(leagues)}")
