# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.crawler.tczq_result import TczqResultCollector
from app.database import localdb, TczqMatch

collector = TczqResultCollector()
results, pending_matches = collector.fetch_match_results()

print(f"Pending matches: {len(pending_matches)}")
print(f"API results: {len(results)}")

# Build matchId index
api_results_by_id = {}
for result_data in results:
    match_id = result_data.get('matchId')
    if match_id:
        api_results_by_id[str(match_id)] = result_data

print(f"\nAPI matchId index: {len(api_results_by_id)} entries")
print(f"Sample matchIds: {list(api_results_by_id.keys())[:5]}")

# Check target matches
target_ids = [78, 84]
for match in pending_matches:
    if match.id in target_ids:
        match_id_str = str(match.match_id)
        print(f"\nMatch ID {match.id}:")
        print(f"  DB match_id: {match.match_id} (str: {match_id_str})")
        print(f"  In API index: {match_id_str in api_results_by_id}")
        
        if match_id_str in api_results_by_id:
            api_result = api_results_by_id[match_id_str]
            print(f"  API homeTeam: {api_result.get('allHomeTeam')}")
            print(f"  API awayTeam: {api_result.get('allAwayTeam')}")
            print(f"  API score: {api_result.get('homeScore')}-{api_result.get('awayScore')}")
            
            # Check if home_name is defined
            home_name = match.home_team.team_full_name if match.home_team else ''
            away_name = match.away_team.team_full_name if match.away_team else ''
            print(f"  DB home_name: '{home_name}'")
            print(f"  DB away_name: '{away_name}'")
            print(f"  home_name defined: {bool(home_name)}")
            print(f"  away_name defined: {bool(away_name)}")

localdb.close()
