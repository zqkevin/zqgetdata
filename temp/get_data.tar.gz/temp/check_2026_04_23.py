# -*- coding: utf-8 -*-
"""
检查2026-04-23的赛果页面
"""
import sys
sys.path.insert(0, 'E:\\my_prog\\zqgetdata')

from app.common._utils import req_info
from app.crawler.bjdc_result import BjdcResultCollector

def check_2026_04_23():
    """检查2026-04-23的赛果"""
    
    print("=" * 100)
    print("检查2026-04-23的赛果页面")
    print("=" * 100)
    
    date_str = '2026-04-23'
    url = f'https://live.500.com/wanchang.php?e={date_str}'
    
    print(f"\n爬取URL: {url}")
    soup = req_info(url)
    
    if not soup:
        print("爬取失败！")
        return
    
    collector = BjdcResultCollector()
    results = collector._parse_match_results_from_html(soup, date_str)
    
    print(f"\n总共爬取到 {len(results)} 场比赛\n")
    
    # 查找包含"福冈黄蜂"的比赛
    print("查找包含'福冈黄蜂'或'大阪'的比赛：")
    print("-" * 100)
    
    for result in results:
        if '福冈黄蜂' in result.get('awayTeam', '') or '福冈黄蜂' in result.get('homeTeam', '') or \
           '大阪' in result.get('homeTeam', '') or '大阪' in result.get('awayTeam', ''):
            print(f"Match ID: {result['matchId']}")
            print(f"联赛: {result['leagueName']}")
            print(f"主队: {result['homeTeam']}")
            print(f"客队: {result['awayTeam']}")
            print(f"比分: {result['homeScore']}-{result['awayScore']}")
            print(f"时间: {result['matchTime']}")
            print(f"状态: {result['status']}")
            print("-" * 100)
    
    # 特别查找1366368
    print("\n查找Match ID 1366368：")
    print("-" * 100)
    
    found = False
    for result in results:
        if str(result['matchId']) == '1366368':
            found = True
            print(f"✓ 找到！")
            print(f"Match ID: {result['matchId']}")
            print(f"联赛: {result['leagueName']}")
            print(f"主队: {result['homeTeam']}")
            print(f"客队: {result['awayTeam']}")
            print(f"比分: {result['homeScore']}-{result['awayScore']}")
            print(f"时间: {result['matchTime']}")
            print(f"状态: {result['status']}")
            break
    
    if not found:
        print("✗ 未找到Match ID 1366368")
        
        # 显示前10条记录供参考
        print(f"\n前10条记录：")
        for i, result in enumerate(results[:10], 1):
            print(f"{i}. Match ID: {result['matchId']}, {result['homeTeam']} vs {result['awayTeam']}")

if __name__ == '__main__':
    check_2026_04_23()
