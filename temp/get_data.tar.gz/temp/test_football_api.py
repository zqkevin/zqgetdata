"""
测试 football-data.org API
探索可用的数据和免费账户限制
"""
import requests
import json
from datetime import datetime

# API配置
API_TOKEN = "b95b11f44dde401bb5f8de79364f59c6"
BASE_URL = "https://api.football-data.org/v4"
HEADERS = {
    "X-Auth-Token": API_TOKEN
}

def test_api_endpoint(endpoint, description):
    """测试API端点并打印结果"""
    print(f"\n{'='*60}")
    print(f"测试: {description}")
    print(f"端点: {endpoint}")
    print('='*60)
    
    try:
        response = requests.get(f"{BASE_URL}/{endpoint}", headers=HEADERS)
        
        # 检查速率限制头信息
        rate_limit = response.headers.get('X-Requests-Available-Minute', 'N/A')
        rate_remaining = response.headers.get('X-Requests-Remaining-Minute', 'N/A')
        print(f"速率限制 - 每分钟可用: {rate_limit}, 剩余: {rate_remaining}")
        
        if response.status_code == 200:
            data = response.json()
            
            # 打印基本信息
            if isinstance(data, dict):
                print(f"返回类型: dict")
                print(f"键: {list(data.keys())}")
                
                # 如果是列表类型的数据
                if 'competitions' in data:
                    print(f"\n竞赛数量: {len(data['competitions'])}")
                    if data['competitions']:
                        print("示例竞赛:")
                        for comp in data['competitions'][:3]:
                            print(f"  - {comp.get('name')} ({comp.get('code')}) - {comp.get('area', {}).get('name')}")
                
                elif 'teams' in data:
                    print(f"\n球队数量: {len(data['teams'])}")
                    if data['teams']:
                        print("示例球队:")
                        for team in data['teams'][:3]:
                            print(f"  - {team.get('name')} - {team.get('shortName')} - {team.get('country', 'N/A')}")
                
                elif 'matches' in data:
                    print(f"\n比赛数量: {len(data['matches'])}")
                
                elif 'standings' in data:
                    print(f"\n积分榜存在")
                    
            elif isinstance(data, list):
                print(f"返回类型: list, 长度: {len(data)}")
                if data:
                    print(f"第一项: {json.dumps(data[0], indent=2, ensure_ascii=False)[:500]}")
            
            return data
        else:
            print(f"错误: HTTP {response.status_code}")
            print(f"响应: {response.text[:500]}")
            return None
            
    except Exception as e:
        print(f"异常: {str(e)}")
        return None

def main():
    print("开始测试 football-data.org API")
    print(f"时间: {datetime.now()}")
    
    # 1. 测试获取所有竞赛
    test_api_endpoint("competitions", "获取所有可用竞赛")
    
    # 2. 测试获取特定竞赛（英超）
    test_api_endpoint("competitions/PL", "获取英超联赛信息")
    
    # 3. 测试获取竞赛的球队列表
    test_api_endpoint("competitions/PL/teams", "获取英超所有球队")
    
    # 4. 测试获取特定球队信息
    test_api_endpoint("teams/64", "获取利物浦球队信息")
    
    # 5. 测试获取今日比赛
    test_api_endpoint("matches", "获取今日比赛")
    
    # 6. 测试获取区域列表
    test_api_endpoint("areas", "获取所有区域/国家")
    
    # 7. 测试获取特定区域的竞赛
    test_api_endpoint("areas/2072/competitions", "获取英格兰的竞赛")
    
    print("\n" + "="*60)
    print("测试完成！")
    print("="*60)

if __name__ == "__main__":
    main()
