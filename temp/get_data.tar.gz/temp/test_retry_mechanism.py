# -*- coding: utf-8 -*-
"""
测试优化后的重试机制（5-10秒随机等待）
"""
import sys
import os
import time

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.common._utils import req_info

def test_retry_mechanism():
    """测试重试机制的等待时间"""
    
    print("=" * 70)
    print("测试优化后的重试机制（5-10秒随机等待）")
    print("=" * 70)
    
    # 测试一个可能失败的URL来触发重试
    test_url = "https://trade.500.com/bjdc/project_fq_bq.php"
    qishu = "26048"
    
    print(f"\n测试URL: {test_url}?e={qishu}")
    print("-" * 70)
    print("说明：如果网络正常，应该一次成功；如果网络波动，会看到重试等待日志")
    print()
    
    start_time = time.time()
    
    try:
        result = req_info(test_url, qishu)
        elapsed_time = time.time() - start_time
        
        if result:
            print(f"\n✓ 成功获取页面")
            print(f"  耗时: {elapsed_time:.2f} 秒")
            print(f"  页面标题: {result.title.text if result.title else 'N/A'}")
            print(f"  内容长度: {len(str(result))} 字符")
        else:
            print(f"\n✗ 获取页面失败")
            print(f"  耗时: {elapsed_time:.2f} 秒")
            
    except Exception as e:
        elapsed_time = time.time() - start_time
        print(f"\n✗ 异常: {type(e).__name__}: {str(e)}")
        print(f"  耗时: {elapsed_time:.2f} 秒")
    
    print("\n" + "=" * 70)
    print("测试完成")
    print("=" * 70)
    print("\n预期行为：")
    print("  1. 如果首次请求成功：立即返回，无等待")
    print("  2. 如果首次请求失败：等待5-10秒后重试（最多3次）")
    print("  3. 每次重试都会显示等待时间日志")
    print("=" * 70)

if __name__ == '__main__':
    test_retry_mechanism()
