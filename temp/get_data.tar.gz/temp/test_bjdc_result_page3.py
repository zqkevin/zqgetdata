# -*- coding: utf-8 -*-
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.common._utils import req_info

# 获取页面
soup = req_info('https://live.500.com/wanchang.php?e=2026-04-14')

if not soup:
    print("Failed to fetch page")
    sys.exit(1)

# 保存 HTML 到文件
html_path = os.path.join(project_root, 'temp', 'bjdc_result_page.html')
with open(html_path, 'w', encoding='utf-8') as f:
    f.write(str(soup))

print(f"HTML 已保存到: {html_path}")
print(f"文件大小: {os.path.getsize(html_path)} bytes")

# 查找所有包含比赛信息的标签
print("\n查找包含球队名称的元素...")

# 搜索包含常见球队名的文本
team_names = ['朴茨茅斯', '利物浦', '曼联', '切尔西']
for team in team_names:
    elements = soup.find_all(string=lambda text: text and team in text)
    if elements:
        print(f"\n找到 '{team}':")
        for elem in elements[:3]:
            parent = elem.parent
            print(f"  父标签: {parent.name}, class={parent.get('class')}")
            # 打印周围的内容
            siblings = list(parent.find_next_siblings(limit=3))
            for sib in siblings:
                if hasattr(sib, 'get_text'):
                    print(f"    - {sib.get_text(strip=True)[:100]}")
