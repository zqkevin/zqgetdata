# -*- coding: utf-8 -*-
"""
检查芬兰杯比赛是否能匹配
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.crawler.bjdc_result import BjdcResultCollector
from app.database import localdb, BjdcMatch, League

print("=" * 80)
print("检查芬兰杯比赛匹配")
print("=" * 80)

c = BjdcResultCollector()

# 获取数据
results, pending_matches = c.fetch_match_results()

# 找到芬兰杯的待匹配比赛
finland_matches = []
for match in pending_matches:
    if match.league_id:
        league = localdb.query(League).filter_by(id=match.league_id).first()
        if league and '芬兰杯' in league.league_name:
            finland_matches.append(match)

print(f"\n找到 {len(finland_matches)} 场芬兰杯待匹配比赛:")
for i, match in enumerate(finland_matches, 1):
    home_name = match.home_team.team_full_name if match.home_team else '未知'
    away_name = match.away_team.team_full_name if match.away_team else '未知'
    match_date = match.match_time.strftime('%Y-%m-%d') if match.match_time else '未知'
    print(f"  {i}. {match_date} | {home_name} vs {away_name}")

# 在爬取的赛果中查找芬兰杯
finland_results = [r for r in results if '芬兰杯' in r.get('leagueName', '')]
print(f"\n爬取到 {len(finland_results)} 场芬兰杯赛果:")
for i, r in enumerate(finland_results[:10], 1):
    print(f"  {i}. {r['matchDate']} | {r['homeTeam']} vs {r['awayTeam']}: {r['homeScore']}-{r['awayScore']}")

# 尝试匹配
if finland_matches and finland_results:
    print(f"\n尝试匹配第一场芬兰杯比赛...")
    first_match = finland_matches[0]
    db_home = first_match.home_team.team_full_name if first_match.home_team else ''
    db_away = first_match.away_team.team_full_name if first_match.away_team else ''
    db_date = first_match.match_time.strftime('%Y-%m-%d') if first_match.match_time else ''
    
    print(f"数据库: {db_date} | {db_home} vs {db_away}")
    
    for r in finland_results:
        if r['matchDate'] == db_date:
            api_home = r['homeTeam']
            api_away = r['awayTeam']
            
            home_similar = c._is_team_name_similar(db_home, api_home)
            away_similar = c._is_team_name_similar(db_away, api_away)
            
            match_str = "MATCH!" if (home_similar and away_similar) else ""
            print(f"  {api_home} vs {api_away} - H:{home_similar}, A:{away_similar} {match_str}")

print("\n" + "=" * 80)
