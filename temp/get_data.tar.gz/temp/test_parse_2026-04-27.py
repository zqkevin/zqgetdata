"""
测试爬取 2026-04-27 页面的解析结果
"""
from app.crawler.bjdc_result import BjdcResultCollector
from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-27'
print(f"爬取: {url}")

soup = req_info(url)

if not soup:
    print("❌ 爬取失败")
    exit(1)

print(f"✓ 爬取成功")

# 检查是否有 span.mainName 和 span.clientName
home_names = soup.find_all('span', class_='mainName')
away_names = soup.find_all('span', class_='clientName')

print(f"\n主队名称数量: {len(home_names)}")
print(f"客队名称数量: {len(away_names)}")

if len(home_names) > 0:
    print(f"\n前3个主队:")
    for i, span in enumerate(home_names[:3]):
        print(f"  {i+1}. {span.get_text(strip=True)}")

collector = BjdcResultCollector()
results = collector._parse_match_results_from_html(soup, '2026-04-27')

print(f"\n解析结果: {len(results)} 场比赛")

if len(results) > 0:
    print(f"\n前3场比赛:")
    for i, result in enumerate(results[:3]):
        print(f"  {i+1}. matchId={result['matchId']}: {result['homeTeam']} vs {result['awayTeam']} ({result['matchTime']})")
