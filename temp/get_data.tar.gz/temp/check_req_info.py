"""
检查 req_info 返回的HTML中是否有 a1358307
"""
from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-27'
soup = req_info(url)

# 查找 id="a1358307" 的 tr
tr = soup.find('tr', id='a1358307')

if tr:
    print("✓ 找到 tr#a1358307")
    gy = tr.get('gy', '')
    print(f"  gy: {gy}")
else:
    print("❌ 未找到 tr#a1358307")
    
    # 统计所有 tr 的数量
    all_tr = soup.find_all('tr')
    tr_with_id = soup.find_all('tr', id=True)
    tr_starting_with_a = soup.find_all('tr', id=lambda x: x and x.startswith('a'))
    
    print(f"\n总 tr 数量: {len(all_tr)}")
    print(f"带 id 的 tr 数量: {len(tr_with_id)}")
    print(f"id以'a'开头的 tr 数量: {len(tr_starting_with_a)}")
    
    if len(tr_starting_with_a) > 0:
        print(f"\n前5个 tr id:")
        for tr in tr_starting_with_a[:5]:
            print(f"  {tr.get('id')}")
