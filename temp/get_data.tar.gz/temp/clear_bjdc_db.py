# -*- coding: utf-8 -*-
"""清空BJDC相关的所有数据表"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb
from app.database.bjdc_models import (
    BjdcMatch,
    BjdcSpfOdds,
    BjdcTotalGoalOdds,
    BjdcScoreOdds,
    BjdcHalfTimeFullTimeOdds,
    BjdcUpDownOdds,
    BjdcOddsChangeLog
)
from app.database.base_models import Team, TeamAlias, League

print('开始清空BJDC相关数据...\n')

try:
    # 按依赖关系顺序删除（先删除子表，再删除主表）
    
    # 1. 删除赔率变化日志
    count = localdb.query(BjdcOddsChangeLog).delete()
    print(f'✓ 删除赔率变化日志: {count} 条')
    
    # 2. 删除各种赔率表
    count = localdb.query(BjdcSpfOdds).delete()
    print(f'✓ 删除胜负平赔率: {count} 条')
    
    count = localdb.query(BjdcTotalGoalOdds).delete()
    print(f'✓ 删除总进球赔率: {count} 条')
    
    count = localdb.query(BjdcScoreOdds).delete()
    print(f'✓ 删除比分赔率: {count} 条')
    
    count = localdb.query(BjdcHalfTimeFullTimeOdds).delete()
    print(f'✓ 删除半全场赔率: {count} 条')
    
    count = localdb.query(BjdcUpDownOdds).delete()
    print(f'✓ 删除上下单双赔率: {count} 条')
    
    # 3. 删除比赛记录
    count = localdb.query(BjdcMatch).delete()
    print(f'✓ 删除比赛记录: {count} 条')
    
    # 4. 删除球队别名
    count = localdb.query(TeamAlias).delete()
    print(f'✓ 删除球队别名: {count} 条')
    
    # 5. 删除球队
    count = localdb.query(Team).delete()
    print(f'✓ 删除球队: {count} 条')
    
    # 6. 删除联赛
    count = localdb.query(League).delete()
    print(f'✓ 删除联赛: {count} 条')
    
    # 提交事务
    localdb.session.commit()
    print('\n✅ 数据库清空完成！')
    
except Exception as e:
    localdb.session.rollback()
    print(f'\n❌ 清空失败: {e}')
    import traceback
    traceback.print_exc()
finally:
    localdb.close()
