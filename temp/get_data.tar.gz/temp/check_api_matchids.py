# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.crawler.tczq_result import TczqResultCollector

collector = TczqResultCollector()
results, pending_matches = collector.fetch_match_results()

print(f"API返回 {len(results)} 条赛果")
print("\n所有match_id:")
match_ids = [str(r.get('matchId')) for r in results if r.get('matchId')]
print(', '.join(sorted(match_ids)))

print(f"\n目标match_id是否在API中:")
print(f"  2039369: {'是' if '2039369' in match_ids else '否'}")
print(f"  2039404: {'是' if '2039404' in match_ids else '否'}")
