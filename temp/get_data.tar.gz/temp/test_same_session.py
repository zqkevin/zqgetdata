"""
使用同一个 Session 请求两个页面
"""
import requests
from app.common._utils import generate_random_cookies

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                  'AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/80.0.3987.149 Safari/537.36'
}

# 创建同一个 session
session = requests.Session()
cookies = generate_random_cookies('500')

# 先请求 04-26
url_26 = 'https://live.500.com/wanchang.php?e=2026-04-26'
response_26 = session.get(url=url_26, headers=headers, cookies=cookies, timeout=15)
print(f"04-26: {len(response_26.text)} 字符")

# 再请求 04-27（使用同一个 session）
url_27 = 'https://live.500.com/wanchang.php?e=2026-04-27'
response_27 = session.get(url=url_27, headers=headers, cookies=cookies, timeout=15)
print(f"04-27: {len(response_27.text)} 字符")

# 检查是否包含 a1358307
if 'a1358307' in response_27.text:
    print("✓ 04-27 包含 a1358307")
else:
    print("❌ 04-27 不包含 a1358307")
    
# 检查响应中是否有 JavaScript 加载的内容提示
if 'document.write' in response_27.text or 'ajax' in response_27.text.lower():
    print("\n⚠️ 页面可能使用了 JavaScript 动态加载")
