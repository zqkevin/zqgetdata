# -*- coding: utf-8 -*-
"""
手动检查7场异常比赛的赛果
"""
import sys
import os
from datetime import datetime

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.append(project_root)

from app.crawler.bjdc_result import BjdcResultCollector
from app.crawler.tczq_result import TczqResultCollector
from app.database import localdb, BjdcMatch, TczqMatch

def check_tczq_matches():
    """检查TCZQ比赛"""
    print("=" * 80)
    print("检查TCZQ（体彩足球）比赛")
    print("=" * 80)
    
    collector = TczqResultCollector()
    
    # 检查match_id 78和84
    match_ids = [78, 84]
    
    for match_id in match_ids:
        match = localdb.query(TczqMatch).filter(TczqMatch.id == match_id).first()
        if not match:
            print(f"\n❌ 未找到ID为{match_id}的比赛")
            continue
        
        home_team = match.home_team.team_full_name if match.home_team else "未知"
        away_team = match.away_team.team_full_name if match.away_team else "未知"
        
        print(f"\n📋 比赛信息:")
        print(f"  ID: {match.id}")
        print(f"  场次号: {match.match_num}")
        print(f"  比赛时间: {match.match_time}")
        print(f"  对阵: {home_team} vs {away_team}")
        print(f"  当前状态: {match.status}")
        print(f"  已过时间: {(datetime.now() - match.match_time).total_seconds() / 3600:.1f} 小时")
        
        # 尝试从API获取赛果
        try:
            match_date = match.match_time.strftime('%Y-%m-%d')
            print(f"\n🔍 从API获取 {match_date} 的赛果...")
            results = collector.api.get_football_match_result(
                match_begin_date=match_date,
                match_end_date=match_date
            )
            
            if results:
                print(f"  ✅ API返回了 {len(results)} 条赛果")
                # 查找匹配的比赛
                for result in results:
                    api_home = result.get('allHomeTeam', '')
                    api_away = result.get('allAwayTeam', '')
                    if home_team in api_home or api_home in home_team:
                        if away_team in api_away or api_away in away_team:
                            print(f"\n  🎯 找到匹配的赛果:")
                            print(f"    主队: {api_home}")
                            print(f"    客队: {api_away}")
                            print(f"    比分: {result.get('homeTeamGoals')} - {result.get('awayTeamGoals')}")
                            print(f"    半场: {result.get('halfTimeHomeGoals')} - {result.get('halfTimeAwayGoals')}")
                            print(f"    原始状态: {result.get('matchResultStatus')}")
                            break
            else:
                print(f"  ❌ API未返回任何赛果")
        except Exception as e:
            print(f"  ❌ 获取赛果失败: {e}")

def check_bjdc_matches():
    """检查BJDC比赛"""
    print("\n" + "=" * 80)
    print("检查BJDC（北京单场）比赛")
    print("=" * 80)
    
    collector = BjdcResultCollector()
    
    # 检查id 400, 401, 402, 403, 432
    match_ids = [400, 401, 402, 403, 432]
    
    for match_id in match_ids:
        match = localdb.query(BjdcMatch).filter(BjdcMatch.id == match_id).first()
        if not match:
            print(f"\n❌ 未找到ID为{match_id}的比赛")
            continue
        
        home_team = match.home_team.team_full_name if match.home_team else "未知"
        away_team = match.away_team.team_full_name if match.away_team else "未知"
        
        print(f"\n📋 比赛信息:")
        print(f"  ID: {match.id}")
        print(f"  场次号: {match.match_num}")
        print(f"  期数: {match.issue}")
        print(f"  比赛时间: {match.match_time}")
        print(f"  对阵: {home_team} vs {away_team}")
        print(f"  当前状态: {match.status}")
        print(f"  已过时间: {(datetime.now() - match.match_time).total_seconds() / 3600:.1f} 小时")
        
        # 尝试从网页爬取赛果
        try:
            match_date = match.match_time.strftime('%Y-%m-%d')
            print(f"\n🔍 从500.com爬取 {match_date} 的赛果...")
            
            # 使用现有的爬取逻辑
            from bs4 import BeautifulSoup
            from app.common._utils import req_info
            
            url = f"https://trade.500.com/jczq/?date={match_date.replace('-', '')}"
            response = req_info(url)
            
            if response:
                soup = BeautifulSoup(response, 'html.parser')
                results = collector._parse_match_results_from_html(soup, match_date)
                
                if results:
                    print(f"  ✅ 爬取到 {len(results)} 条赛果")
                    # 查找匹配的比赛
                    for result in results:
                        api_home = result.get('homeTeam', '')
                        api_away = result.get('awayTeam', '')
                        if home_team in api_home or api_home in home_team:
                            if away_team in api_away or api_away in away_team:
                                print(f"\n  🎯 找到匹配的赛果:")
                                print(f"    主队: {api_home}")
                                print(f"    客队: {api_away}")
                                print(f"    比分: {result.get('homeScore')} - {result.get('awayScore')}")
                                print(f"    半场: {result.get('halfHomeScore')} - {result.get('halfAwayScore')}")
                                print(f"    状态: {result.get('status')}")
                                break
                else:
                    print(f"  ❌ 未爬取到任何赛果")
            else:
                print(f"  ❌ 网页请求失败")
        except Exception as e:
            print(f"  ❌ 获取赛果失败: {e}")
            import traceback
            traceback.print_exc()

if __name__ == '__main__':
    print("开始检查7场异常比赛...\n")
    
    check_tczq_matches()
    check_bjdc_matches()
    
    print("\n" + "=" * 80)
    print("检查完成")
    print("=" * 80)
