# -*- coding: utf-8 -*-
"""查看需要获取赛果的BJDC比赛信息"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, BjdcMatch
from datetime import datetime, timedelta

now = datetime.now()
cutoff_time = now - timedelta(hours=4)

matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.status == 0,
    BjdcMatch.match_time < cutoff_time
).all()

print(f'需要获取赛果的比赛: {len(matches)} 场\n')
print('=' * 100)

for i, m in enumerate(matches):
    home_name = m.home_team.team_full_name if m.home_team else '未知'
    away_name = m.away_team.team_full_name if m.away_team else '未知'
    page_date = (m.match_time - timedelta(hours=10)).strftime('%Y-%m-%d') if m.match_time else ''
    
    print(f'\n比赛 {i+1}:')
    print(f'  Match ID: {m.match_id}')
    print(f'  联赛ID: {m.league_id}')
    print(f'  主队: {home_name} (ID: {m.home_team_id})')
    print(f'  客队: {away_name} (ID: {m.away_team_id})')
    print(f'  比赛时间: {m.match_time}')
    print(f'  期数: {m.issue}')
    print(f'  场次: {m.match_num_str}')
    print(f'  页面日期(减10h): {page_date}')
    print(f'  500.com URL: https://live.500.com/wanchang.php?e={page_date}')
    print('-' * 100)
