# -*- coding: utf-8 -*-
"""
测试TCZQ状态码修复 - 检查超过24小时但状态为0的比赛
"""
import sys
import os
from datetime import datetime, timedelta

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(project_root))

from app.database import localdb, TczqMatch, Team

def check_abnormal_matches():
    """检查异常比赛"""
    print("=" * 80)
    print("检查TCZQ超过24小时但状态为0的比赛")
    print("=" * 80)
    
    # 计算24小时前的时间
    cutoff_time = datetime.now() - timedelta(hours=24)
    
    # 查询超过24小时但状态还是0的比赛
    abnormal_matches = localdb.query(TczqMatch).filter(
        TczqMatch.match_time < cutoff_time,
        TczqMatch.status == 0
    ).all()
    
    print(f"\n找到 {len(abnormal_matches)} 场异常比赛:\n")
    
    for match in abnormal_matches:
        home_team = match.home_team.team_full_name if match.home_team else "未知"
        away_team = match.away_team.team_full_name if match.away_team else "未知"
        hours_passed = (datetime.now() - match.match_time).total_seconds() / 3600
        
        print(f"📋 ID={match.id}, 场次号={match.match_num}")
        print(f"   对阵: {home_team} vs {away_team}")
        print(f"   比赛时间: {match.match_time}")
        print(f"   已过时间: {hours_passed:.1f} 小时")
        print(f"   当前状态: {match.status} (应该是2或8)")
        print(f"   是否有赛果: {'是' if match.result else '否'}")
        print()
    
    print("=" * 80)
    print("分析结论:")
    print("=" * 80)
    print("这些比赛已经超过24小时，应该已经结束")
    print("但状态仍然是0（待开赛），说明状态更新逻辑有问题")
    print()
    print("✅ 已修复 tczq_result.py:")
    print("   第76行: TczqMatch.status < 2 → TczqMatch.status < 3")
    print("   第185行: TczqMatch.status < 2 → TczqMatch.status < 3")
    print()
    print("修复后，状态2（已结束）的比赛也会被纳入赛果获取范围")
    print("=" * 80)

if __name__ == '__main__':
    check_abnormal_matches()
