"""
检查 BJDC 比赛状态分布
"""
from app.database import BjdcMatch, localdb
from datetime import datetime, timedelta

# 查询所有 BJDC 比赛
all_matches = localdb.query(BjdcMatch).all()

print(f"总比赛数: {len(all_matches)}\n")

# 按状态分组统计
status_count = {}
for match in all_matches:
    status = match.status
    if status not in status_count:
        status_count[status] = []
    status_count[status].append(match)

# 显示各状态的统计
status_desc = {
    0: '未开始',
    1: '进行中',
    2: '已结束（未获取赛果）',
    3: '延期',
    4: '取消',
    5: '中断',
    8: '已完成（已获取赛果）'
}

for status in sorted(status_count.keys()):
    matches = status_count[status]
    desc = status_desc.get(status, '未知')
    
    # 找出时间范围
    times = [m.match_time for m in matches if m.match_time]
    if times:
        time_range = f"{min(times)} ~ {max(times)}"
    else:
        time_range = '无时间信息'
    
    print(f"状态 {status} ({desc}): {len(matches)} 场")
    print(f"  时间范围: {time_range}")
    
    # 显示前3场比赛
    if len(matches) > 0:
        print(f"  示例比赛:")
        for match in matches[:3]:
            home = match.home_team.team_full_name if match.home_team else '未知'
            away = match.away_team.team_full_name if match.away_team else '未知'
            print(f"    - {home} vs {away} ({match.match_time})")
        if len(matches) > 3:
            print(f"    ... 还有 {len(matches) - 3} 场")
    print()
