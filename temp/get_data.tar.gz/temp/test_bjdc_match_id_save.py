# -*- coding: utf-8 -*-
"""
测试bjdc_match_id字段的保存
"""
import sys
sys.path.insert(0, 'E:\\my_prog\\zqgetdata')

from app.database import localdb, TczqMatch

# 查询一场比赛
match = localdb.query(TczqMatch).filter_by(match_id=2039240).first()

if match:
    print(f"更新前: match_id={match.match_id}, bjdc_match_id={match.bjdc_match_id}")
    
    # 设置bjdc_match_id
    match.bjdc_match_id = 1373121
    localdb.update(match, close=False)
    
    print(f"更新后(未commit): match_id={match.match_id}, bjdc_match_id={match.bjdc_match_id}")
    
    # 重新查询
    match2 = localdb.query(TczqMatch).filter_by(match_id=2039240).first()
    print(f"重新查询: match_id={match2.match_id}, bjdc_match_id={match2.bjdc_match_id}")
    
    localdb.close()
else:
    print("未找到比赛")
