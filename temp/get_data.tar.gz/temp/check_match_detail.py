"""
查看 match_id=1358307 的完整信息
"""
from app.database import BjdcMatch, League, Team, localdb

match = localdb.query(BjdcMatch).filter_by(match_id=1358307).first()

if not match:
    print("未找到比赛")
    exit(1)

# 获取联赛信息
league = localdb.query(League).filter_by(id=match.league_id).first()
league_name = league.league_name if league else '未知'

# 获取球队信息
home_team = localdb.query(Team).filter_by(id=match.home_team_id).first()
away_team = localdb.query(Team).filter_by(id=match.away_team_id).first()

home_name = home_team.team_full_name if home_team else '未知'
away_name = away_team.team_full_name if away_team else '未知'

print("="*60)
print("比赛详细信息:")
print("="*60)
print(f"match_id: {match.match_id}")
print(f"联赛: {league_name}")
print(f"主队: {home_name}")
print(f"客队: {away_name}")
print(f"比赛时间: {match.match_time}")
print(f"星期: {match.match_week}")
print(f"期数: {match.issue}")
print(f"场次: {match.match_num_str}")
print(f"状态: {match.status}")
print("="*60)

localdb.close()
