# -*- coding: utf-8 -*-
"""
添加bjdc_match_id字段到tczq_match表
"""
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.database import localdb
from sqlalchemy import text

def add_bjdc_match_id_column():
    """添加bjdc_match_id字段"""
    
    print("=" * 80)
    print("添加 bjdc_match_id 字段到 tczq_match 表")
    print("=" * 80)
    
    try:
        # 检查字段是否已存在
        with localdb.engine.connect() as conn:
            result = conn.execute(text("""
                SELECT COUNT(*) as count 
                FROM information_schema.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = 'tczq_match' 
                AND COLUMN_NAME = 'bjdc_match_id'
            """))
            
            row = result.fetchone()
            if row and row[0] > 0:
                print("✅ bjdc_match_id 字段已存在")
                return True
            
            # 添加字段
            conn.execute(text("""
                ALTER TABLE tczq_match 
                ADD COLUMN bjdc_match_id INT NULL COMMENT '匹配到的BJDC比赛ID（避免重复匹配）'
            """))
            
            # 添加索引
            conn.execute(text("""
                ALTER TABLE tczq_match 
                ADD INDEX idx_bjdc_match_id (bjdc_match_id)
            """))
            
            conn.commit()
        
        print("✅ 成功添加 bjdc_match_id 字段")
        print("✅ 成功创建索引 idx_bjdc_match_id")
        
        return True
        
    except Exception as e:
        print(f"❌ 添加字段失败: {e}")
        import traceback
        traceback.print_exc()
        localdb.rollback()
        return False
    finally:
        localdb.close()

if __name__ == '__main__':
    success = add_bjdc_match_id_column()
    if success:
        print("\n完成！")
    else:
        print("\n失败！")
        sys.exit(1)
