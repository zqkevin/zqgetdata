# -*- coding: utf-8 -*-
"""
检查TCZQ API返回的赛果数据结构
"""
import sys
import os

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.common.req_sporttery_api import SportteryAPI
from datetime import datetime, timedelta

def check_tczq_result_data():
    """检查TCZQ API返回的赛果数据"""
    api = SportteryAPI()
    
    # 获取昨天的日期范围
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    today = datetime.now().strftime('%Y-%m-%d')
    
    print(f"查询日期范围: {yesterday} 到 {today}")
    print("=" * 80)
    
    # 调用API获取赛果
    results = api.get_football_match_result(
        match_begin_date=yesterday,
        match_end_date=today
    )
    
    if not results:
        print("API未返回任何数据")
        return
    
    print(f"API返回 {len(results)} 条赛果\n")
    
    # 检查前5条数据的结构
    for i, result in enumerate(results[:5]):
        print(f"\n--- 第 {i+1} 条比赛 ---")
        print(f"  比赛: {result.get('homeTeam')} vs {result.get('awayTeam')}")
        print(f"  matchId: {result.get('matchId')}")
        print(f"  matchDate: {result.get('matchDate')}")
        print(f"  matchResultStatus: {result.get('matchResultStatus')} (类型: {type(result.get('matchResultStatus')).__name__})")
        print(f"  homeScore: {result.get('homeScore')} (类型: {type(result.get('homeScore')).__name__})")
        print(f"  awayScore: {result.get('awayScore')} (类型: {type(result.get('awayScore')).__name__})")
        
        # 检查是否有取消标识
        home_score = result.get('homeScore')
        away_score = result.get('awayScore')
        
        if home_score == '取消' or away_score == '取消' or home_score == 'N/A':
            print(f"  ⚠️  会被判断为'比赛取消'")
        else:
            print(f"  ✓ 正常比赛")
    
    # 统计所有比赛的状态分布
    print("\n" + "=" * 80)
    print("状态分布统计:")
    status_count = {}
    score_none_count = 0
    score_na_count = 0
    score_cancel_count = 0
    
    for result in results:
        status = result.get('matchResultStatus', '未知')
        status_count[status] = status_count.get(status, 0) + 1
        
        home_score = result.get('homeScore')
        away_score = result.get('awayScore')
        
        if home_score is None or away_score is None:
            score_none_count += 1
        elif home_score == 'N/A' or away_score == 'N/A':
            score_na_count += 1
        elif home_score == '取消' or away_score == '取消':
            score_cancel_count += 1
    
    for status, count in sorted(status_count.items()):
        print(f"  matchResultStatus='{status}': {count} 场")
    
    print(f"\n比分异常情况:")
    print(f"  比分为None: {score_none_count} 场")
    print(f"  比分为'N/A': {score_na_count} 场")
    print(f"  比分为'取消': {score_cancel_count} 场")

if __name__ == '__main__':
    check_tczq_result_data()
