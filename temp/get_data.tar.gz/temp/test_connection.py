# -*- coding: utf-8 -*-
"""测试网络连接"""
import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry

url = "https://trade.500.com/bjdc/project_fq_bq.php?e=26048"

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                  'AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/80.0.3987.149 Safari/537.36'
}

print(f"正在测试连接: {url}")
print("-" * 60)

try:
    session = requests.Session()
    retry = Retry(total=3, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    
    response = session.get(url=url, headers=headers, timeout=10)
    print(f"状态码: {response.status_code}")
    print(f"响应长度: {len(response.text)}")
    print(f"编码: {response.encoding}")
    print("✓ 连接成功!")
    
except requests.exceptions.ConnectionError as e:
    print(f"✗ 连接错误: {e}")
except requests.exceptions.Timeout as e:
    print(f"✗ 超时错误: {e}")
except Exception as e:
    print(f"✗ 其他错误: {type(e).__name__}: {e}")
