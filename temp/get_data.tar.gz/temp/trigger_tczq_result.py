# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.crawler.tczq_result import TczqResultCollector
from app.database import localdb, TczqMatch

print("=" * 80)
print("手动触发TCZQ赛果获取")
print("=" * 80)

# 检查目标比赛状态
target_ids = [78, 84]
matches = localdb.query(TczqMatch).filter(TczqMatch.id.in_(target_ids)).all()

print("\n目标比赛当前状态:")
for m in matches:
    home = m.home_team.team_full_name if m.home_team else '未知'
    away = m.away_team.team_full_name if m.away_team else '未知'
    print(f"  ID {m.id}: match_id={m.match_id}, status={m.status}, {home} vs {away}")

# 触发赛果获取
collector = TczqResultCollector()
results, pending_matches = collector.fetch_match_results()

print(f"\nAPI返回赛果数: {len(results)}")
print(f"待匹配比赛数: {len(pending_matches)}")

if pending_matches:
    print("\n开始保存赛果...")
    saved = collector.save_results_to_db(results, pending_matches)
    print(f"成功保存: {saved} 场")

# 检查最终状态
print("\n最终状态:")
matches = localdb.query(TczqMatch).filter(TczqMatch.id.in_(target_ids)).all()
for m in matches:
    home = m.home_team.team_full_name if m.home_team else '未知'
    away = m.away_team.team_full_name if m.away_team else '未知'
    
    # 检查是否有赛果
    from app.database import TczqMatchResult
    result = localdb.query(TczqMatchResult).filter_by(match_id=m.match_id).first()
    
    if result:
        print(f"  ID {m.id}: status={m.status}, {home} vs {away}, 比分: {result.home_team_goals}-{result.away_team_goals} ✓")
    else:
        print(f"  ID {m.id}: status={m.status}, {home} vs {away}, 无赛果 ✗")

localdb.close()
