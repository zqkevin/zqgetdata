# -*- coding: utf-8 -*-
"""
检查500.com网页上是否有BJDC比赛
"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from bs4 import BeautifulSoup
from app.common._utils import req_info

def check_500com_page(date_str):
    """检查指定日期的500.com页面"""
    print(f"\n{'='*80}")
    print(f"检查 500.com {date_str} 的完场页面")
    print(f"{'='*80}")
    
    url = f'https://live.500.com/wanchang.php?e={date_str}'
    print(f"URL: {url}\n")
    
    try:
        soup = req_info(url)
        
        if not soup:
            print("[FAIL] 网页请求失败")
            return
        
        # 查找所有tr标签，id以'a'开头的
        tr_list = soup.find_all('tr', id=lambda x: x and x.startswith('a'))
        print(f"找到 {len(tr_list)} 个比赛记录\n")
        
        # 检查是否有我们要找的比赛
        target_matches = [
            ('圣吉罗斯联合', '哈德斯菲尔德'),
            ('布鲁日', '比尔森胜利'),
            ('普埃布拉', '帕尔杜比采'),
            ('瓦路尔', '莱比锡红牛'),
        ]
        
        found_count = 0
        for tr in tr_list[:20]:  # 只检查前20个
            gy = tr.get('gy', '')
            tr_id = tr.get('id', '')
            
            if gy:
                parts = gy.split(',')
                if len(parts) >= 3:
                    league = parts[0]
                    home = parts[1]
                    away = parts[2]
                    
                    # 检查是否是目标比赛
                    for target_home, target_away in target_matches:
                        if target_home in home or home in target_home:
                            if target_away in away or away in target_away:
                                print(f"[FOUND] match_id={tr_id.replace('a', '')}")
                                print(f"  联赛: {league}")
                                print(f"  主队: {home}")
                                print(f"  客队: {away}")
                                found_count += 1
                                break
        
        if found_count == 0:
            print("[INFO] 前20个比赛中没有找到目标比赛")
            print("\n前5个比赛的gy属性:")
            for tr in tr_list[:5]:
                gy = tr.get('gy', '')
                tr_id = tr.get('id', '')
                if gy:
                    print(f"  {tr_id}: {gy}")
        
    except Exception as e:
        print(f"[ERROR] 检查失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    # 检查2026-04-28和2026-04-29的页面
    check_500com_page('2026-04-28')
    check_500com_page('2026-04-29')
