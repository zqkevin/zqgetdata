# -*- coding: utf-8 -*-
from datetime import datetime, timedelta

times = [
    ('墨尔本胜利', datetime(2026, 4, 17, 17, 25)),
    ('加拉茨钢铁', datetime(2026, 4, 17, 22, 20)),
    ('吉达国民', datetime(2026, 4, 17, 22, 35))
]

print('验证页面日期计算逻辑:')
print('=' * 80)

for name, t in times:
    if t.hour >= 10:
        page_date = (t.date() + timedelta(days=1)).strftime('%Y-%m-%d')
    else:
        page_date = t.date().strftime('%Y-%m-%d')
    
    print(f'{name}: {t} -> 页面日期: {page_date}')

print('\n预期结果: 都应该是 2026-04-18')
