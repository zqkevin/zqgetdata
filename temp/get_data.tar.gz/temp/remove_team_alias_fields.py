# -*- coding: utf-8 -*-
"""
删除team表中误添加的alias1和alias2字段
"""
import sys
sys.path.insert(0, 'E:\\my_prog\\zqgetdata')

from app.database import localdb
from sqlalchemy import text

def remove_team_alias_fields():
    """删除team表中的alias1和alias2字段"""
    
    print("=" * 80)
    print("删除 team 表中的 alias1 和 alias2 字段")
    print("=" * 80)
    
    try:
        with localdb.engine.connect() as conn:
            # 检查并删除alias1字段
            result = conn.execute(text("""
                SELECT COUNT(*) as count 
                FROM information_schema.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = 'team' 
                AND COLUMN_NAME = 'alias1'
            """))
            
            row = result.fetchone()
            if row and row[0] > 0:
                conn.execute(text("ALTER TABLE team DROP COLUMN alias1"))
                print("✅ 成功删除 alias1 字段")
            else:
                print("ℹ️  alias1 字段不存在，跳过")
            
            # 检查并删除alias2字段
            result = conn.execute(text("""
                SELECT COUNT(*) as count 
                FROM information_schema.COLUMNS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = 'team' 
                AND COLUMN_NAME = 'alias2'
            """))
            
            row = result.fetchone()
            if row and row[0] > 0:
                conn.execute(text("ALTER TABLE team DROP COLUMN alias2"))
                print("✅ 成功删除 alias2 字段")
            else:
                print("ℹ️  alias2 字段不存在，跳过")
            
            conn.commit()
        
        print("\n完成！")
        return True
        
    except Exception as e:
        print(f"❌ 删除字段失败: {e}")
        import traceback
        traceback.print_exc()
        localdb.rollback()
        return False
    finally:
        localdb.close()

if __name__ == '__main__':
    success = remove_team_alias_fields()
    if not success:
        sys.exit(1)
