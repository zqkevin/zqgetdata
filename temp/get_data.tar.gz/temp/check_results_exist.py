# -*- coding: utf-8 -*-
"""
检查爬取的赛果中是否包含待匹配的比赛
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.crawler.bjdc_result import BjdcResultCollector
from app.database import localdb, League

c = BjdcResultCollector()
results, pending_matches = c.fetch_match_results()

print("=" * 80)
print("检查爬取的赛果中是否包含待匹配比赛")
print("=" * 80)

# 构建赛果字典（按日期分组）
results_by_date = {}
for r in results:
    date_str = r['matchDate']
    if date_str not in results_by_date:
        results_by_date[date_str] = []
    results_by_date[date_str].append(r)

print(f"\n爬取到 {len(results)} 条赛果，分布在 {len(results_by_date)} 个日期")

# 检查每个待匹配比赛
print(f"\n检查 {len(pending_matches)} 场待匹配比赛:")
for i, match in enumerate(pending_matches[:5], 1):  # 只检查前5场
    home_name = match.home_team.team_full_name if match.home_team else '未知'
    away_name = match.away_team.team_full_name if match.away_team else '未知'
    match_date = match.match_time.strftime('%Y-%m-%d') if match.match_time else '未知'
    league_id = match.league_id
    league = localdb.query(League).filter_by(id=league_id).first() if league_id else None
    league_name = league.league_name if league else f'ID:{league_id}'
    
    print(f"\n{i}. [{league_name}] {match_date} | {home_name} vs {away_name}")
    
    # 在该日期的赛果中查找
    if match_date in results_by_date:
        day_results = results_by_date[match_date]
        print(f"   该日期有 {len(day_results)} 条赛果")
        
        # 查找是否有相同的队名
        found = False
        for r in day_results:
            api_home = r['homeTeam']
            api_away = r['awayTeam']
            
            if home_name == api_home and away_name == api_away:
                print(f"   ✅ 找到: {api_home} vs {api_away}: {r['homeScore']}-{r['awayScore']}")
                found = True
                break
        
        if not found:
            print(f"   ❌ 未找到精确匹配")
            # 显示该日期的前5场比赛
            print(f"   该日期前5场赛果:")
            for j, r in enumerate(day_results[:5], 1):
                print(f"      {j}. {r['homeTeam']} vs {r['awayTeam']} ({r['leagueName']})")
    else:
        print(f"   ❌ 该日期没有赛果数据")

print("\n" + "=" * 80)
