# -*- coding: utf-8 -*-
"""检查 BJDC 比赛时间的时区问题"""
import sys
import os
from datetime import timedelta

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from app.database import localdb, BjdcMatch
from sqlalchemy import func
from datetime import datetime

# 查询最早和最晚的比赛
cutoff_time = datetime.now() - timedelta(hours=4)

earliest = localdb.query(BjdcMatch).filter(
    BjdcMatch.match_time < cutoff_time,
    BjdcMatch.status < 3
).order_by(BjdcMatch.match_time.asc()).first()

latest = localdb.query(BjdcMatch).filter(
    BjdcMatch.match_time < cutoff_time,
    BjdcMatch.status < 3
).order_by(BjdcMatch.match_time.desc()).first()

print("=" * 80)
print("BJDC 比赛时间检查")
print("=" * 80)

for match in [earliest, latest]:
    if match:
        print(f"\nMatch ID: {match.match_id}")
        print(f"对阵: {match.home_team.team_full_name if match.home_team else 'N/A'} vs {match.away_team.team_full_name if match.away_team else 'N/A'}")
        print(f"match_time (原始): {match.match_time}")
        print(f"match_time 类型: {type(match.match_time)}")
        print(f"match_time.hour: {match.match_time.hour}")
        print(f"match_time.date(): {match.match_time.date()}")
        
        # 计算页面日期（修正后）
        utc_time = match.match_time - timedelta(hours=8)
        if utc_time.hour < 10:
            page_date = utc_time.date() - timedelta(days=1)  # 使用 UTC 时间的日期
            print(f"→ UTC时间: {utc_time}")
            print(f"→ 页面日期: {page_date} (因为 UTC hour={utc_time.hour} < 10)")
        else:
            page_date = utc_time.date()  # 使用 UTC 时间的日期
            print(f"→ UTC时间: {utc_time}")
            print(f"→ 页面日期: {page_date} (因为 UTC hour={utc_time.hour} >= 10)")

print("\n" + "=" * 80)
print("所有待获取比赛的页面日期分布:")
print("=" * 80)

matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.match_time < cutoff_time,
    BjdcMatch.status < 3
).all()

page_dates = {}
for m in matches:
    if m.match_time:
        # 修正后的逻辑：先转回 UTC
        utc_time = m.match_time - timedelta(hours=8)
        if utc_time.hour < 10:
            pd = utc_time.date() - timedelta(days=1)  # 使用 UTC 时间的日期
        else:
            pd = utc_time.date()  # 使用 UTC 时间的日期
        
        date_str = str(pd)
        if date_str not in page_dates:
            page_dates[date_str] = []
        page_dates[date_str].append(m.match_id)

for date_str in sorted(page_dates.keys()):
    print(f"{date_str}: {len(page_dates[date_str])} 场比赛")
