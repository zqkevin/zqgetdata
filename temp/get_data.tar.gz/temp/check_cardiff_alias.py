# -*- coding: utf-8 -*-
"""
检查"卡迪夫城"的别名
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, Team, TeamAlias

# 查找卡迪夫城
team = localdb.query(Team).filter(
    (Team.team_full_name.like('%卡迪夫%')) | 
    (Team.team_full_name.like('%加的夫%'))
).first()

if team:
    print(f"找到球队: {team.team_full_name}")
    print(f"简称: {team.team_short_name}")
    print(f"英文简称: {team.team_short_en_name}")
    
    # 查询别名
    aliases = localdb.query(TeamAlias).filter_by(team_id=team.id).all()
    if aliases:
        print(f"\n别名列表:")
        for alias in aliases:
            print(f"  - {alias.alias_name} (来源: {alias.source_type})")
    else:
        print("\n没有别名记录")
else:
    print("未找到相关球队")
