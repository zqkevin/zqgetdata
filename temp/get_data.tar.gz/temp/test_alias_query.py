# -*- coding: utf-8 -*-
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, Team, TeamAlias

# 测试别名查询
api_name = '朴次茅斯'  # API 返回的队名
bjdc_name = '朴茨茅斯'  # BJDC 数据库中的队名

print(f"测试: API='{api_name}' -> BJDC='{bjdc_name}'")
print()

# 1. 查找 API 队名对应的球队
api_team = localdb.query(Team).filter(
    (Team.team_full_name == api_name) | 
    (Team.team_short_name == api_name)
).first()

print(f"1. 直接查找 API 队名 '{api_name}':")
print(f"   结果: {api_team.team_full_name if api_team else '未找到'}")
print()

# 2. 查找 BJDC 队名的别名
alias = localdb.query(TeamAlias).filter(
    TeamAlias.alias_name == bjdc_name
).first()

print(f"2. 查找别名 '{bjdc_name}':")
if alias:
    print(f"   找到别名，team_id={alias.team_id}")
    team = localdb.query(Team).filter_by(id=alias.team_id).first()
    if team:
        print(f"   对应球队: {team.team_full_name} (ID:{team.id})")
else:
    print(f"   未找到别名")
print()

# 3. 列出所有相关别名
print(f"3. team_id=464 的所有别名:")
aliases = localdb.query(TeamAlias).filter_by(team_id=464).all()
for a in aliases:
    print(f"   - {a.alias_name} (source: {a.source_type})")
