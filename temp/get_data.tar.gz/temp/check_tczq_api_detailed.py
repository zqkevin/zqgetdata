# -*- coding: utf-8 -*-
"""
详细检查TCZQ API返回的赛果数据 - 用于人工校验
"""
import sys
import os
import json

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.common.req_sporttery_api import SportteryAPI
from datetime import datetime, timedelta

def check_tczq_result_data_detailed():
    """详细检查TCZQ API返回的赛果数据"""
    api = SportteryAPI()
    
    # 获取昨天的日期范围
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    today = datetime.now().strftime('%Y-%m-%d')
    
    print("=" * 100)
    print(f"TCZQ API 赛果数据详细检查")
    print(f"查询日期范围: {yesterday} 到 {today}")
    print(f"查询时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 100)
    
    # 调用API获取赛果
    results = api.get_football_match_result(
        match_begin_date=yesterday,
        match_end_date=today
    )
    
    if not results:
        print("\n❌ API未返回任何数据")
        return
    
    print(f"\n✅ API返回 {len(results)} 条赛果\n")
    
    # 按状态分组
    status_groups = {}
    for result in results:
        status = result.get('matchResultStatus', '未知')
        if status not in status_groups:
            status_groups[status] = []
        status_groups[status].append(result)
    
    # 打印每个状态的详细信息
    for status in sorted(status_groups.keys()):
        matches = status_groups[status]
        print("\n" + "=" * 100)
        print(f"📊 matchResultStatus = '{status}' 的比赛（共 {len(matches)} 场）")
        print("=" * 100)
        
        for i, result in enumerate(matches[:10], 1):  # 只显示前10场
            print(f"\n--- 第 {i} 场 ---")
            print(f"  比赛ID: {result.get('matchId')}")
            print(f"  比赛编号: {result.get('matchNum')}")
            print(f"  比赛日期: {result.get('matchDate')}")
            print(f"  比赛时间: {result.get('matchTime')}")
            print(f"  主队: {result.get('homeTeam')} / {result.get('allHomeTeam')}")
            print(f"  客队: {result.get('awayTeam')} / {result.get('allAwayTeam')}")
            print(f"  联赛: {result.get('leagueName')}")
            print(f"  ⭐ matchResultStatus: '{result.get('matchResultStatus')}' (类型: {type(result.get('matchResultStatus')).__name__})")
            print(f"  ⭐ homeScore: {repr(result.get('homeScore'))} (类型: {type(result.get('homeScore')).__name__})")
            print(f"  ⭐ awayScore: {repr(result.get('awayScore'))} (类型: {type(result.get('awayScore')).__name__})")
            
            # 显示其他可能的状态字段
            print(f"  其他状态字段:")
            print(f"    - resultStatus: {repr(result.get('resultStatus'))}")
            print(f"    - poolStatus: {repr(result.get('poolStatus'))}")
            print(f"    - matchStatus: {repr(result.get('matchStatus'))}")
            
            # 判断当前逻辑会如何处理
            home_score = result.get('homeScore')
            away_score = result.get('awayScore')
            match_result_status = result.get('matchResultStatus', '')
            
            print(f"\n  🔍 当前代码判断逻辑:")
            if match_result_status == '1':
                print(f"     → 跳过（比赛未结束）")
            elif match_result_status == '2':
                print(f"     → 正常处理（比赛已完成）")
            elif match_result_status == '3':
                print(f"     → 标记为异常")
            else:
                print(f"     → 未知状态，按已完成处理")
            
            # 显示旧的错误逻辑会如何判断
            print(f"\n  ⚠️  旧逻辑（已修复前）会判断为:")
            if home_score == '取消' or away_score == '取消' or home_score == 'N/A':
                print(f"     → ❌ 比赛取消（错误！）")
            else:
                print(f"     → ✓ 正常比赛")
        
        if len(matches) > 10:
            print(f"\n  ... 还有 {len(matches) - 10} 场比赛未显示")
    
    # 统计总结
    print("\n" + "=" * 100)
    print("📈 统计总结")
    print("=" * 100)
    
    for status in sorted(status_groups.keys()):
        matches = status_groups[status]
        sample = matches[0]
        home_score = sample.get('homeScore')
        away_score = sample.get('awayScore')
        
        print(f"\nmatchResultStatus='{status}': {len(matches)} 场")
        print(f"  示例比分: homeScore={repr(home_score)}, awayScore={repr(away_score)}")
        
        # 统计该状态下比分的分布
        score_patterns = {}
        for m in matches:
            hs = m.get('homeScore')
            as_ = m.get('awayScore')
            pattern = f"home={repr(hs)}, away={repr(as_)}"
            score_patterns[pattern] = score_patterns.get(pattern, 0) + 1
        
        print(f"  比分模式分布:")
        for pattern, count in sorted(score_patterns.items(), key=lambda x: -x[1]):
            print(f"    - {pattern}: {count} 场")
    
    # 保存完整数据到文件供进一步分析
    output_file = os.path.join(project_root, 'temp', 'tczq_api_raw_data.json')
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 完整原始数据已保存到: {output_file}")
    print("=" * 100)

if __name__ == '__main__':
    check_tczq_result_data_detailed()
