# -*- coding: utf-8 -*-
"""检查爬取结果中是否有西雅图的比赛"""
import json

with open('temp/bjdc_crawled_results.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

seattle_matches = [m for m in data if '西雅图' in m.get('homeTeam', '') or '西雅图' in m.get('awayTeam', '')]

print(f"找到 {len(seattle_matches)} 场包含'西雅图'的比赛")
for m in seattle_matches[:5]:
    print(f"  Match ID: {m['matchId']}, {m['homeTeam']} vs {m['awayTeam']}, Time: {m.get('matchTime')}")
