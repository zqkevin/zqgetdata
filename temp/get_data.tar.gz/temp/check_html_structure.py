"""
检查 04-27 页面的 HTML 结构
"""
from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-27'
soup = req_info(url)

if not soup:
    print("爬取失败")
    exit(1)

# 查找 script 标签
scripts = soup.find_all('script')
print(f"Script 标签数量: {len(scripts)}")

# 查找是否有 AJAX 或动态加载的提示
html_str = str(soup)

# 检查常见的动态加载模式
patterns = [
    'ajax',
    'fetch',
    'XMLHttpRequest',
    'document.write',
    'innerHTML',
    'loadData',
    'getMatchData'
]

print("\n检查动态加载模式:")
for pattern in patterns:
    if pattern.lower() in html_str.lower():
        count = html_str.lower().count(pattern.lower())
        print(f"  ✓ 找到 '{pattern}' ({count} 次)")

# 检查页面中是否有数据容器
data_containers = soup.find_all('div', id=lambda x: x and ('data' in x.lower() or 'match' in x.lower() or 'list' in x.lower()))
print(f"\n可能的数据容器: {len(data_containers)} 个")
for container in data_containers[:5]:
    print(f"  - {container.get('id')}")

# 检查 tbody 标签（比赛数据通常在表格中）
tbodies = soup.find_all('tbody')
print(f"\ntbody 标签数量: {len(tbodies)}")
