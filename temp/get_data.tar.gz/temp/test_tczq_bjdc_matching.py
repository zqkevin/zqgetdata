# -*- coding: utf-8 -*-
"""
测试TCZQ与BJDC比赛匹配逻辑（修复后）
"""
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.crawler.tczq import TczqDataCollector
from app.database import localdb, BjdcMatch, Team

def test_matching():
    """测试匹配逻辑"""
    print("=" * 80)
    print("测试TCZQ与BJDC比赛匹配逻辑（修复后）")
    print("=" * 80)
    
    collector = TczqDataCollector()
    
    # 测试用例1：ID 78的比赛（应该是 AIK索尔纳 vs 马尔默）
    print("\n【测试1】TCZQ ID 78 (match_id=2039369)")
    print("-" * 80)
    
    # 获取这场比赛的信息
    from app.database import TczqMatch
    tczq_match = localdb.query(TczqMatch).filter_by(id=78).first()
    
    if tczq_match:
        home_team = localdb.query(Team).filter_by(id=tczq_match.home_team_id).first()
        away_team = localdb.query(Team).filter_by(id=tczq_match.away_team_id).first()
        
        print(f"TCZQ比赛信息:")
        print(f"  match_id: {tczq_match.match_id}")
        print(f"  league_id: {tczq_match.league_id}")
        print(f"  match_time: {tczq_match.match_time}")
        print(f"  主队: {home_team.team_full_name if home_team else '未知'} (ID={tczq_match.home_team_id})")
        print(f"  客队: {away_team.team_full_name if away_team else '未知'} (ID={tczq_match.away_team_id})")
        print(f"  bjdc_match_id: {tczq_match.bjdc_match_id}")
        
        # 测试匹配函数
        print(f"\n调用 _find_match_by_league_and_time...")
        matched = collector._find_match_by_league_and_time(
            league_id=tczq_match.league_id,
            match_date=tczq_match.match_date,
            match_time=tczq_match.match_time.strftime('%H:%M:%S'),
            home_team_name='AIK索尔纳',
            away_team_name='马尔默',
            source_type='tczq'
        )
        
        if matched:
            bjdc_home = localdb.query(Team).filter_by(id=matched.home_team_id).first()
            bjdc_away = localdb.query(Team).filter_by(id=matched.away_team_id).first()
            print(f"✓ 匹配成功!")
            print(f"  BJDC match_id: {matched.match_id}")
            print(f"  BJDC match_time: {matched.match_time}")
            print(f"  主队: {bjdc_home.team_full_name if bjdc_home else '未知'}")
            print(f"  客队: {bjdc_away.team_full_name if bjdc_away else '未知'}")
            
            # 检查是否正确
            expected_bjdc_id = 1362638
            if matched.match_id == expected_bjdc_id:
                print(f"  [WARN] 仍然匹配到错误的BJDC比赛 (ID={expected_bjdc_id})")
            else:
                print(f"  [OK] 匹配结果已改善")
        else:
            print(f"  [FAIL] 未匹配到任何BJDC比赛（这是预期的，因为队名不匹配）")
    
    # 测试用例2：ID 84的比赛
    print(f"\n【测试2】TCZQ ID 84 (match_id=2039404)")
    print("-" * 80)
    
    tczq_match2 = localdb.query(TczqMatch).filter_by(id=84).first()
    
    if tczq_match2:
        home_team2 = localdb.query(Team).filter_by(id=tczq_match2.home_team_id).first()
        away_team2 = localdb.query(Team).filter_by(id=tczq_match2.away_team_id).first()
        
        print(f"TCZQ比赛信息:")
        print(f"  match_id: {tczq_match2.match_id}")
        print(f"  league_id: {tczq_match2.league_id}")
        print(f"  match_time: {tczq_match2.match_time}")
        print(f"  主队: {home_team2.team_full_name if home_team2 else '未知'} (ID={tczq_match2.home_team_id})")
        print(f"  客队: {away_team2.team_full_name if away_team2 else '未知'} (ID={tczq_match2.away_team_id})")
        print(f"  bjdc_match_id: {tczq_match2.bjdc_match_id}")
        
        # 测试匹配函数
        print(f"\n调用 _find_match_by_league_and_time...")
        matched2 = collector._find_match_by_league_and_time(
            league_id=tczq_match2.league_id,
            match_date=tczq_match2.match_date,
            match_time=tczq_match2.match_time.strftime('%H:%M:%S'),
            home_team_name='巴黎圣日尔曼',
            away_team_name='拜仁慕尼黑',
            source_type='tczq'
        )
        
        if matched2:
            bjdc_home2 = localdb.query(Team).filter_by(id=matched2.home_team_id).first()
            bjdc_away2 = localdb.query(Team).filter_by(id=matched2.away_team_id).first()
            print(f"✓ 匹配成功!")
            print(f"  BJDC match_id: {matched2.match_id}")
            print(f"  BJDC match_time: {matched2.match_time}")
            print(f"  主队: {bjdc_home2.team_full_name if bjdc_home2 else '未知'}")
            print(f"  客队: {bjdc_away2.team_full_name if bjdc_away2 else '未知'}")
            
            # 检查是否正确
            expected_bjdc_id2 = 1407201
            if matched2.match_id == expected_bjdc_id2:
                print(f"  [WARN] 仍然匹配到错误的BJDC比赛 (ID={expected_bjdc_id2})")
            else:
                print(f"  [OK] 匹配结果已改善")
        else:
            print(f"  [FAIL] 未匹配到任何BJDC比赛（这是预期的，因为队名不匹配）")
    
    localdb.close()
    print(f"\n{'='*80}")
    print("测试完成")
    print("=" * 80)

if __name__ == '__main__':
    test_matching()
