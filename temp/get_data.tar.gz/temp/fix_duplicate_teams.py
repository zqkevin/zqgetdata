# -*- coding: utf-8 -*-
"""
修复 BJDC 和 TCZQ 球队重复问题
为 API 球队添加 BJDC 队名作为别名
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, Team, TeamAlias

def fix_duplicate_teams():
    """修复重复的球队记录"""
    
    # 需要修复的球队对：(API队名, BJDC队名)
    team_pairs = [
        ("朴次茅斯", "朴茨茅斯"),
        ("南安普敦", "南安普顿"),
        ("巴黎圣日尔曼", "巴黎圣日耳曼"),
        ("葡萄牙体育", "里斯本竞技"),
        ("利勒斯特罗姆", "利勒斯特伦"),
    ]
    
    print("=" * 80)
    print("修复 BJDC/TCZQ 球队重复问题")
    print("=" * 80)
    
    for api_name, bjdc_name in team_pairs:
        print(f"\n处理: {api_name} <-> {bjdc_name}")
        
        # 查找两个球队
        api_team = localdb.query(Team).filter(
            (Team.team_full_name == api_name) | 
            (Team.team_short_name == api_name)
        ).first()
        
        bjdc_team = localdb.query(Team).filter(
            (Team.team_full_name == bjdc_name) | 
            (Team.team_short_name == bjdc_name)
        ).first()
        
        if not api_team:
            print(f"  [SKIP] 未找到 API 球队: {api_name}")
            continue
        
        if not bjdc_team:
            print(f"  [SKIP] 未找到 BJDC 球队: {bjdc_name}")
            continue
        
        print(f"  API 球队: {api_team.team_full_name} (ID:{api_team.id})")
        print(f"  BJDC 球队: {bjdc_team.team_full_name} (ID:{bjdc_team.id})")
        
        if api_team.id == bjdc_team.id:
            print(f"  [OK] 已是同一球队")
            continue
        
        # 检查是否已存在别名
        existing_alias = localdb.query(TeamAlias).filter(
            TeamAlias.team_id == api_team.id,
            TeamAlias.alias_name == bjdc_name
        ).first()
        
        if existing_alias:
            print(f"  [EXIST] 别名已存在")
            continue
        
        # 为 API 球队添加 BJDC 队名作为别名
        try:
            new_alias = TeamAlias(
                team_id=api_team.id,
                alias_name=bjdc_name,
                source_type='bjdc',
                remark='Fixed duplicate team issue'
            )
            localdb.add(new_alias)
            print(f"  [ADD] 添加别名: {bjdc_name} -> {api_team.team_full_name} (ID:{api_team.id})")
        except Exception as e:
            print(f"  [ERROR] 添加失败: {e}")
            localdb.rollback()
    
    print("\n" + "=" * 80)
    print("修复完成")
    print("=" * 80)

if __name__ == '__main__':
    try:
        fix_duplicate_teams()
    except Exception as e:
        print(f"\n[ERROR] 执行失败: {e}")
        import traceback
        traceback.print_exc()
