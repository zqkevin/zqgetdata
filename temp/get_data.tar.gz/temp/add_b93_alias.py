# -*- coding: utf-8 -*-
"""添加B93哥本哈根的别名映射"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, Team, TeamAlias

# 查找B 93球队
team = localdb.query(Team).filter_by(team_full_name='B 93').first()

if not team:
    print('❌ 未找到球队: B 93')
    sys.exit(1)

print(f'找到球队: ID={team.id}, 全称={team.team_full_name}')

# 检查是否已存在该别名
existing_alias = localdb.query(TeamAlias).filter_by(
    team_id=team.id,
    alias_name='B93哥本哈根',
    source_type='bjdc_result'
).first()

if existing_alias:
    print('✓ 别名已存在: B93哥本哈根 -> B 93')
else:
    # 创建新别名
    new_alias = TeamAlias(
        team_id=team.id,
        alias_name='B93哥本哈根',
        source_type='bjdc_result',
        is_primary=0,
        remark='完场页面队名'
    )
    localdb.add(new_alias, close=False)
    localdb.session.commit()
    print('✅ 添加别名: B93哥本哈根 -> B 93')
