# -*- coding: utf-8 -*-
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, BjdcMatch
from datetime import datetime, timedelta

matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.status == 0,
    BjdcMatch.match_time < datetime.now() - timedelta(hours=4)
).all()

print('待匹配比赛的队名:\n')
for m in matches[:10]:
    home = m.home_team.team_full_name if m.home_team else '未知'
    away = m.away_team.team_full_name if m.away_team else '未知'
    print(f'Match ID {m.match_id}: {home} vs {away}')
