# -*- coding: utf-8 -*-
"""
使用本地代码检查为什么那7场比赛没有赛果
"""
import sys
import os
from datetime import datetime, timedelta

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.crawler.tczq_result import TczqResultCollector
from app.database import localdb, TczqMatch

def check_tczq_matches():
    """检查TCZQ比赛为什么没有赛果"""
    print("=" * 80)
    print("检查TCZQ比赛为什么没有赛果")
    print("=" * 80)
    
    collector = TczqResultCollector()
    
    # 检查ID 78和84
    match_ids = [78, 84]
    
    for match_id in match_ids:
        match = localdb.query(TczqMatch).filter(TczqMatch.id == match_id).first()
        if not match:
            print(f"\n❌ 未找到ID为{match_id}的比赛")
            continue
        
        home_team = match.home_team.team_full_name if match.home_team else "未知"
        away_team = match.away_team.team_full_name if match.away_team else "未知"
        
        print(f"\n📋 比赛信息:")
        print(f"  ID: {match.id}")
        print(f"  场次号: {match.match_num}")
        print(f"  API match_id: {match.match_id}")
        print(f"  比赛时间: {match.match_time}")
        print(f"  对阵: {home_team} vs {away_team}")
        print(f"  当前状态: {match.status}")
        print(f"  已过时间: {(datetime.now() - match.match_time).total_seconds() / 3600:.1f} 小时")
        
        # 检查是否满足赛果获取条件
        cutoff_time = datetime.now() - timedelta(hours=4)
        print(f"\n🔍 赛果获取条件检查:")
        print(f"  比赛时间 < cutoff_time (4小时前): {match.match_time < cutoff_time} ✅" if match.match_time < cutoff_time else f"  比赛时间 < cutoff_time (4小时前): {match.match_time < cutoff_time} ❌")
        print(f"  当前状态 < 3: {match.status < 3} ✅" if match.status < 3 else f"  当前状态 < 3: {match.status < 3} ❌")
        
        if match.match_time < cutoff_time and match.status < 3:
            print(f"  → 这场比赛应该被纳入赛果获取范围！")
        else:
            print(f"  → 这场比赛不会被获取赛果")
        
        # 尝试从API获取这一天的赛果
        try:
            match_date = match.match_time.strftime('%Y-%m-%d')
            print(f"\n🔍 从API获取 {match_date} 的赛果...")
            results = collector.api.get_football_match_result(
                match_begin_date=match_date,
                match_end_date=match_date
            )
            
            if results:
                print(f"  ✅ API返回了 {len(results)} 条赛果")
                
                # 查找是否有这场比赛
                found = False
                for result in results:
                    api_match_id = result.get('matchId')
                    api_home = result.get('allHomeTeam', '')
                    api_away = result.get('allAwayTeam', '')
                    
                    if api_match_id == match.match_id:
                        print(f"\n  🎯 找到匹配的比赛（通过match_id）:")
                        print(f"    API match_id: {api_match_id}")
                        print(f"    主队: {api_home}")
                        print(f"    客队: {api_away}")
                        print(f"    比分: {result.get('homeTeamGoals')} - {result.get('awayTeamGoals')}")
                        print(f"    原始状态: {result.get('matchResultStatus')}")
                        found = True
                        break
                
                if not found:
                    print(f"\n  ❌ API返回的赛果中没有这场比赛（match_id={match.match_id}）")
                    print(f"  可能的原因:")
                    print(f"    1. API没有返回这场比赛的赛果")
                    print(f"    2. 比赛可能延期或取消")
                    print(f"    3. API数据不完整")
            else:
                print(f"  ❌ API未返回任何赛果")
        except Exception as e:
            print(f"  ❌ 获取赛果失败: {e}")
            import traceback
            traceback.print_exc()

if __name__ == '__main__':
    check_tczq_matches()
