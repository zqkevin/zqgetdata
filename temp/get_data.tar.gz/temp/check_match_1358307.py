"""
检查特定比赛的详细信息和页面日期
"""
from app.database import BjdcMatch, localdb
from datetime import timedelta

# 查询特定比赛
match = localdb.query(BjdcMatch).filter_by(match_id=1358307).first()

if not match:
    print("未找到 match_id=1358307 的比赛")
    exit(1)

home_name = match.home_team.team_full_name if match.home_team else '未知'
away_name = match.away_team.team_full_name if match.away_team else '未知'
match_time = match.match_time
status = match.status

print(f"数据库中的比赛:")
print(f"  match_id: {match.match_id}")
print(f"  队名: {home_name} vs {away_name}")
print(f"  比赛时间: {match_time}")
print(f"  状态: {status}")
print(f"  期数: {match.issue}")
print(f"  场次: {match.match_num_str}")

# 计算页面日期
utc_time = match_time - timedelta(hours=8)
if utc_time.hour < 10:
    page_date = (utc_time.date() - timedelta(days=1)).strftime('%Y-%m-%d')
else:
    page_date = utc_time.date().strftime('%Y-%m-%d')

print(f"\n页面日期计算:")
print(f"  北京时间: {match_time}")
print(f"  UTC时间: {utc_time}")
print(f"  UTC小时: {utc_time.hour}")
print(f"  页面日期: {page_date}")

localdb.close()
