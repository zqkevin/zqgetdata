# -*- coding: utf-8 -*-
"""
检查API返回的赛果数据结构
"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.crawler.tczq_result import TczqResultCollector

def check_api_response():
    """检查API响应结构"""
    print("=" * 80)
    print("检查TCZQ API返回的赛果数据结构")
    print("=" * 80)
    
    collector = TczqResultCollector()
    
    # 获取2026-04-28的赛果
    print("\n🔍 获取 2026-04-28 的赛果...")
    results = collector.api.get_football_match_result(
        match_begin_date='2026-04-28',
        match_end_date='2026-04-28'
    )
    
    if results:
        print(f"✅ API返回了 {len(results)} 条赛果\n")
        
        # 找到match_id=2039369的比赛
        for result in results:
            if result.get('matchId') == 2039369:
                print("📋 match_id=2039369 的完整数据结构:")
                import json
                print(json.dumps(result, indent=2, ensure_ascii=False))
                break
    
    # 获取2026-04-29的赛果
    print("\n" + "=" * 80)
    print("\n🔍 获取 2026-04-29 的赛果...")
    results = collector.api.get_football_match_result(
        match_begin_date='2026-04-29',
        match_end_date='2026-04-29'
    )
    
    if results:
        print(f"✅ API返回了 {len(results)} 条赛果\n")
        
        # 找到match_id=2039404的比赛
        for result in results:
            if result.get('matchId') == 2039404:
                print("📋 match_id=2039404 的完整数据结构:")
                import json
                print(json.dumps(result, indent=2, ensure_ascii=False))
                break

if __name__ == '__main__':
    check_api_response()
