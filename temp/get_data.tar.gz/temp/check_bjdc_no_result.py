# -*- coding: utf-8 -*-
"""
检查BJDC异常比赛为什么没有赛果
"""
import sys
import os
from datetime import datetime, timedelta

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.crawler.bjdc_result import BjdcResultCollector
from app.database import localdb, BjdcMatch

def check_bjdc_matches():
    """检查BJDC比赛为什么没有赛果"""
    print("=" * 80)
    print("检查BJDC比赛为什么没有赛果")
    print("=" * 80)
    
    collector = BjdcResultCollector()
    
    # 检查ID 400, 401, 402, 403, 432
    match_ids = [400, 401, 402, 403, 432]
    
    for match_id in match_ids:
        match = localdb.query(BjdcMatch).filter(BjdcMatch.id == match_id).first()
        if not match:
            print(f"\n❌ 未找到ID为{match_id}的比赛")
            continue
        
        home_team = match.home_team.team_full_name if match.home_team else "未知"
        away_team = match.away_team.team_full_name if match.away_team else "未知"
        
        print(f"\n📋 比赛信息:")
        print(f"  ID: {match.id}")
        print(f"  场次号: {match.match_num}")
        print(f"  期数: {match.issue}")
        print(f"  API match_id: {match.match_id}")
        print(f"  比赛时间: {match.match_time}")
        print(f"  对阵: {home_team} vs {away_team}")
        print(f"  当前状态: {match.status}")
        print(f"  已过时间: {(datetime.now() - match.match_time).total_seconds() / 3600:.1f} 小时")
        
        # 检查是否满足赛果获取条件
        cutoff_time = datetime.now() - timedelta(hours=4)
        print(f"\n🔍 赛果获取条件检查:")
        print(f"  比赛时间 < cutoff_time (4小时前): {match.match_time < cutoff_time} ✅" if match.match_time < cutoff_time else f"  比赛时间 < cutoff_time (4小时前): {match.match_time < cutoff_time} ❌")
        print(f"  当前状态 < 3: {match.status < 3} ✅" if match.status < 3 else f"  当前状态 < 3: {match.status < 3} ❌")
        
        if match.match_time < cutoff_time and match.status < 3:
            print(f"  → 这场比赛应该被纳入赛果获取范围！")
        else:
            print(f"  → 这场比赛不会被获取赛果")
        
        # 尝试从500.com爬取这一天的赛果
        try:
            # 根据500.com的规则，10点以前的比赛属于前一天的页面
            if match.match_time.hour >= 10:
                page_date = match.match_time.date()
            else:
                page_date = match.match_time.date() - timedelta(days=1)
            
            date_str = page_date.strftime('%Y-%m-%d')
            print(f"\n🔍 从500.com爬取 {date_str} 的赛果...")
            
            from bs4 import BeautifulSoup
            from app.common._utils import req_info
            
            url = f'https://live.500.com/wanchang.php?e={date_str}'
            soup = req_info(url)
            
            if soup:
                results = collector._parse_match_results_from_html(soup, date_str)
                print(f"  ✅ 爬取到 {len(results)} 条赛果")
                
                # 查找是否有这场比赛（通过match_id）
                found = False
                for result in results:
                    api_match_id = result.get('matchId')
                    api_home = result.get('homeTeam', '')
                    api_away = result.get('awayTeam', '')
                    
                    if api_match_id == str(match.match_id):
                        print(f"\n  🎯 找到匹配的比赛（通过match_id）:")
                        print(f"    API match_id: {api_match_id}")
                        print(f"    主队: {api_home}")
                        print(f"    客队: {api_away}")
                        print(f"    比分: {result.get('homeScore')} - {result.get('awayScore')}")
                        print(f"    半场: {result.get('halfHomeScore')} - {result.get('halfAwayScore')}")
                        print(f"    状态: {result.get('status')}")
                        found = True
                        break
                
                if not found:
                    print(f"\n  ❌ 网页爬取的赛果中没有这场比赛（match_id={match.match_id}）")
            else:
                print(f"  ❌ 网页请求失败")
        except Exception as e:
            print(f"  ❌ 获取赛果失败: {e}")
            import traceback
            traceback.print_exc()

if __name__ == '__main__':
    check_bjdc_matches()
