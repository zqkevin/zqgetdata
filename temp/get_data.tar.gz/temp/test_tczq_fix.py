# -*- coding: utf-8 -*-
"""
测试TCZQ赛果匹配逻辑（优先使用match_id）
"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.crawler.tczq_result import TczqResultCollector
from app.database import localdb, TczqMatch

def test_tczq_result_matching():
    """测试TCZQ赛果匹配"""
    print("=" * 80)
    print("测试TCZQ赛果匹配逻辑")
    print("=" * 80)
    
    collector = TczqResultCollector()
    
    # 获取待匹配的比赛
    results, pending_matches = collector.fetch_match_results()
    
    print(f"\n待匹配比赛数: {len(pending_matches)}")
    print(f"API返回赛果数: {len(results)}")
    
    if not pending_matches:
        print("\n[INFO] 没有待匹配的比赛")
        return
    
    # 检查那2场问题比赛
    target_ids = [78, 84]
    target_matches = [m for m in pending_matches if m.id in target_ids]
    
    print(f"\n目标比赛:")
    for match in target_matches:
        home_name = match.home_team.team_full_name if match.home_team else '未知'
        away_name = match.away_team.team_full_name if match.away_team else '未知'
        print(f"  ID {match.id}: match_id={match.match_id}, {home_name} vs {away_name}")
    
    # 执行保存（这会触发匹配逻辑）
    print(f"\n开始测试匹配...")
    saved_count = collector.save_results_to_db(results, pending_matches)
    
    print(f"\n{'='*80}")
    print(f"测试结果:")
    print(f"  成功保存: {saved_count} 场")
    
    # 检查目标比赛的状态
    print(f"\n检查目标比赛状态:")
    for match_id in target_ids:
        match = localdb.query(TczqMatch).filter_by(id=match_id).first()
        if match:
            home_name = match.home_team.team_full_name if match.home_team else '未知'
            away_name = match.away_team.team_full_name if match.away_team else '未知'
            print(f"  ID {match_id}: status={match.status}, {home_name} vs {away_name}")
            
            # 检查是否有赛果
            from app.database import TczqMatchResult
            result = localdb.query(TczqMatchResult).filter_by(match_id=match.match_id).first()
            if result:
                print(f"    ✅ 有赛果: {result.home_team_goals}-{result.away_team_goals}")
            else:
                print(f"    ❌ 无赛果")
        else:
            print(f"  ID {match_id}: 未找到")
    
    localdb.close()

if __name__ == '__main__':
    test_tczq_result_matching()
