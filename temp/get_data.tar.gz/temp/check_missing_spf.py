# -*- coding: utf-8 -*-
"""
检查特定比赛的API赔率数据结构
"""
import sys
import os
import json

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.common.req_sporttery_api import SportteryAPI

def check_match_odds_structure():
    """检查特定比赛的赔率结构"""
    
    # 需要检查的比赛ID
    match_ids_to_check = [2039146, 2039160, 2039254, 2039260]
    
    api = SportteryAPI()
    
    logger_info = print
    
    logger_info("=" * 80)
    logger_info("检查缺失胜平负赔率的比赛")
    logger_info("=" * 80)
    
    try:
        # 获取比赛列表
        match_data = api.get_football_match_list()
        
        if isinstance(match_data, dict):
            match_info_list = match_data.get('match_info_list', [])
            
            # 提取所有比赛
            all_matches = []
            for date_group in match_info_list:
                sub_matches = date_group.get('subMatchList', [])
                all_matches.extend(sub_matches)
            
            logger_info(f"总共获取 {len(all_matches)} 场比赛\n")
            
            # 查找目标比赛
            for match in all_matches:
                match_id = int(match.get('matchId', 0))
                
                if match_id in match_ids_to_check:
                    home_team = match.get('homeTeamAllName', '')
                    away_team = match.get('awayTeamAllName', '')
                    
                    logger_info(f"\n{'='*80}")
                    logger_info(f"比赛ID: {match_id}")
                    logger_info(f"对阵: {home_team} vs {away_team}")
                    logger_info(f"{'='*80}")
                    
                    # 检查赔率数据
                    odds_data = match.get('oddsData', {})
                    
                    # 检查各种玩法是否存在
                    play_types = {
                        'had': '胜平负',
                        'hhad': '让球胜平负',
                        'ttg': '总进球',
                        'hafu': '半全场',
                        'crs': '比分'
                    }
                    
                    for key, name in play_types.items():
                        if key in odds_data and odds_data[key]:
                            logger_info(f"✅ {name} ({key}): 存在")
                            # 显示前几个赔率值
                            sample_data = odds_data[key]
                            if isinstance(sample_data, dict):
                                sample_keys = list(sample_data.keys())[:3]
                                sample_values = {k: sample_data[k] for k in sample_keys}
                                logger_info(f"   示例数据: {sample_values}")
                        else:
                            logger_info(f"❌ {name} ({key}): 不存在或为空")
                    
                    logger_info("")
            
            # 统计有多少场比赛有/没有胜平负
            had_count = 0
            no_had_count = 0
            
            for match in all_matches:
                odds_data = match.get('oddsData', {})
                if 'had' in odds_data and odds_data['had']:
                    had_count += 1
                else:
                    no_had_count += 1
            
            logger_info(f"\n{'='*80}")
            logger_info(f"统计结果:")
            logger_info(f"  有胜平负赔率的比赛: {had_count} 场")
            logger_info(f"  无胜平负赔率的比赛: {no_had_count} 场")
            logger_info(f"  总计: {had_count + no_had_count} 场")
            logger_info(f"{'='*80}")
            
    except Exception as e:
        print(f"检查失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    check_match_odds_structure()
