# -*- coding: utf-8 -*-
"""检查HTML中是否有半场比分"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-18'
print(f'爬取: {url}\n')

soup = req_info(url)
if not soup:
    print('爬取失败！')
    sys.exit(1)

home_names = soup.find_all('span', class_='mainName')
away_names = soup.find_all('span', class_='clientName')

# 找到南锡比赛
for i in range(min(len(home_names), len(away_names))):
    home_span = home_names[i]
    away_span = away_names[i]
    
    web_home = home_span.get_text(strip=True)
    if '南锡' in web_home:
        match_row = home_span.find_parent('tr')
        tds = match_row.find_all('td')
        
        print(f'找到南锡比赛，共有 {len(tds)} 个td元素:\n')
        for idx, td in enumerate(tds):
            text = td.get_text(strip=True)
            print(f'td[{idx:2d}]: "{text}"')
        
        # 查找包含"-"的td（可能是比分）
        print('\n\n包含"-"的td:')
        for idx, td in enumerate(tds):
            text = td.get_text(strip=True)
            if '-' in text and any(c.isdigit() for c in text):
                print(f'  td[{idx}]: "{text}"')
        
        break
