# -*- coding: utf-8 -*-
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, BjdcMatch
from datetime import timedelta

match_ids = [1212076, 1212157]

print('=' * 100)
print('比分缺失的比赛详情')
print('=' * 100)

for match_id in match_ids:
    match = localdb.query(BjdcMatch).filter_by(match_id=match_id).first()
    if not match:
        print(f'\nMatch ID {match_id}: 未找到')
        continue
    
    home_name = match.home_team.team_full_name if match.home_team else '未知'
    away_name = match.away_team.team_full_name if match.away_team else '未知'
    
    # 计算页面日期
    if match.match_time:
        if match.match_time.hour >= 10:
            page_date = (match.match_time.date() + timedelta(days=1)).strftime('%Y-%m-%d')
        else:
            page_date = match.match_time.date().strftime('%Y-%m-%d')
    else:
        page_date = '未知'
    
    print(f'\n【Match ID: {match_id}】')
    print(f'  比赛: {home_name} vs {away_name}')
    print(f'  联赛ID: {match.league_id}')
    print(f'  比赛时间: {match.match_time}')
    print(f'  星期: {match.match_week}')
    print(f'  期数: {match.issue}')
    print(f'  场次: {match.match_num_str}')
    print(f'  当前状态: {match.status}')
    print(f'  页面日期: {page_date}')
    print(f'  URL: https://live.500.com/wanchang.php?e={page_date}')
    print('-' * 100)
