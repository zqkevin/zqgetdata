# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.crawler.tczq_result import TczqResultCollector

print("Testing TCZQ result collection...")
collector = TczqResultCollector()
results, pending_matches = collector.fetch_match_results()

print(f"Results: {len(results)}")
print(f"Pending matches: {len(pending_matches)}")

if pending_matches:
    print("\nSaving results...")
    try:
        saved = collector.save_results_to_db(results, pending_matches)
        print(f"SUCCESS: Saved {saved} results")
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
else:
    print("No pending matches")
