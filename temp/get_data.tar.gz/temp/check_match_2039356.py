import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, TczqMatch
from datetime import datetime

# 查询比赛ID 2039356
match = localdb.query(TczqMatch).filter_by(match_id=2039356).first()

if match:
    print(f"数据库中的比赛信息:")
    print(f"  match_id: {match.match_id}")
    print(f"  主队: {match.home_team.team_full_name if match.home_team else '未知'}")
    print(f"  客队: {match.away_team.team_full_name if match.away_team else '未知'}")
    print(f"  match_time: {match.match_time}")
    print(f"  status: {match.status}")
    
    if match.match_time:
        now = datetime.now()
        hours_passed = (now - match.match_time).total_seconds() / 3600
        print(f"  当前时间: {now}")
        print(f"  距离开赛已过: {hours_passed:.1f} 小时")
        
        if hours_passed > 4:
            print(f"  ⚠️  已超过4小时，应该有赛果了！")
        else:
            print(f"  ✓ 还未到4小时")
else:
    print("数据库中未找到比赛ID 2039356")
