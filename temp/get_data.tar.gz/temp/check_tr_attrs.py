# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.common._utils import req_info

soup = req_info('https://live.500.com/wanchang.php?e=2026-04-29')
tr_list = soup.find_all('tr', id=lambda x: x and x.startswith('a'))
print(f'Total: {len(tr_list)}')

target_ids = ['a1398747', 'a1398836', 'a1398801', 'a1407929']
for tr in tr_list:
    if tr.get('id') in target_ids:
        print(f'ID: {tr.get("id")}, gy: {tr.get("gy")}')
