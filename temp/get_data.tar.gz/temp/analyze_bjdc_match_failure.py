# -*- coding: utf-8 -*-
"""详细分析BJDC赛果匹配失败的原因"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, BjdcMatch, Team
from app.common._utils import req_info
from bs4 import BeautifulSoup
from datetime import datetime, timedelta

# 3场未匹配的比赛
pending_matches = [
    {'match_id': 1337830, 'home': '墨尔本胜利', 'away': '纽卡斯尔喷气机', 'date': '2026-04-17'},
    {'match_id': 1394821, 'home': '加拉茨钢铁', 'away': 'UTA阿拉德', 'date': '2026-04-17'},
    {'match_id': 1406172, 'home': '吉达国民', 'away': '柔佛', 'date': '2026-04-17'},
]

print('=' * 120)
print('BJDC赛果匹配失败分析')
print('=' * 120)

# 爬取2026-04-17的网页
url = 'https://live.500.com/wanchang.php?e=2026-04-17'
print(f'\n爬取网页: {url}\n')

soup = req_info(url)
if not soup:
    print('爬取失败！')
    sys.exit(1)

# 解析网页中的所有比赛
home_names = soup.find_all('span', class_='mainName')
away_names = soup.find_all('span', class_='clientName')

print(f'网页中共有 {len(home_names)} 场比赛\n')

# 提取所有比赛的队名
web_matches = []
for i in range(min(len(home_names), len(away_names))):
    home_span = home_names[i]
    away_span = away_names[i]
    
    match_row = home_span.find_parent('tr')
    if not match_row:
        continue
    
    tr_id = match_row.get('id', '')
    match_id = tr_id.replace('a', '') if tr_id.startswith('a') else tr_id
    
    # 提取联赛名称
    league_td = match_row.find('td', class_='ssbox_01')
    league_name = league_td.get_text(strip=True) if league_td else ''
    
    web_home = home_span.get_text(strip=True)
    web_away = away_span.get_text(strip=True)
    
    web_matches.append({
        'match_id': match_id,
        'league': league_name,
        'home': web_home,
        'away': web_away
    })

print('=' * 120)
print('待匹配比赛 vs 网页爬取比赛对比')
print('=' * 120)

for idx, pending in enumerate(pending_matches):
    print(f'\n【比赛 {idx+1}】')
    print(f'  数据库 Match ID: {pending["match_id"]}')
    print(f'  数据库主队: {pending["home"]}')
    print(f'  数据库客队: {pending["away"]}')
    print(f'  比赛日期: {pending["date"]}')
    
    # 在网页结果中查找相同的match_id
    matched_web = None
    for web_match in web_matches:
        if web_match['match_id'] == str(pending['match_id']):
            matched_web = web_match
            break
    
    if matched_web:
        print(f'\n  ✅ 网页中找到相同 Match ID 的比赛:')
        print(f'     网页 Match ID: {matched_web["match_id"]}')
        print(f'     网页联赛: {matched_web["league"]}')
        print(f'     网页主队: {matched_web["home"]}')
        print(f'     网页客队: {matched_web["away"]}')
        
        # 比较队名
        home_match = pending['home'] == matched_web['home']
        away_match = pending['away'] == matched_web['away']
        
        if home_match and away_match:
            print(f'     ⚠️  队名完全一致，但匹配失败！可能是其他原因')
        else:
            print(f'\n     ❌ 队名不一致:')
            if not home_match:
                print(f'        主队差异: "{pending["home"]}" vs "{matched_web["home"]}"')
            if not away_match:
                print(f'        客队差异: "{pending["away"]}" vs "{matched_web["away"]}"')
    else:
        print(f'\n  ❌ 网页中未找到 Match ID={pending["match_id"]} 的比赛')
        # 尝试通过队名模糊查找
        print(f'     尝试通过队名查找...')
        for web_match in web_matches:
            if (pending['home'] in web_match['home'] or web_match['home'] in pending['home']) and \
               (pending['away'] in web_match['away'] or web_match['away'] in pending['away']):
                print(f'     🔍 找到相似比赛:')
                print(f'        网页 Match ID: {web_match["match_id"]}')
                print(f'        网页主队: {web_match["home"]}')
                print(f'        网页客队: {web_match["away"]}')
                break

print('\n' + '=' * 120)
print('分析完成')
print('=' * 120)
