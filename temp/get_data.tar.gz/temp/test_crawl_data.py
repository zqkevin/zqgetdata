# -*- coding: utf-8 -*-
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.crawler.bjdc_result import BjdcResultCollector
from datetime import datetime, timedelta

collector = BjdcResultCollector()

# 模拟获取赛果
results, pending_matches = collector.fetch_match_results()

print(f'爬取到 {len(results)} 条赛果')
print(f'待匹配 {len(pending_matches)} 场比赛\n')

if results:
    print('前5条爬取的赛果数据:')
    print('=' * 120)
    for i, r in enumerate(results[:5]):
        print(f'{i+1}. Match ID: {r.get("matchId")}')
        print(f'   主队: {r.get("homeTeam")}')
        print(f'   客队: {r.get("awayTeam")}')
        print(f'   日期: {r.get("matchDate")}')
        print(f'   比分: {r.get("homeScore")}-{r.get("awayScore")}')
        print(f'   半场: {r.get("halfHomeScore")}-{r.get("halfAwayScore")}')
        print()

if pending_matches:
    print('\n前5场待匹配比赛:')
    print('=' * 120)
    for i, m in enumerate(pending_matches[:5]):
        home = m.home_team.team_full_name if m.home_team else '未知'
        away = m.away_team.team_full_name if m.away_team else '未知'
        
        # 计算页面日期
        if m.match_time:
            if m.match_time.hour >= 10:
                page_date = (m.match_time.date() + timedelta(days=1)).strftime('%Y-%m-%d')
            else:
                page_date = m.match_time.date().strftime('%Y-%m-%d')
        else:
            page_date = '未知'
        
        print(f'{i+1}. Match ID: {m.match_id}')
        print(f'   主队: {home}')
        print(f'   客队: {away}')
        print(f'   页面日期: {page_date}')
        print()
