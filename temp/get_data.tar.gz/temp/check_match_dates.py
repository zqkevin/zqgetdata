# -*- coding: utf-8 -*-
"""检查BJDC比赛的时间与页面日期关系"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, BjdcMatch
from datetime import datetime, timedelta

# 3场未匹配的比赛
match_ids = [1337830, 1394821, 1406172]

print('=' * 100)
print('BJDC比赛时间与页面日期分析')
print('=' * 100)

for match_id in match_ids:
    match = localdb.query(BjdcMatch).filter_by(match_id=match_id).first()
    if not match:
        print(f'\nMatch ID {match_id}: 未找到')
        continue
    
    home_name = match.home_team.team_full_name if match.home_team else '未知'
    away_name = match.away_team.team_full_name if match.away_team else '未知'
    
    print(f'\n【Match ID: {match_id}】')
    print(f'  比赛: {home_name} vs {away_name}')
    print(f'  比赛时间: {match.match_time}')
    print(f'  星期: {match.match_week}')
    print(f'  期数: {match.issue}')
    print(f'  场次: {match.match_num_str}')
    
    # 计算不同偏移的页面日期
    match_date = match.match_time.date()
    page_date_minus_10h = (match.match_time - timedelta(hours=10)).date()
    page_date_same_day = match_date
    
    print(f'\n  页面日期计算:')
    print(f'    比赛当天: {page_date_same_day}')
    print(f'    减10小时: {page_date_minus_10h}')
    print(f'    差异: {(page_date_same_day - page_date_minus_10h).days} 天')
    
    # 建议的URL
    print(f'\n  建议查询的URL:')
    print(f'    https://live.500.com/wanchang.php?e={page_date_same_day}')
    print(f'    https://live.500.com/wanchang.php?e={page_date_minus_10h}')

print('\n' + '=' * 100)
