# -*- coding: utf-8 -*-
"""
测试优化后的球队名称匹配逻辑
"""
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.common._utils import handle_team_name
from app.database import localdb, Team

print("=" * 80)
print("测试优化后的球队名称匹配逻辑")
print("=" * 80)

# 测试用例：应该匹配的（正确的）
should_match = [
    ("拜仁", "tczq", "拜仁慕尼黑"),  # 长度差2，但"拜仁"在"拜仁慕尼黑"中
    ("埃因霍温", "bjdc", "PSV埃因霍温"),  # 长度差3，但"埃因霍温"在"PSV埃因霍温"中
]

# 测试用例：不应该匹配的（错误的）
should_not_match = [
    ("曼彻斯特城", "tczq", "曼彻斯特联"),  # 不同球队
    ("布拉格斯巴达", "bjdc", "布拉格斯拉维亚"),  # 不同球队
]

print("\n【应该匹配的案例】\n")
for team_name, source_type, expected in should_match:
    print(f"测试: '{team_name}' (来源:{source_type})")
    print(f"  预期: 应该匹配到 '{expected}'")
    
    team = handle_team_name(team_name, source_type=source_type)
    
    if team:
        if team.team_full_name == expected:
            print(f"  ✓ 正确匹配: ID={team.id}, 全称='{team.team_full_name}'")
        else:
            print(f"  ✗ 错误匹配: ID={team.id}, 全称='{team.team_full_name}' (预期: {expected})")
    else:
        print(f"  ⚠ 未匹配，将创建新球队")
    print()

print("\n【不应该匹配的案例】\n")
for team_name, source_type, wrong_match in should_not_match:
    print(f"测试: '{team_name}' (来源:{source_type})")
    print(f"  预期: 不应该匹配到 '{wrong_match}'")
    
    # 先查找目标球队
    target_team = localdb.query(Team).filter_by(team_full_name=wrong_match).first()
    
    if target_team:
        team = handle_team_name(team_name, source_type=source_type)
        
        if team and team.id == target_team.id:
            print(f"  ✗ 错误！匹配到了 '{team.team_full_name}' (ID:{team.id})")
        else:
            if team:
                print(f"  ✓ 正确：匹配到其他球队 '{team.team_full_name}' (ID:{team.id})")
            else:
                print(f"  ✓ 正确：创建了新的球队记录")
    else:
        print(f"  ⚠ 目标球队 '{wrong_match}' 不存在于数据库中")
    print()

print("=" * 80)
print("测试完成")
print("=" * 80)

localdb.close()
