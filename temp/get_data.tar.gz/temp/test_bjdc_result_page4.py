# -*- coding: utf-8 -*-
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.common._utils import req_info

# 获取页面
soup = req_info('https://live.500.com/wanchang.php?e=2026-04-14')

if not soup:
    print("Failed to fetch page")
    sys.exit(1)

# 查找所有比赛行
print("查找比赛信息...\n")

# 方法1: 查找包含 clientName 的父级元素
client_names = soup.find_all('span', class_='clientName')
print(f"找到 {len(client_names)} 个球队名称\n")

# 查看前几个比赛的完整结构
for i, name_span in enumerate(client_names[:6]):
    # 向上找到比赛行
    match_row = name_span.find_parent('tr') or name_span.find_parent('div')
    
    if match_row:
        print(f"比赛 {i//2 + 1}:")
        print(f"  HTML 结构: {match_row.name}")
        
        # 获取所有文本内容
        all_text = match_row.get_text(strip=True)
        print(f"  完整文本: {all_text[:200]}")
        
        # 查找比分
        score_spans = match_row.find_all('span', class_=lambda x: x and 'score' in str(x).lower())
        if score_spans:
            scores = [s.get_text(strip=True) for s in score_spans]
            print(f"  比分: {scores}")
        
        # 查找时间
        time_spans = match_row.find_all('span', class_=lambda x: x and ('time' in str(x).lower() or 'date' in str(x).lower()))
        if time_spans:
            times = [t.get_text(strip=True) for t in time_spans[:2]]
            print(f"  时间: {times}")
        
        print()
