"""
检查 BJDC 数据库 match_id 和网页 matchId 是否匹配
"""
from app.database import BjdcMatch, localdb
from app.crawler.bjdc_result import BjdcResultCollector
from app.common._utils import req_info
from datetime import datetime, timedelta

# 查询需要获取赛果的比赛
cutoff_time = datetime.now() - timedelta(hours=4)
pending_matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.match_time < cutoff_time,
    BjdcMatch.status < 3
).all()

print(f"待匹配比赛: {len(pending_matches)} 场\n")

# 按页面日期分组
pending_by_date = {}
for match in pending_matches:
    if match.match_time:
        utc_time = match.match_time - timedelta(hours=8)
        if utc_time.hour < 10:
            page_date = (utc_time.date() - timedelta(days=1)).strftime('%Y-%m-%d')
        else:
            page_date = utc_time.date().strftime('%Y-%m-%d')
    else:
        page_date = ''
    
    if page_date not in pending_by_date:
        pending_by_date[page_date] = []
    
    pending_by_date[page_date].append(match)

# 爬取网页赛果并对比
collector = BjdcResultCollector()

for page_date in sorted(pending_by_date.keys()):
    matches = pending_by_date[page_date]
    print(f"\n{'='*60}")
    print(f"{page_date}: 待匹配 {len(matches)} 场")
    
    # 爬取该日期的赛果
    url = f'https://live.500.com/wanchang.php?e={page_date}'
    soup = req_info(url)
    
    if not soup:
        print(f"  ❌ 爬取失败")
        continue
    
    results = collector._parse_match_results_from_html(soup, page_date)
    print(f"  爬取到 {len(results)} 条赛果")
    
    # 构建网页 matchId 集合（字符串）
    web_match_ids = set()
    for result in results:
        match_id_str = result.get('matchId', '')
        if match_id_str:
            web_match_ids.add(match_id_str)
    
    # 检查数据库 match_id 是否在网页中
    matched_count = 0
    unmatched_samples = []
    
    for match in matches[:10]:  # 只检查前10个
        db_match_id_str = str(match.match_id)
        if db_match_id_str in web_match_ids:
            matched_count += 1
        else:
            home_name = match.home_team.team_full_name if match.home_team else '未知'
            away_name = match.away_team.team_full_name if match.away_team else '未知'
            unmatched_samples.append((match.match_id, home_name, away_name))
    
    print(f"  前10场中匹配: {matched_count} 场")
    
    if unmatched_samples:
        print(f"\n  未匹配样本（前5个）:")
        for match_id, home, away in unmatched_samples[:5]:
            print(f"    DB match_id={match_id} (str='{str(match_id)}'): {home} vs {away}")
        
        # 检查是否有相似的 ID
        print(f"\n  检查是否有相近的 ID:")
        for match_id, home, away in unmatched_samples[:3]:
            match_id_str = str(match_id)
            # 查找网页中是否有包含该 ID 的记录
            similar_ids = [wid for wid in web_match_ids if match_id_str in wid or wid in match_id_str]
            if similar_ids:
                print(f"    {match_id_str} -> 找到相似: {similar_ids[:3]}")
            else:
                # 显示网页中的部分 ID
                sample_web_ids = list(web_match_ids)[:5]
                print(f"    {match_id_str} -> 无相似，网页示例: {sample_web_ids}")

localdb.close()
