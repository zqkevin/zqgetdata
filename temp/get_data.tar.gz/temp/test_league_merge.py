# -*- coding: utf-8 -*-
"""
测试联赛名称处理逻辑
验证BJDC和TCZQ的联赛名称能否正确合并
"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.common._utils import handle_league_name, get_or_create_league
from app.database import localdb, League
from app.log.logger import log


def test_league_merge():
    """测试联赛名称合并逻辑"""
    
    print("\n" + "="*80)
    print(" " * 25 + "联赛名称合并测试")
    print("="*80)
    
    # 场景1: BJDC先创建简称记录
    print("\n【场景1】BJDC先创建简称记录 '德甲'")
    print("-"*80)
    league1 = handle_league_name("德甲", source_type='bjdc')
    if league1:
        print(f"✓ 创建成功: ID={league1.id}, league_id={league1.league_id}")
        print(f"  全称='{league1.league_name}', 简称='{league1.league_name_abbr}'")
    else:
        print("✗ 创建失败")
        return
    
    # 场景2: TCZQ后用全称查询,应该找到同一条记录并补充全称
    print("\n【场景2】TCZQ用全称 '德国甲级联赛' 查询,应匹配到同一记录")
    print("-"*80)
    league2 = handle_league_name("德国甲级联赛", source_type=None)
    if league2:
        print(f"✓ 查询成功: ID={league2.id}, league_id={league2.league_id}")
        print(f"  全称='{league2.league_name}', 简称='{league2.league_name_abbr}'")
        
        if league1.id == league2.id:
            print("✓✓✓ 成功!两条记录是同一个ID,没有重复创建")
        else:
            print(f"✗✗✗ 失败!创建了重复记录: ID1={league1.id}, ID2={league2.id}")
    else:
        print("✗ 查询失败")
    
    # 场景3: 使用get_or_create_league函数(TCZQ实际使用的)
    print("\n【场景3】使用 get_or_create_league('意大利甲级联赛', '意甲')")
    print("-"*80)
    league3_id = get_or_create_league("意大利甲级联赛", "意甲")
    if league3_id:
        league3 = localdb.query(League).filter_by(id=league3_id).first()
        print(f"✓ 处理成功: ID={league3.id}")
        print(f"  全称='{league3.league_name}', 简称='{league3.league_name_abbr}'")
    
    # 场景4: 再次用简称查询,应该找到同一条记录
    print("\n【场景4】再用简称 '意甲' 查询,应找到同一记录")
    print("-"*80)
    league4 = handle_league_name("意甲", source_type=None)
    if league4:
        print(f"✓ 查询成功: ID={league4.id}")
        print(f"  全称='{league4.league_name}', 简称='{league4.league_name_abbr}'")
        
        if league3_id == league4.id:
            print("✓✓✓ 成功!两次查询返回同一记录")
        else:
            print(f"✗✗✗ 失败!ID不一致: ID3={league3_id}, ID4={league4.id}")
    else:
        print("✗ 查询失败")
    
    # 检查数据库中是否有重复
    print("\n【检查】查询数据库中的重复记录")
    print("-"*80)
    from sqlalchemy import func as sql_func
    duplicates = localdb.session.query(
        League.league_name,
        League.league_name_abbr,
        sql_func.count(League.id).label('cnt')
    ).group_by(
        League.league_name,
        League.league_name_abbr
    ).having(
        sql_func.count(League.id) > 1
    ).all()
    
    if duplicates:
        print(f"⚠️  发现 {len(duplicates)} 组重复:")
        for dup in duplicates:
            name = dup.league_name if dup.league_name else "(空)"
            abbr = dup.league_name_abbr if dup.league_name_abbr else "(空)"
            print(f"  - {name} / {abbr} (重复{dup.cnt}次)")
    else:
        print("✓ 未发现重复记录!")
    
    print("\n" + "="*80)
    print("测试完成")
    print("="*80 + "\n")


if __name__ == '__main__':
    try:
        test_league_merge()
    except Exception as e:
        log.error(f"测试失败: {str(e)}")
        import traceback
        log.error(traceback.format_exc())
        print(f"\n✗ 错误: {str(e)}")
        traceback.print_exc()
