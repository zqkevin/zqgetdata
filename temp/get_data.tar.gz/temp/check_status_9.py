"""
检查状态9的比赛是否需要获取赛果
"""
from app.database import BjdcMatch, localdb
from datetime import datetime, timedelta

# 查询状态为9的比赛
status_9_matches = localdb.query(BjdcMatch).filter_by(status=9).all()

print(f"状态9的比赛数: {len(status_9_matches)}\n")

# 检查这些比赛的时间
now = datetime.now()
cutoff_time = now - timedelta(hours=4)

need_result = []
not_need_result = []

for match in status_9_matches:
    if match.match_time and match.match_time < cutoff_time:
        need_result.append(match)
    else:
        not_need_result.append(match)

print(f"需要获取赛果（结束超过4小时）: {len(need_result)} 场")
print(f"不需要获取赛果（未结束或刚结束）: {len(not_need_result)} 场\n")

if len(need_result) > 0:
    print("前10场需要获取赛果的比赛:")
    for match in need_result[:10]:
        home = match.home_team.team_full_name if match.home_team else '未知'
        away = match.away_team.team_full_name if match.away_team else '未知'
        hours_ago = (now - match.match_time).total_seconds() / 3600
        print(f"  - {home} vs {away} ({match.match_time}), 已结束{hours_ago:.1f}小时")
