# -*- coding: utf-8 -*-
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, BjdcMatch
from datetime import datetime, timedelta

now = datetime.now()
cutoff_time = now - timedelta(hours=4)

matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.status == 0,
    BjdcMatch.match_time < cutoff_time
).all()

print(f'需要获取赛果的比赛: {len(matches)} 场\n')
print('=' * 120)

for i, m in enumerate(matches[:5]):  # 只显示前5场
    home_name = m.home_team.team_full_name if m.home_team else '未知'
    away_name = m.away_team.team_full_name if m.away_team else '未知'
    
    # 计算页面日期
    if m.match_time:
        if m.match_time.hour >= 10:
            page_date = (m.match_time.date() + timedelta(days=1)).strftime('%Y-%m-%d')
        else:
            page_date = m.match_time.date().strftime('%Y-%m-%d')
    else:
        page_date = '未知'
    
    print(f'\n比赛 {i+1}:')
    print(f'  Match ID: {m.match_id}')
    print(f'  主队: {home_name}')
    print(f'  客队: {away_name}')
    print(f'  比赛时间: {m.match_time}')
    print(f'  页面日期: {page_date}')
    print('-' * 120)
