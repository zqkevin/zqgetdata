# -*- coding: utf-8 -*-
"""
修复 BJDC 和 TCZQ 之间的球队别名映射
"""
import sys
import os
# 添加项目根目录到 Python 路径
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, Team, TeamAlias

def fix_team_aliases():
    """修复常见的球队别名映射"""
    
    # 定义需要添加的别名映射（TCZQ/API队名 -> BJDC队名）
    # 注意：这里是为 API 返回的队名添加 BJDC 系统中的队名作为别名
    alias_mappings = [
        # 英超/英冠
        ("朴次茅斯", "朴茨茅斯"),  # API:朴次茅斯 -> DB:朴茨茅斯
        ("南安普敦", "南安普顿"),
        ("巴黎圣日尔曼", "巴黎圣日耳曼"),
        ("葡萄牙体育", "里斯本竞技"),
        
        # 其他可能的差异
        ("利勒斯特罗姆", "利勒斯特伦"),
    ]
    
    print("=" * 80)
    print("开始修复球队别名映射")
    print("=" * 80)
    
    added_count = 0
    skipped_count = 0
    
    for api_name, bjdc_name in alias_mappings:
        # 查找 API 队名对应的球队
        api_team = localdb.query(Team).filter(
            (Team.team_full_name == api_name) | 
            (Team.team_short_name == api_name)
        ).first()
        
        if not api_team:
            print(f"[SKIP] 未找到 API 球队: {api_name}")
            skipped_count += 1
            continue
        
        # 检查是否已存在该别名
        existing_alias = localdb.query(TeamAlias).filter(
            TeamAlias.team_id == api_team.id,
            TeamAlias.alias_name == bjdc_name
        ).first()
        
        if existing_alias:
            print(f"[EXIST] 别名已存在: {bjdc_name} -> {api_team.team_full_name} (ID:{api_team.id})")
            skipped_count += 1
            continue
        
        # 创建别名：为 API 球队添加 BJDC 队名作为别名
        try:
            new_alias = TeamAlias(
                team_id=api_team.id,
                alias_name=bjdc_name,
                source_type='bjdc',
                remark='Auto-fixed for BJDC-TCZQ matching'
            )
            localdb.add(new_alias)
            print(f"[ADD] 添加别名: {bjdc_name} -> {api_team.team_full_name} (ID:{api_team.id})")
            added_count += 1
        except Exception as e:
            print(f"[ERROR] 添加失败: {bjdc_name} -> {api_name}, 错误: {e}")
            localdb.rollback()
    
    print("\n" + "=" * 80)
    print(f"修复完成: 添加 {added_count} 个别名, 跳过 {skipped_count} 个")
    print("=" * 80)

if __name__ == '__main__':
    try:
        fix_team_aliases()
    except Exception as e:
        print(f"\n[ERROR] 执行失败: {e}")
        import traceback
        traceback.print_exc()
