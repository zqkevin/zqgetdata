# -*- coding: utf-8 -*-
"""
检查TCZQ赛果获取情况
"""
import sys
sys.path.insert(0, 'E:\\my_prog\\zqgetdata')

from app.crawler.tczq_result import TczqResultCollector
from app.database import localdb, TczqMatch
from datetime import datetime, timedelta

# 需要检查的比赛
match_ids = [2039244, 2039248, 2039249]

print("=" * 80)
print("检查TCZQ赛果获取情况")
print("=" * 80)

# 查询比赛信息
for match_id in match_ids:
    match = localdb.query(TczqMatch).filter_by(match_id=match_id).first()
    if match:
        print(f"\n比赛 {match_id}:")
        print(f"  场次: {match.match_num_str}")
        print(f"  时间: {match.match_time}")
        print(f"  状态: {match.status}")
        
        # 计算距离现在的时间差
        if match.match_time:
            now = datetime.now()
            match_time = match.match_time
            if hasattr(match_time, 'replace'):
                diff = now - match_time.replace(tzinfo=None)
                print(f"  已结束时长: {diff.total_seconds() / 3600:.1f} 小时")

# 尝试获取赛果
print("\n" + "=" * 80)
print("尝试从API获取赛果...")
print("=" * 80)

crawler = TczqResultCollector()

# 获取昨天的赛果
yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
print(f"\n获取日期: {yesterday}")

try:
    results = crawler.fetch_match_results(yesterday, yesterday)
    print(f"API返回赛果数量: {len(results)}")
    
    # 检查目标比赛是否在结果中
    result_dict = {r.get('matchId'): r for r in results}
    
    for match_id in match_ids:
        if match_id in result_dict:
            print(f"\n✓ 比赛 {match_id} 在API返回结果中")
            result = result_dict[match_id]
            print(f"  比分: {result.get('homeTeamGoals')} - {result.get('awayTeamGoals')}")
            print(f"  半场: {result.get('halfTimeHomeGoals')} - {result.get('halfTimeAwayGoals')}")
        else:
            print(f"\n✗ 比赛 {match_id} 不在API返回结果中")
            
except Exception as e:
    print(f"获取赛果失败: {e}")
    import traceback
    traceback.print_exc()

localdb.close()
