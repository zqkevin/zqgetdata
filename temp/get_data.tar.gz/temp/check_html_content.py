"""
检查爬取到的HTML内容
"""
from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-27'
print(f"爬取: {url}")

soup = req_info(url)

if not soup:
    print("❌ 爬取失败")
    exit(1)

# 输出HTML的前2000个字符
html_str = str(soup)[:2000]
print(f"\nHTML前2000字符:\n{html_str}")

# 查找所有 tr 标签
tr_tags = soup.find_all('tr')
print(f"\n\ntr 标签数量: {len(tr_tags)}")

if len(tr_tags) > 0:
    print(f"\n前3个 tr 标签:")
    for i, tr in enumerate(tr_tags[:3]):
        print(f"\n{i+1}. id={tr.get('id', '')}, class={tr.get('class', '')}")
        print(f"   文本: {tr.get_text(strip=True)[:100]}")
