# -*- coding: utf-8 -*-
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.common._utils import req_info

# 获取页面
soup = req_info('https://live.500.com/wanchang.php?e=2026-04-14')

if not soup:
    print("Failed to fetch page")
    sys.exit(1)

# 查找表格
tables = soup.find_all('table', class_='t-table')
print(f'找到 {len(tables)} 个表格\n')

for i, table in enumerate(tables[:3]):
    print(f"表格 {i}: id={table.get('id')}, class={table.get('class')}")
    
    # 查找行
    rows = table.find_all('tr')
    print(f"  行数: {len(rows)}")
    
    # 查看前几行
    for j, row in enumerate(rows[:2]):
        cells = row.find_all(['td', 'th'])
        print(f"  行 {j}: {len(cells)} 列")
        if cells:
            # 打印前几个单元格的内容
            cell_texts = [cell.get_text(strip=True)[:30] for cell in cells[:5]]
            print(f"    内容: {' | '.join(cell_texts)}")
    print()
