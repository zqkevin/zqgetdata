"""
检查 04-27 页面爬取到的比赛时间范围
"""
from app.crawler.bjdc_result import BjdcResultCollector
from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-27'
soup = req_info(url)

collector = BjdcResultCollector()
results = collector._parse_match_results_from_html(soup, '2026-04-27')

print(f"总共解析到 {len(results)} 场比赛\n")

if len(results) > 0:
    # 提取所有时间
    times = [r['matchTime'] for r in results if r['matchTime']]
    print(f"时间范围:")
    print(f"  最早: {min(times)}")
    print(f"  最晚: {max(times)}")
    
    # 显示前5个和最后5个比赛
    print(f"\n前5场比赛:")
    for r in results[:5]:
        print(f"  {r['matchId']}: {r['homeTeam']} vs {r['awayTeam']} ({r['matchTime']})")
    
    print(f"\n最后5场比赛:")
    for r in results[-5:]:
        print(f"  {r['matchId']}: {r['homeTeam']} vs {r['awayTeam']} ({r['matchTime']})")
