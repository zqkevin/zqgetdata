# -*- coding: utf-8 -*-
"""
检查BJDC match_id匹配问题
"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.crawler.bjdc_result import BjdcResultCollector
from bs4 import BeautifulSoup
from app.common._utils import req_info

def check_match_id_matching():
    """检查match_id匹配"""
    print("=" * 80)
    print("检查BJDC match_id匹配")
    print("=" * 80)
    
    collector = BjdcResultCollector()
    
    # 要检查的比赛
    target_matches = [
        {'id': 400, 'match_id': 1398747},
        {'id': 401, 'match_id': 1398836},
        {'id': 402, 'match_id': 1398801},
        {'id': 403, 'match_id': 1407929},
    ]
    
    # 爬取2026-04-28的页面
    date_str = '2026-04-28'
    url = f'https://live.500.com/wanchang.php?e={date_str}'
    print(f"\n爬取 {date_str} 的页面...")
    
    soup = req_info(url)
    if not soup:
        print("[FAIL] 网页请求失败")
        return
    
    results = collector._parse_match_results_from_html(soup, date_str)
    print(f"爬取到 {len(results)} 条赛果\n")
    
    # 构建match_id索引
    results_by_id = {}
    for result in results:
        web_match_id = result.get('matchId', '')
        if web_match_id:
            results_by_id[web_match_id] = result
    
    print(f"赛果中的match_id示例（前10个）:")
    for i, mid in enumerate(list(results_by_id.keys())[:10]):
        r = results_by_id[mid]
        print(f"  {i+1}. matchId='{mid}' (type={type(mid).__name__}): {r.get('homeTeam')} vs {r.get('awayTeam')}")
    
    print(f"\n目标比赛的match_id:")
    for match in target_matches:
        db_match_id = str(match['match_id'])
        print(f"  ID {match['id']}: match_id={db_match_id} (type=str)")
        
        # 尝试匹配
        if db_match_id in results_by_id:
            r = results_by_id[db_match_id]
            print(f"    [OK] 匹配成功!")
            print(f"         网页队名: {r.get('homeTeam')} vs {r.get('awayTeam')}")
        else:
            print(f"    [FAIL] 未找到匹配")
            
            # 查找是否有类似的ID
            similar_ids = [mid for mid in results_by_id.keys() if mid.startswith(db_match_id[:4])]
            if similar_ids:
                print(f"    相似的ID: {similar_ids[:5]}")

if __name__ == '__main__':
    check_match_id_matching()
