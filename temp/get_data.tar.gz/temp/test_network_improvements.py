# -*- coding: utf-8 -*-
"""
测试改进后的网络连接处理
"""
import sys
import os

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 指向 E:\my_prog\zqgetdata
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.common._utils import req_info
from app.log.logger import bjdc_log

def test_req_info():
    """测试 req_info 函数的网络连接处理"""
    
    print("=" * 60)
    print("测试改进后的网络连接处理")
    print("=" * 60)
    
    # 测试 URL
    test_urls = [
        ('https://trade.500.com/bjdc/', None, '北京单场主页'),
        ('https://trade.500.com/bjdc/project_fq_bq.php', '26048', '半全场数据'),
        ('https://trade.500.com/bjdc/project_fq_jq.php', '26048', '总进球数据'),
        ('https://trade.500.com/bjdc/project_fq_bf.php', '26048', '比分数据'),
        ('https://trade.500.com/bjdc/project_fq_ds.php', '26048', '上下单双数据'),
    ]
    
    for url, qishu, description in test_urls:
        print(f"\n测试: {description}")
        print(f"URL: {url}" + (f"?e={qishu}" if qishu else ""))
        print("-" * 60)
        
        try:
            result = req_info(url, qishu)
            if result:
                print(f"✓ 成功获取页面")
                print(f"  页面标题: {result.title.text if result.title else 'N/A'}")
                print(f"  内容长度: {len(str(result))} 字符")
            else:
                print(f"✗ 获取页面失败")
        except Exception as e:
            print(f"✗ 异常: {type(e).__name__}: {str(e)}")
        
        print()
    
    print("=" * 60)
    print("测试完成")
    print("=" * 60)

if __name__ == '__main__':
    test_req_info()
