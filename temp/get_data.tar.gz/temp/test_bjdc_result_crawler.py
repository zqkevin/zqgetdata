# -*- coding: utf-8 -*-
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.crawler.bjdc_result import BjdcResultCollector

c = BjdcResultCollector()
results, pending = c.fetch_match_results()

print(f'\n爬取到 {len(results)} 条赛果, 待匹配 {len(pending) if pending else 0} 场比赛\n')

if results:
    print("前5场比赛:")
    for r in results[:5]:
        print(f"  {r['homeTeam']} vs {r['awayTeam']}: {r['homeScore']}-{r['awayScore']}")
