# -*- coding: utf-8 -*-
"""
找出真正需要获取赛果的15场未匹配比赛
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, BjdcMatch, League
from datetime import timedelta, datetime

now = datetime.now()
cutoff_time = now - timedelta(hours=4)

# 获取需要获取赛果的比赛（status=0 且 开赛超过4小时）
matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.status == 0,
    BjdcMatch.match_time < cutoff_time
).all()

print("=" * 100)
print(f"需要获取赛果的 {len(matches)} 场比赛")
print("=" * 100)

for i, m in enumerate(matches, 1):
    home = m.home_team.team_full_name if m.home_team else "?"
    away = m.away_team.team_full_name if m.away_team else "?"
    league_id = m.league_id
    league = localdb.query(League).filter_by(id=league_id).first() if league_id else None
    league_name = league.league_name if league else f"ID:{league_id}"
    
    # 计算应该查询的页面日期（减去10小时）
    page_date = (m.match_time - timedelta(hours=10)).strftime('%Y-%m-%d') if m.match_time else "?"
    match_date = m.match_time.strftime('%Y-%m-%d %H:%M') if m.match_time else "?"
    hours_ago = (now - m.match_time).total_seconds() / 3600
    
    print(f"\n{i}. [{league_name}] {match_date} ({hours_ago:.1f}小时前)")
    print(f"   主队: {home}")
    print(f"   客队: {away}")
    print(f"   Match ID: {m.match_id}")
    print(f"   应查询页面: https://live.500.com/wanchang.php?e={page_date}")

print("\n" + "=" * 100)
