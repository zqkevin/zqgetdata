# -*- coding: utf-8 -*-
"""
找出同一日期的3场待匹配比赛
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, BjdcMatch, League
from datetime import datetime
from collections import defaultdict

# 获取所有待匹配比赛
matches = localdb.query(BjdcMatch).filter_by(status=0).all()

# 按日期分组
matches_by_date = defaultdict(list)
for m in matches:
    if m.match_time:
        date_str = m.match_time.strftime('%Y-%m-%d')
        home = m.home_team.team_full_name if m.home_team else "?"
        away = m.away_team.team_full_name if m.away_team else "?"
        league_id = m.league_id
        league = localdb.query(League).filter_by(id=league_id).first() if league_id else None
        league_name = league.league_name if league else f"ID:{league_id}"
        
        matches_by_date[date_str].append({
            'match_id': m.match_id,
            'home': home,
            'away': away,
            'league': league_name,
            'time': m.match_time.strftime('%H:%M')
        })

print("=" * 80)
print("按日期分组的待匹配比赛")
print("=" * 80)

# 选择第一个有比赛的日期
if matches_by_date:
    first_date = sorted(matches_by_date.keys())[0]
    day_matches = matches_by_date[first_date]
    
    print(f"\n选择日期: {first_date} (共 {len(day_matches)} 场比赛)")
    print("\n前3场比赛:")
    for i, m in enumerate(day_matches[:3], 1):
        print(f"{i}. [{m['league']}] {m['time']} - {m['home']} vs {m['away']}")
    
    print(f"\n应该爬取的网址:")
    url = f"https://live.500.com/wanchang.php?e={first_date}"
    print(f"  {url}")
    
    # 尝试用浏览器打开
    import webbrowser
    print(f"\n正在打开浏览器...")
    webbrowser.open(url)
else:
    print("没有找到待匹配比赛")

print("\n" + "=" * 80)
