"""
检查待匹配比赛的时间分布
"""
from app.database import BjdcMatch, localdb
from datetime import datetime, timedelta

# 查询需要获取赛果的比赛
cutoff_time = datetime.now() - timedelta(hours=4)
pending_matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.match_time < cutoff_time,
    BjdcMatch.status < 3
).all()

print(f"待匹配比赛: {len(pending_matches)} 场\n")

# 按页面日期分组（使用新逻辑）
pending_by_date = {}
for match in pending_matches:
    if match.match_time:
        # 新逻辑：直接使用北京时间判断
        if match.match_time.hour >= 10:
            page_date = (match.match_time.date() + timedelta(days=1)).strftime('%Y-%m-%d')
        else:
            page_date = match.match_time.date().strftime('%Y-%m-%d')
    else:
        page_date = ''
    
    if page_date not in pending_by_date:
        pending_by_date[page_date] = []
    
    pending_by_date[page_date].append(match)

print("按页面日期分组:")
for date in sorted(pending_by_date.keys()):
    matches = pending_by_date[date]
    print(f"\n{date}: {len(matches)} 场")
    
    # 显示前3个比赛的时间
    for match in matches[:3]:
        home_name = match.home_team.team_full_name if match.home_team else '未知'
        away_name = match.away_team.team_full_name if match.away_team else '未知'
        print(f"  {match.match_time} ({match.match_time.hour:02d}:{match.match_time.minute:02d}): {home_name} vs {away_name}")

localdb.close()
