# -*- coding: utf-8 -*-
"""
批量添加 BJDC 队名别名
解决 trade.500.com 和 live.500.com 队名不一致的问题
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, Team, TeamAlias

# 队名映射表：{数据库队名: [网页队名列表]}
team_name_mappings = {
    '卡迪夫城': ['加的夫城'],
    '格里姆斯比': ['格林斯比'],
    '巴兰基亚青年': ['巴兰基利亚青年'],
    '列斯特拉体育': ['利斯特雷'],
}

print("=" * 80)
print("批量添加 BJDC 队名别名")
print("=" * 80)

added_count = 0
for db_name, web_names in team_name_mappings.items():
    # 查找数据库中的球队
    team = localdb.query(Team).filter_by(team_full_name=db_name).first()
    
    if not team:
        print(f"\n❌ 未找到球队: {db_name}")
        continue
    
    print(f"\n球队: {db_name} (ID: {team.id})")
    
    for web_name in web_names:
        # 检查是否已存在该别名
        existing = localdb.query(TeamAlias).filter_by(
            team_id=team.id,
            alias_name=web_name
        ).first()
        
        if existing:
            print(f"  ⚠️  别名已存在: {web_name}")
            continue
        
        # 创建新别名
        alias = TeamAlias(
            team_id=team.id,
            alias_name=web_name,
            source_type='bjdc'
        )
        localdb.add(alias, close=False)
        added_count += 1
        print(f"  ✅ 添加别名: {web_name}")

localdb.session.commit()

print("\n" + "=" * 80)
print(f"共添加 {added_count} 个别名")
print("=" * 80)
