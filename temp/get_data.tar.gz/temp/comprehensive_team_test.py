# -*- coding: utf-8 -*-
"""
全面测试球队名称匹配逻辑
"""
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.common._utils import handle_team_name
from app.database import localdb, Team

print("=" * 80)
print("全面测试球队名称匹配逻辑")
print("=" * 80)

test_results = {
    'pass': 0,
    'fail': 0,
    'skip': 0
}

def test_match(team_name, source_type, expected_full_name, description):
    """测试匹配"""
    print(f"\n测试: {description}")
    print(f"  输入: '{team_name}' (来源:{source_type})")
    print(f"  预期: '{expected_full_name}'")
    
    # 先查找预期球队是否存在
    expected_team = localdb.query(Team).filter_by(team_full_name=expected_full_name).first()
    if not expected_team:
        print(f"  [SKIP] 预期球队不存在于数据库中")
        test_results['skip'] += 1
        return
    
    # 执行匹配
    team = handle_team_name(team_name, source_type=source_type)
    
    if not team:
        print(f"  [FAIL] 未匹配到任何球队，将创建新记录")
        test_results['fail'] += 1
        return
    
    if team.id == expected_team.id:
        print(f"  [PASS] 正确匹配到 ID={team.id}, 全称='{team.team_full_name}'")
        test_results['pass'] += 1
    else:
        print(f"  [FAIL] 错误匹配到 ID={team.id}, 全称='{team.team_full_name}'")
        print(f"         预期 ID={expected_team.id}, 全称='{expected_full_name}'")
        test_results['fail'] += 1

def test_no_match(team_name, source_type, should_not_match_name, description):
    """测试不应该匹配到某支球队"""
    print(f"\n测试: {description}")
    print(f"  输入: '{team_name}' (来源:{source_type})")
    print(f"  预期: 不应该匹配到 '{should_not_match_name}'")
    
    # 查找不应该匹配的球队
    wrong_team = localdb.query(Team).filter_by(team_full_name=should_not_match_name).first()
    if not wrong_team:
        print(f"  [SKIP] 目标球队不存在于数据库中")
        test_results['skip'] += 1
        return
    
    # 执行匹配
    team = handle_team_name(team_name, source_type=source_type)
    
    if not team:
        print(f"  [PASS] 创建了新的球队记录（未匹配到错误球队）")
        test_results['pass'] += 1
    elif team.id != wrong_team.id:
        print(f"  [PASS] 匹配到其他球队: ID={team.id}, 全称='{team.team_full_name}'")
        test_results['pass'] += 1
    else:
        print(f"  [FAIL] 错误地匹配到了 '{team.team_full_name}' (ID:{team.id})")
        test_results['fail'] += 1

print("\n" + "=" * 80)
print("【第一组】应该成功匹配的测试（简称/别名匹配）")
print("=" * 80)

# 测试1: 简称匹配
test_match("拜仁", "tczq", "拜仁慕尼黑", "简称匹配: '拜仁' -> '拜仁慕尼黑'")

# 测试2: 前缀匹配（长度差<=3）
test_match("埃因霍温", "bjdc", "PSV埃因霍温", "后缀匹配: '埃因霍温' -> 'PSV埃因霍温'")

print("\n" + "=" * 80)
print("【第二组】不应该错误匹配的测试（德比对手）")
print("=" * 80)

# 测试3: 曼城 vs 曼联
test_no_match("曼彻斯特城", "tczq", "曼彻斯特联", "德比对手: '曼彻斯特城' 不应匹配 '曼彻斯特联'")

# 测试4: 布拉格斯巴达 vs 布拉格斯拉维亚
test_no_match("布拉格斯巴达", "bjdc", "布拉格斯拉维亚", "德比对手: '布拉格斯巴达' 不应匹配 '布拉格斯拉维亚'")

print("\n" + "=" * 80)
print("测试结果汇总")
print("=" * 80)
print(f"通过: {test_results['pass']}")
print(f"失败: {test_results['fail']}")
print(f"跳过: {test_results['skip']}")
print(f"总计: {test_results['pass'] + test_results['fail'] + test_results['skip']}")

if test_results['fail'] == 0:
    print("\n[SUCCESS] 所有测试通过！")
else:
    print(f"\n[WARNING] 有 {test_results['fail']} 个测试失败，需要修复！")

print("=" * 80)

localdb.close()
