# -*- coding: utf-8 -*-
"""
验证TCZQ赛果API是否返回match_id
"""
import sys
import os
import json

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.common.req_sporttery_api import SportteryAPI

def check_tczq_result_api():
    """检查TCZQ赛果API返回的数据结构"""
    print("=" * 80)
    print("验证TCZQ赛果API返回的match_id")
    print("=" * 80)
    
    api = SportteryAPI()
    
    # 获取最近几天的赛果
    results = api.get_football_match_result(
        match_begin_date='2026-04-28',
        match_end_date='2026-04-30'
    )
    
    print(f"\n总共获取 {len(results)} 条赛果\n")
    
    if not results:
        print("[FAIL] API返回为空")
        return
    
    # 检查前5条记录的字段
    print("前5条赛果的字段示例:")
    for i, result in enumerate(results[:5], 1):
        print(f"\n{i}. matchId: {result.get('matchId')}")
        print(f"   matchNum: {result.get('matchNum')}")
        print(f"   homeTeam: {result.get('homeTeam')}")
        print(f"   allHomeTeam: {result.get('allHomeTeam')}")
        print(f"   awayTeam: {result.get('awayTeam')}")
        print(f"   allAwayTeam: {result.get('allAwayTeam')}")
        print(f"   homeScore: {result.get('homeScore')}")
        print(f"   awayScore: {result.get('awayScore')}")
        print(f"   matchDate: {result.get('matchDate')}")
        print(f"   matchResultStatus: {result.get('matchResultStatus')}")
        
        # 显示所有键
        print(f"   所有字段: {list(result.keys())}")
    
    # 统计match_id的存在情况
    has_match_id_count = sum(1 for r in results if r.get('matchId'))
    print(f"\n{'='*80}")
    print(f"统计结果:")
    print(f"  总记录数: {len(results)}")
    print(f"  有matchId的记录: {has_match_id_count}")
    print(f"  无matchId的记录: {len(results) - has_match_id_count}")
    
    if has_match_id_count > 0:
        print(f"\n[OK] API返回了matchId字段！")
        print(f"     可以用于优先匹配")
    else:
        print(f"\n[FAIL] API没有返回matchId字段")
        print(f"       只能使用队名+时间匹配")

if __name__ == '__main__':
    check_tczq_result_api()
