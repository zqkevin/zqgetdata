"""
查找西雅图海湾人 vs 达拉斯FC的比赛
"""
from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-27'
soup = req_info(url)

# 查找所有 id 以 "a" 开头的 tr
tr_with_id = soup.find_all('tr', id=lambda x: x and x.startswith('a'))

for tr in tr_with_id:
    gy = tr.get('gy', '')
    
    if '西雅图' in gy or '达拉斯' in gy:
        print(f"找到比赛!")
        print(f"  id: {tr.get('id')}")
        print(f"  gy: {gy}")
        
        # 解析 gy 属性
        parts = gy.split(',')
        if len(parts) >= 3:
            league = parts[0]
            home = parts[1]
            away = parts[2]
            print(f"  联赛: {league}")
            print(f"  主队: {home}")
            print(f"  客队: {away}")
