# -*- coding: utf-8 -*-
"""
检查500.com页面的时间范围
"""
import sys
import os
import re

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from bs4 import BeautifulSoup
from app.common._utils import req_info

def check_page_time_range(date_str):
    """检查指定日期页面的比赛时间范围"""
    print(f"\n{'='*80}")
    print(f"检查 {date_str} 页面的比赛时间范围")
    print(f"{'='*80}")
    
    url = f'https://live.500.com/wanchang.php?e={date_str}'
    soup = req_info(url)
    
    if not soup:
        print("[FAIL] 网页请求失败")
        return
    
    # 查找所有tr标签，id以'a'开头的
    tr_list = soup.find_all('tr', id=lambda x: x and x.startswith('a'))
    print(f"找到 {len(tr_list)} 个比赛记录\n")
    
    # 提取前5个和后5个比赛的时间
    times = []
    for tr in tr_list:
        value = tr.get('value', '')
        if value:
            # 提取endTime
            time_match = re.search(r"endTime:'(\d{4}-\d{2}-\d{2} \d{2}:\d{2})'", value)
            if time_match:
                times.append(time_match.group(1))
    
    if times:
        print(f"最早比赛时间: {times[0]}")
        print(f"最晚比赛时间: {times[-1]}")
        print(f"总比赛数: {len(times)}")
        
        # 显示前5个和后5个
        print(f"\n前5个比赛时间:")
        for t in times[:5]:
            print(f"  {t}")
        
        print(f"\n后5个比赛时间:")
        for t in times[-5:]:
            print(f"  {t}")

if __name__ == '__main__':
    check_page_time_range('2026-04-28')
    check_page_time_range('2026-04-29')
