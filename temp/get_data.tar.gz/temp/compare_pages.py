"""
对比 04-26 和 04-27 页面的爬取结果
"""
from app.common._utils import req_info
import requests
from bs4 import BeautifulSoup

# 测试两个页面
dates = ['2026-04-26', '2026-04-27']

for date in dates:
    url = f'https://live.500.com/wanchang.php?e={date}'
    print(f"\n{'='*60}")
    print(f"测试日期: {date}")
    print(f"URL: {url}")
    print('='*60)
    
    # 使用 req_info 爬取
    soup = req_info(url)
    
    if not soup:
        print("❌ 爬取失败")
        continue
    
    html_str = str(soup)
    print(f"HTML 大小: {len(html_str):,} 字符")
    
    # 统计 tr 标签
    all_tr = soup.find_all('tr')
    tr_with_id = soup.find_all('tr', id=True)
    tr_starting_with_a = soup.find_all('tr', id=lambda x: x and x.startswith('a'))
    
    print(f"总 tr 数量: {len(all_tr)}")
    print(f"带 id 的 tr 数量: {len(tr_with_id)}")
    print(f"id以'a'开头的 tr 数量: {len(tr_starting_with_a)}")
    
    # 检查是否有 match_id=1358307
    target_tr = soup.find('tr', id='a1358307')
    if target_tr:
        gy = target_tr.get('gy', '')
        print(f"✓ 找到 a1358307: {gy}")
    else:
        print("❌ 未找到 a1358307")
    
    # 显示前几个比赛的时间范围
    if len(tr_starting_with_a) > 0:
        times = []
        for tr in tr_starting_with_a[:5]:
            time_td = tr.find_all('td')[2] if len(tr.find_all('td')) > 2 else None
            if time_td:
                times.append(time_td.get_text(strip=True))
        
        print(f"前5场比赛时间: {times}")
