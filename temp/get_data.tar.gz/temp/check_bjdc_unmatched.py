# -*- coding: utf-8 -*-
"""
检查BJDC未匹配比赛，获取赛果数据并生成分析报告
"""
import sys
sys.path.insert(0, 'E:\\my_prog\\zqgetdata')

from app.database import localdb, BjdcMatch, League, Team
from app.crawler.bjdc_result import BjdcResultCollector
from datetime import datetime, timedelta
import json

def get_pending_matches():
    """获取需要匹配的BJDC比赛"""
    matches = localdb.query(BjdcMatch).filter(
        BjdcMatch.status == 0,
        BjdcMatch.match_time < datetime.now() - timedelta(hours=4)
    ).order_by(BjdcMatch.match_time.asc()).limit(15).all()
    
    result = []
    for m in matches:
        league = m.league
        home_team = m.home_team
        away_team = m.away_team
        
        result.append({
            'match_id': m.match_id,
            'match_num': m.match_num,
            'match_time': m.match_time.strftime('%Y-%m-%d %H:%M:%S') if m.match_time else None,
            'league_name': league.league_name if league else None,
            'home_team': home_team.team_full_name if home_team else None,
            'away_team': away_team.team_full_name if away_team else None,
            'home_team_id': m.home_team_id,
            'away_team_id': m.away_team_id,
            'league_id': m.league_id
        })
    
    return result

def fetch_results_for_dates(dates):
    """获取指定日期的赛果数据"""
    from app.common._utils import req_info
    collector = BjdcResultCollector()
    all_results = []
    
    for date_str in dates:
        print(f"\n爬取 {date_str} 的赛果...")
        try:
            url = f'https://live.500.com/wanchang.php?e={date_str}'
            soup = req_info(url)
            
            if not soup:
                print(f"  爬取失败")
                continue
            
            results = collector._parse_match_results_from_html(soup, date_str)
            print(f"  获取到 {len(results)} 场比赛")
            all_results.extend(results)
        except Exception as e:
            print(f"  爬取失败: {e}")
            import traceback
            traceback.print_exc()
    
    return all_results

def main():
    print("=" * 100)
    print("BJDC未匹配比赛分析")
    print("=" * 100)
    
    # 1. 获取待匹配比赛
    pending_matches = get_pending_matches()
    print(f"\n找到 {len(pending_matches)} 场待匹配比赛\n")
    
    # 2. 提取需要爬取的日期（注意：BJDC以10点为界）
    dates_to_crawl = set()
    for match in pending_matches:
        if match['match_time']:
            match_dt = datetime.strptime(match['match_time'], '%Y-%m-%d %H:%M:%S')
            # 10点之前的比赛显示在当天页面，10点及之后显示在第二天页面
            if match_dt.hour >= 10:
                page_date = (match_dt.date() + timedelta(days=1)).strftime('%Y-%m-%d')
            else:
                page_date = match_dt.date().strftime('%Y-%m-%d')
            dates_to_crawl.add(page_date)
    
    print(f"需要爬取的日期: {sorted(dates_to_crawl)}\n")
    
    # 3. 爬取赛果数据
    all_results = fetch_results_for_dates(sorted(dates_to_crawl))
    print(f"\n总共获取 {len(all_results)} 条赛果数据")
    
    # 4. 生成分析报告
    report = {
        'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'pending_matches_count': len(pending_matches),
        'crawled_results_count': len(all_results),
        'dates_crawled': sorted(list(dates_to_crawl)),
        'pending_matches': pending_matches,
        'crawled_results': all_results[:50]  # 只保留前50条，避免文件过大
    }
    
    # 保存JSON
    json_file = 'E:\\my_prog\\zqgetdata\\temp\\bjdc_unmatched_analysis.json'
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    
    print(f"\nJSON报告已保存: {json_file}")
    
    # 5. 生成Markdown报告
    md_content = generate_markdown_report(pending_matches, all_results)
    md_file = 'E:\\my_prog\\zqgetdata\\temp\\bjdc_unmatched_analysis.md'
    with open(md_file, 'w', encoding='utf-8') as f:
        f.write(md_content)
    
    print(f"Markdown报告已保存: {md_file}")
    
    localdb.close()

def generate_markdown_report(pending_matches, crawled_results):
    """生成Markdown格式的分析报告"""
    
    lines = []
    lines.append("# BJDC未匹配比赛分析报告\n")
    lines.append(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    lines.append(f"**待匹配比赛数**: {len(pending_matches)}\n")
    lines.append(f"**爬取赛果数**: {len(crawled_results)}\n")
    lines.append("---\n")
    
    lines.append("## 待匹配比赛列表\n")
    lines.append("| 序号 | Match ID | 场次 | 联赛 | 比赛时间 | 主队 | 客队 |\n")
    lines.append("|------|----------|------|------|----------|------|------|\n")
    
    for i, match in enumerate(pending_matches, 1):
        lines.append(
            f"| {i} | {match['match_id']} | {match['match_num']} | "
            f"{match['league_name'] or 'N/A'} | {match['match_time']} | "
            f"{match['home_team']} | {match['away_team']} |\n"
        )
    
    lines.append("\n---\n")
    lines.append("## 爬取的赛果数据（部分）\n")
    lines.append("| 序号 | Match ID | 联赛 | 主队 | 客队 | 比分 | 状态 |\n")
    lines.append("|------|----------|------|------|------|------|------|\n")
    
    for i, result in enumerate(crawled_results[:30], 1):
        home_score = result.get('homeScore', 'N/A')
        away_score = result.get('awayScore', 'N/A')
        score = f"{home_score}-{away_score}" if home_score and away_score else 'N/A'
        
        lines.append(
            f"| {i} | {result.get('matchId', 'N/A')} | "
            f"{result.get('leagueName', 'N/A')} | "
            f"{result.get('homeTeam', 'N/A')} | "
            f"{result.get('awayTeam', 'N/A')} | "
            f"{score} | {result.get('status', 'N/A')} |\n"
        )
    
    lines.append("\n---\n")
    lines.append("## 手动匹配建议\n")
    lines.append("\n请根据以下信息手动查找匹配：\n")
    
    for i, match in enumerate(pending_matches, 1):
        lines.append(f"\n### 比赛 {i}: {match['home_team']} vs {match['away_team']}\n")
        lines.append(f"- **数据库Match ID**: {match['match_id']}\n")
        lines.append(f"- **联赛**: {match['league_name']}\n")
        lines.append(f"- **时间**: {match['match_time']}\n")
        lines.append(f"- **主队**: {match['home_team']} (ID: {match['home_team_id']})\n")
        lines.append(f"- **客队**: {match['away_team']} (ID: {match['away_team_id']})\n")
        
        # 查找可能的匹配
        possible_matches = find_possible_matches(match, crawled_results)
        if possible_matches:
            lines.append(f"\n**可能的匹配结果**:\n")
            for j, pm in enumerate(possible_matches[:3], 1):
                lines.append(f"{j}. Match ID: {pm.get('matchId')}, "
                           f"主队: {pm.get('homeTeam')}, "
                           f"客队: {pm.get('awayTeam')}, "
                           f"比分: {pm.get('homeScore')}-{pm.get('awayScore')}\n")
        else:
            lines.append(f"\n**未找到可能的匹配**\n")
    
    lines.append("\n---\n")
    lines.append("## 下一步操作\n")
    lines.append("1. 检查上述可能的匹配是否正确\n")
    lines.append("2. 如果队名不一致，需要在TeamAlias表中添加别名\n")
    lines.append("3. 或者修改数据库中的队名为标准名称\n")
    
    return ''.join(lines)

def find_possible_matches(db_match, crawled_results):
    """查找可能的匹配结果"""
    possible = []
    
    db_home = db_match['home_team']
    db_away = db_match['away_team']
    db_league = db_match['league_name']
    db_date = db_match['match_time'][:10] if db_match['match_time'] else None
    
    for result in crawled_results:
        score = 0
        
        # 匹配客队名（权重最高）
        if db_away and result.get('awayTeam'):
            if db_away == result['awayTeam']:
                score += 10
            elif db_away in result['awayTeam'] or result['awayTeam'] in db_away:
                score += 5
        
        # 匹配联赛名
        if db_league and result.get('leagueName'):
            if db_league == result['leagueName']:
                score += 3
            elif db_league in result['leagueName'] or result['leagueName'] in db_league:
                score += 2
        
        # 匹配日期
        if db_date and result.get('matchDate'):
            if db_date == result['matchDate']:
                score += 2
        
        if score >= 5:  # 至少客队名完全匹配
            result['match_score'] = score
            possible.append(result)
    
    # 按匹配度排序
    possible.sort(key=lambda x: x.get('match_score', 0), reverse=True)
    return possible

if __name__ == '__main__':
    main()
