"""检查BJDC赛果队名与数据库队名的匹配情况"""
import sys
sys.path.insert(0, 'E:\\my_prog\\zqgetdata\\get_data')

from app.crawler.bjdc_result import BjdcResultCollector
from app.database import localdb, Team, TeamAlias, BjdcMatch
from datetime import datetime

# 获取BJDC赛果
crawler = BjdcResultCollector()
results, pending_matches = crawler.fetch_match_results()

print(f"爬取到 {len(results)} 条赛果")
print(f"待匹配比赛: {len(pending_matches)} 场\n")

if not results:
    print("没有赛果数据")
    sys.exit(1)

# 检查前5条赛果的队名匹配情况
print("=" * 80)
print("检查前5条赛果的队名匹配情况:")
print("=" * 80)

for i, result in enumerate(results[:5], 1):
    home_name = result.get('allHomeTeam') or result.get('homeTeam')
    away_name = result.get('allAwayTeam') or result.get('awayTeam')
    match_date = result.get('matchDate')
    
    print(f"\n{i}. BJDC赛果: {home_name} vs {away_name} ({match_date})")
    
    # 在数据库中查找主队
    home_team = localdb.query(Team).filter(
        (Team.team_full_name == home_name) | 
        (Team.team_short_name == home_name)
    ).first()
    
    if not home_team:
        # 尝试通过别名查找
        alias = localdb.query(TeamAlias).filter_by(alias_name=home_name).first()
        if alias:
            home_team = localdb.query(Team).filter_by(id=alias.team_id).first()
    
    if home_team:
        print(f"   ✓ 主队匹配: {home_team.team_full_name} (ID:{home_team.id})")
    else:
        print(f"   ✗ 主队未匹配: '{home_name}'")
        
        # 查找相似的队名
        similar = localdb.query(Team).filter(
            Team.team_full_name.like(f'%{home_name[:4]}%')
        ).limit(3).all()
        
        if similar:
            print(f"   可能的相似队名:")
            for t in similar:
                print(f"     - {t.team_full_name}")
    
    # 在数据库中查找客队
    away_team = localdb.query(Team).filter(
        (Team.team_full_name == away_name) | 
        (Team.team_short_name == away_name)
    ).first()
    
    if not away_team:
        # 尝试通过别名查找
        alias = localdb.query(TeamAlias).filter_by(alias_name=away_name).first()
        if alias:
            away_team = localdb.query(Team).filter_by(id=alias.team_id).first()
    
    if away_team:
        print(f"   ✓ 客队匹配: {away_team.team_full_name} (ID:{away_team.id})")
    else:
        print(f"   ✗ 客队未匹配: '{away_name}'")
        
        # 查找相似的队名
        similar = localdb.query(Team).filter(
            Team.team_full_name.like(f'%{away_name[:4]}%')
        ).limit(3).all()
        
        if similar:
            print(f"   可能的相似队名:")
            for t in similar:
                print(f"     - {t.team_full_name}")

print("\n" + "=" * 80)
print("检查完成")
print("=" * 80)
