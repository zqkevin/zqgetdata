# -*- coding: utf-8 -*-
"""
找出未匹配的比赛信息
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, BjdcMatch, League
from datetime import timedelta

# 获取所有待匹配比赛（status=0）
matches = localdb.query(BjdcMatch).filter_by(status=0).all()

print("=" * 100)
print("未匹配的 BJDC 比赛列表")
print("=" * 100)

for i, m in enumerate(matches, 1):
    home = m.home_team.team_full_name if m.home_team else "?"
    away = m.away_team.team_full_name if m.away_team else "?"
    league_id = m.league_id
    league = localdb.query(League).filter_by(id=league_id).first() if league_id else None
    league_name = league.league_name if league else f"ID:{league_id}"
    
    # 计算应该查询的页面日期（减去10小时）
    page_date = (m.match_time - timedelta(hours=10)).strftime('%Y-%m-%d') if m.match_time else "?"
    match_date = m.match_time.strftime('%Y-%m-%d %H:%M') if m.match_time else "?"
    
    print(f"\n{i}. [{league_name}] {match_date}")
    print(f"   主队: {home}")
    print(f"   客队: {away}")
    print(f"   Match ID: {m.match_id}")
    print(f"   应查询页面: https://live.500.com/wanchang.php?e={page_date}")
    print(f"   Remark: {m.remark}")

print("\n" + "=" * 100)
print(f"共 {len(matches)} 场未匹配比赛")
print("=" * 100)
