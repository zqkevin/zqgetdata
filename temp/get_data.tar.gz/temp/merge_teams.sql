-- 合并重复的球队记录
-- 1. 巴黎圣日耳曼 (828) -> 巴黎圣日尔曼 (510)
-- 2. 拜仁 (931) -> 拜仁慕尼黑 (689)  
-- 3. 索尔纳 (954) -> AIK索尔纳 (671)

SET FOREIGN_KEY_CHECKS = 0;
START TRANSACTION;

-- 第1步：更新BJDC比赛引用
UPDATE bjdc_match SET home_team_id = 510 WHERE home_team_id = 828;
UPDATE bjdc_match SET away_team_id = 510 WHERE away_team_id = 828;

UPDATE bjdc_match SET home_team_id = 689 WHERE home_team_id = 931;
UPDATE bjdc_match SET away_team_id = 689 WHERE away_team_id = 931;

UPDATE bjdc_match SET home_team_id = 671 WHERE home_team_id = 954;
UPDATE bjdc_match SET away_team_id = 671 WHERE away_team_id = 954;

-- 第2步：更新TCZQ比赛引用
UPDATE tczq_match SET home_team_id = 510 WHERE home_team_id = 828;
UPDATE tczq_match SET away_team_id = 510 WHERE away_team_id = 828;

UPDATE tczq_match SET home_team_id = 689 WHERE home_team_id = 931;
UPDATE tczq_match SET away_team_id = 689 WHERE away_team_id = 931;

UPDATE tczq_match SET home_team_id = 671 WHERE home_team_id = 954;
UPDATE tczq_match SET away_team_id = 671 WHERE away_team_id = 954;

-- 第3步：迁移别名（将remove_id的别名添加到keep_id）
-- 巴黎圣日耳曼 (828) -> 巴黎圣日尔曼 (510)
INSERT INTO team_alias (team_id, alias_name, source_type, is_primary, remark, created_at)
SELECT 510, alias_name, source_type, is_primary, CONCAT(remark, ' [merged from 828]'), NOW()
FROM team_alias WHERE team_id = 828
ON DUPLICATE KEY UPDATE remark = VALUES(remark);

-- 拜仁 (931) -> 拜仁慕尼黑 (689)
INSERT INTO team_alias (team_id, alias_name, source_type, is_primary, remark, created_at)
SELECT 689, alias_name, source_type, is_primary, CONCAT(remark, ' [merged from 931]'), NOW()
FROM team_alias WHERE team_id = 931
ON DUPLICATE KEY UPDATE remark = VALUES(remark);

-- 索尔纳 (954) -> AIK索尔纳 (671)
INSERT INTO team_alias (team_id, alias_name, source_type, is_primary, remark, created_at)
SELECT 671, alias_name, source_type, is_primary, CONCAT(remark, ' [merged from 954]'), NOW()
FROM team_alias WHERE team_id = 954
ON DUPLICATE KEY UPDATE remark = VALUES(remark);

-- 第4步：删除重复的球队记录
DELETE FROM team_alias WHERE team_id IN (828, 931, 954);
DELETE FROM team WHERE id IN (828, 931, 954);

COMMIT;
SET FOREIGN_KEY_CHECKS = 1;

-- 验证结果
SELECT 'Merge completed successfully' as status;
SELECT id, team_full_name FROM team WHERE id IN (510, 689, 671);
