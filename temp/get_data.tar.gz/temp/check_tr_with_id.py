"""
检查带id的tr标签
"""
from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-27'
soup = req_info(url)

if not soup:
    print("❌ 爬取失败")
    exit(1)

# 查找所有 id 以 "a" 开头的 tr
tr_with_id = soup.find_all('tr', id=lambda x: x and x.startswith('a'))
print(f"id以'a'开头的 tr 数量: {len(tr_with_id)}")

if len(tr_with_id) > 0:
    print(f"\n前3个比赛 tr:")
    for i, tr in enumerate(tr_with_id[:3]):
        print(f"\n{i+1}. id={tr.get('id')}")
        
        # 查找主队和客队名称
        home_span = tr.find('span', class_='mainName')
        away_span = tr.find('span', class_='clientName')
        
        if home_span and away_span:
            print(f"   主队: {home_span.get_text(strip=True)}")
            print(f"   客队: {away_span.get_text(strip=True)}")
        else:
            print(f"   ❌ 未找到 mainName/clientName")
            # 输出 tr 的部分内容
            print(f"   HTML片段: {str(tr)[:300]}")
