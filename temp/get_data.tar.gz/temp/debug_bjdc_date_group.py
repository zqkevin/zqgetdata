# -*- coding: utf-8 -*-
"""
调试 BJDC 按日期分组的赛果匹配逻辑
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.crawler.bjdc_result import BjdcResultCollector
from app.database import localdb, BjdcMatch, League
from datetime import datetime
import csv

print("=" * 80)
print("调试 BJDC 按日期分组的赛果匹配")
print("=" * 80)

c = BjdcResultCollector()

# 1. 获取待匹配比赛
print("\n1. 获取待匹配比赛...")
results, pending_matches = c.fetch_match_results()

print(f"   爬取到 {len(results)} 条赛果")
print(f"   待匹配 {len(pending_matches)} 场比赛")

# 2. 按日期分组待匹配比赛（注意：500.com以每天10点为界）
print("\n2. 按日期分组待匹配比赛...")
matches_by_date = {}
for match in pending_matches:
    if match.match_time:
        # 减去10小时，得到应该查询的页面日期
        from datetime import timedelta
        page_date = (match.match_time - timedelta(hours=10)).strftime('%Y-%m-%d')
        if page_date not in matches_by_date:
            matches_by_date[page_date] = []
        
        home_name = match.home_team.team_full_name if match.home_team else '未知'
        away_name = match.away_team.team_full_name if match.away_team else '未知'
        league_id = match.league_id
        league = localdb.query(League).filter_by(id=league_id).first() if league_id else None
        league_name = league.league_name if league else f'ID:{league_id}'
        
        matches_by_date[page_date].append({
            'match_id': match.match_id,
            'home_name': home_name,
            'away_name': away_name,
            'league_name': league_name,
            'match_time': match.match_time.strftime('%Y-%m-%d %H:%M'),
            'original_date': match.match_time.strftime('%Y-%m-%d')
        })

print(f"   共 {len(matches_by_date)} 个日期有比赛")
for date_str in sorted(matches_by_date.keys()):
    print(f"   - {date_str}: {len(matches_by_date[date_str])} 场")

# 3. 保存待匹配比赛到 CSV
csv_path = os.path.join(project_root, 'temp', 'bjdc_pending_matches.csv')
with open(csv_path, 'w', encoding='utf-8-sig', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['页面日期', '比赛时间', '联赛', '主队', '客队', 'Match ID'])
    
    for page_date in sorted(matches_by_date.keys()):
        for match_info in matches_by_date[page_date]:
            writer.writerow([
                page_date,
                match_info['match_time'],
                match_info['league_name'],
                match_info['home_name'],
                match_info['away_name'],
                match_info['match_id']
            ])

print(f"\n   待匹配比赛已保存到: {csv_path}")

# 4. 按日期爬取赛果并匹配
print("\n3. 按日期爬取赛果并匹配...")
all_matched = 0
all_unmatched = 0

for page_date in sorted(matches_by_date.keys()):
    print(f"\n   处理页面日期: {page_date} ({len(matches_by_date[page_date])} 场比赛)")
    
    # 爬取该日期的赛果
    url = f'https://live.500.com/wanchang.php?e={page_date}'
    from app.common._utils import req_info
    soup = req_info(url)
    
    if not soup:
        print(f"      ❌ 爬取失败")
        all_unmatched += len(matches_by_date[page_date])
        continue
    
    # 解析赛果
    day_results = c._parse_match_results_from_html(soup, page_date)
    print(f"      爬取到 {len(day_results)} 条赛果")
    
    # 构建赛果字典（用于快速查找）
    results_dict = {}
    for r in day_results:
        key = (r['homeTeam'], r['awayTeam'])
        results_dict[key] = r
    
    # 匹配
    matched_count = 0
    unmatched_list = []
    
    for match_info in matches_by_date[page_date]:
        home = match_info['home_name']
        away = match_info['away_name']
        
        # 精确匹配
        if (home, away) in results_dict:
            result = results_dict[(home, away)]
            print(f"      ✅ {home} vs {away}: {result['homeScore']}-{result['awayScore']}")
            matched_count += 1
        else:
            print(f"      ❌ {home} vs {away} - 未找到")
            unmatched_list.append(match_info)
    
    all_matched += matched_count
    all_unmatched += len(unmatched_list)
    
    # 保存未匹配的到 CSV
    if unmatched_list:
        unmatched_csv = os.path.join(project_root, 'temp', f'bjdc_unmatched_{page_date}.csv')
        with open(unmatched_csv, 'w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['联赛', '主队', '客队', 'Match ID', '比赛时间'])
            for m in unmatched_list:
                writer.writerow([
                    m['league_name'],
                    m['home_name'],
                    m['away_name'],
                    m['match_id'],
                    m['match_time']
                ])
        print(f"      未匹配 {len(unmatched_list)} 场，已保存到: {unmatched_csv}")

print("\n" + "=" * 80)
print(f"总计: 匹配 {all_matched} 场, 未匹配 {all_unmatched} 场")
print("=" * 80)
