# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.common.req_sporttery_api import SportteryAPI

api = SportteryAPI()
results = api.get_football_match_result(match_begin_date='2026-04-28', match_end_date='2026-04-30')

target_ids = [2039369, 2039404]
found = [r for r in results if r.get('matchId') in target_ids]

print(f'Total results: {len(results)}')
print(f'Found: {len(found)}')

for r in found:
    print(f'matchId={r["matchId"]}: {r["allHomeTeam"]} vs {r["allAwayTeam"]}, score={r["homeScore"]}-{r["awayScore"]}')
