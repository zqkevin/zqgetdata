"""
检查 BJDC 爬取结果中的 matchId 格式
"""
from app.crawler.bjdc_result import BjdcResultCollector
from app.common._utils import req_info
from datetime import datetime, timedelta

collector = BjdcResultCollector()

# 爬取 2026-04-25 的赛果
date_str = '2026-04-25'
url = f'https://live.500.com/wanchang.php?e={date_str}'
soup = req_info(url)

if soup:
    results = collector._parse_match_results_from_html(soup, date_str)
    print(f"{date_str}: 爬取到 {len(results)} 场比赛\n")
    
    # 显示前10个 matchId
    print("前10个 matchId:")
    for i, result in enumerate(results[:10]):
        match_id = result.get('matchId', '')
        home_team = result.get('homeTeam', '')
        away_team = result.get('awayTeam', '')
        print(f"  {i+1}. matchId='{match_id}' (type={type(match_id).__name__}): {home_team} vs {away_team}")
else:
    print(f"爬取 {date_str} 失败")
