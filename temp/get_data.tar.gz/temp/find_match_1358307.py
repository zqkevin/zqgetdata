"""
查找 match_id=1358307 的比赛
"""
from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-27'
soup = req_info(url)

# 查找 id="a1358307" 的 tr
tr = soup.find('tr', id='a1358307')

if tr:
    print(f"找到比赛 a1358307!")
    gy = tr.get('gy', '')
    print(f"  gy: {gy}")
    
    # 解析 gy 属性
    parts = gy.split(',')
    if len(parts) >= 3:
        league = parts[0]
        home = parts[1]
        away = parts[2]
        print(f"  联赛: {league}")
        print(f"  主队: {home}")
        print(f"  客队: {away}")
else:
    print("❌ 未找到 id=a1358307 的比赛")
    
    # 列出所有包含"海湾人"或"达拉斯FC"的比赛
    print("\n搜索包含'海湾人'或'达拉斯FC'的比赛:")
    tr_with_id = soup.find_all('tr', id=lambda x: x and x.startswith('a'))
    for tr in tr_with_id:
        gy = tr.get('gy', '')
        if '海湾人' in gy or '达拉斯FC' in gy:
            print(f"  id={tr.get('id')}, gy={gy}")
