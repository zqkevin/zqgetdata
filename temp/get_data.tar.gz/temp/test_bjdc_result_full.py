# -*- coding: utf-8 -*-
"""
测试 BJDC 赛果爬虫和保存功能
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.crawler.bjdc_result import BjdcResultCollector

print("=" * 80)
print("测试 BJDC 赛果爬虫和保存功能")
print("=" * 80)

c = BjdcResultCollector()

# 1. 获取赛果
print("\n1. 爬取赛果数据...")
results, pending_matches = c.fetch_match_results()

print(f"   爬取到 {len(results)} 条赛果")
print(f"   待匹配 {len(pending_matches)} 场比赛")

if results:
    print(f"\n   前3条赛果示例:")
    for i, r in enumerate(results[:3], 1):
        print(f"   {i}. {r['homeTeam']} vs {r['awayTeam']}: {r['homeScore']}-{r['awayScore']}")
        print(f"      半场: {r['halfHomeScore']}-{r['halfAwayScore']}, 状态: {r['status']}")
        print(f"      字段: {list(r.keys())}")

# 2. 保存赛果
if pending_matches and results:
    print(f"\n2. 保存赛果到数据库...")
    saved_count = c.save_results_to_db(results, pending_matches)
    print(f"   成功保存 {saved_count} 条赛果记录")
else:
    print("\n2. 跳过保存（没有待匹配比赛或赛果）")

print("\n" + "=" * 80)
print("测试完成")
print("=" * 80)
