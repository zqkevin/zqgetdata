# -*- coding: utf-8 -*-
"""
调试 BJDC 赛果匹配问题
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, BjdcMatch, League, Team, TeamAlias
from datetime import timedelta, datetime

now = datetime.now()
cutoff_time = now - timedelta(hours=4)

# 获取需要获取赛果的比赛
matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.status == 0,
    BjdcMatch.match_time < cutoff_time
).all()

print("=" * 100)
print(f"需要获取赛果的 {len(matches)} 场比赛")
print("=" * 100)

for i, m in enumerate(matches[:3], 1):  # 只看前3场
    home = m.home_team.team_full_name if m.home_team else "?"
    away = m.away_team.team_full_name if m.away_team else "?"
    
    # 计算页面日期
    page_date = (m.match_time - timedelta(hours=10)).strftime('%Y-%m-%d') if m.match_time else "?"
    match_date = m.match_time.strftime('%Y-%m-%d %H:%M') if m.match_time else "?"
    
    print(f"\n{i}. [{home} vs {away}]")
    print(f"   比赛时间: {match_date}")
    print(f"   页面日期: {page_date}")
    print(f"   Match ID: {m.match_id}")
    
    # 检查是否有别名
    if m.home_team:
        aliases = localdb.query(TeamAlias).filter_by(team_id=m.home_team.id).all()
        if aliases:
            print(f"   主队别名: {[a.alias_name for a in aliases]}")
    
    if m.away_team:
        aliases = localdb.query(TeamAlias).filter_by(team_id=m.away_team.id).all()
        if aliases:
            print(f"   客队别名: {[a.alias_name for a in aliases]}")

print("\n" + "=" * 100)
