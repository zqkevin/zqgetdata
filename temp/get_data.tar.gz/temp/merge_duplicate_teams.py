# -*- coding: utf-8 -*-
"""
合并重复的球队记录

需要合并的球队：
1. 巴黎圣日尔曼 (ID 510) <- 巴黎圣日耳曼 (ID 828)
2. 拜仁慕尼黑 (ID 689) <- 拜仁 (ID 931)
3. AIK索尔纳 (ID 671) <- 索尔纳 (ID 954)
"""
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.database import localdb, Team, TeamAlias, BjdcMatch, TczqMatch

def merge_teams(keep_id, remove_id, keep_name, remove_name):
    """
    合并两支球队记录
    
    Args:
        keep_id: 保留的球队ID
        remove_id: 要删除的球队ID
        keep_name: 保留的球队名称
        remove_name: 要删除的球队名称
    """
    print(f"\n合并球队: {remove_name} (ID={remove_id}) -> {keep_name} (ID={keep_id})")
    print("-" * 80)
    
    # 1. 更新BJDC比赛中的引用（使用原生SQL避免外键约束问题）
    from sqlalchemy import text
    
    bjdc_home_count = localdb.session.execute(
        text("SELECT COUNT(*) FROM bjdc_match WHERE home_team_id = :remove_id"),
        {"remove_id": remove_id}
    ).scalar()
    
    bjdc_away_count = localdb.session.execute(
        text("SELECT COUNT(*) FROM bjdc_match WHERE away_team_id = :remove_id"),
        {"remove_id": remove_id}
    ).scalar()
    
    bjdc_count = bjdc_home_count + bjdc_away_count
    
    if bjdc_count > 0:
        localdb.session.execute(
            text("UPDATE bjdc_match SET home_team_id = :keep_id WHERE home_team_id = :remove_id"),
            {"keep_id": keep_id, "remove_id": remove_id}
        )
        localdb.session.execute(
            text("UPDATE bjdc_match SET away_team_id = :keep_id WHERE away_team_id = :remove_id"),
            {"keep_id": keep_id, "remove_id": remove_id}
        )
        print(f"  更新BJDC比赛: {bjdc_count} 场")
    
    # 2. 更新TCZQ比赛中的引用（使用原生SQL）
    tczq_home_count = localdb.session.execute(
        text("SELECT COUNT(*) FROM tczq_match WHERE home_team_id = :remove_id"),
        {"remove_id": remove_id}
    ).scalar()
    
    tczq_away_count = localdb.session.execute(
        text("SELECT COUNT(*) FROM tczq_match WHERE away_team_id = :remove_id"),
        {"remove_id": remove_id}
    ).scalar()
    
    tczq_count = tczq_home_count + tczq_away_count
    
    if tczq_count > 0:
        localdb.session.execute(
            text("UPDATE tczq_match SET home_team_id = :keep_id WHERE home_team_id = :remove_id"),
            {"keep_id": keep_id, "remove_id": remove_id}
        )
        localdb.session.execute(
            text("UPDATE tczq_match SET away_team_id = :keep_id WHERE away_team_id = :remove_id"),
            {"keep_id": keep_id, "remove_id": remove_id}
        )
        print(f"  更新TCZQ比赛: {tczq_count} 场")
    
    # 3. 迁移别名
    aliases = localdb.query(TeamAlias).filter_by(team_id=remove_id).all()
    alias_count = 0
    for alias in aliases:
        # 检查是否已存在相同的别名
        existing = localdb.query(TeamAlias).filter_by(
            team_id=keep_id,
            source_type=alias.source_type,
            alias_name=alias.alias_name
        ).first()
        
        if not existing:
            alias.team_id = keep_id
            alias_count += 1
    
    if alias_count > 0:
        print(f"  迁移别名: {alias_count} 个")
    
    # 4. 删除重复的球队记录
    remove_team = localdb.query(Team).filter_by(id=remove_id).first()
    if remove_team:
        localdb.delete(remove_team, close=False)
        print(f"  删除球队记录: ID={remove_id}, name={remove_name}")
    
    localdb.commit()
    print(f"  [OK] 合并完成")

def main():
    print("=" * 80)
    print("合并重复的球队记录")
    print("=" * 80)
    
    # 确认操作
    print("\n将要执行以下合并操作:")
    print("  1. 巴黎圣日耳曼 (828) -> 巴黎圣日尔曼 (510)")
    print("  2. 拜仁 (931) -> 拜仁慕尼黑 (689)")
    print("  3. 索尔纳 (954) -> AIK索尔纳 (671)")
    
    confirm = input("\n是否继续？(yes/no): ")
    if confirm.lower() != 'yes':
        print("取消操作")
        return
    
    try:
        # 执行合并
        merge_teams(510, 828, "巴黎圣日尔曼", "巴黎圣日耳曼")
        merge_teams(689, 931, "拜仁慕尼黑", "拜仁")
        merge_teams(671, 954, "AIK索尔纳", "索尔纳")
        
        print("\n" + "=" * 80)
        print("所有合并操作完成！")
        print("=" * 80)
        
    except Exception as e:
        print(f"\n[ERROR] 合并失败: {e}")
        import traceback
        traceback.print_exc()
        localdb.rollback()
    finally:
        localdb.close()

if __name__ == '__main__':
    main()
