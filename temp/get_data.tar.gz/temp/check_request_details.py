"""
检查 req_info 的请求细节
"""
import requests
from app.common._utils import generate_random_cookies

# 检查 04-26 和 04-27 的 Cookie 是否相同
cookies_26 = generate_random_cookies('500')
cookies_27 = generate_random_cookies('500')

print("Cookie 对比:")
print(f"04-26 Cookie 数量: {len(cookies_26)}")
print(f"04-27 Cookie 数量: {len(cookies_27)}")

# 检查关键 Cookie 是否相同
key_cookies = ['H_PS_PSSID', 'BAIDUID', 'PHPSESSID']
for key in key_cookies:
    val_26 = cookies_26.get(key, 'N/A')
    val_27 = cookies_27.get(key, 'N/A')
    print(f"{key}:")
    print(f"  04-26: {val_26[:30]}..." if len(val_26) > 30 else f"  04-26: {val_26}")
    print(f"  04-27: {val_27[:30]}..." if len(val_27) > 30 else f"  04-27: {val_27}")
    print(f"  相同: {val_26 == val_27}")

# 实际请求测试
print("\n" + "="*60)
print("实际请求测试")
print("="*60)

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                  'AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/80.0.3987.149 Safari/537.36'
}

# 测试 04-26
url_26 = 'https://live.500.com/wanchang.php?e=2026-04-26'
response_26 = requests.get(url=url_26, headers=headers, cookies=cookies_26, timeout=15)
print(f"\n04-26 响应:")
print(f"  状态码: {response_26.status_code}")
print(f"  内容长度: {len(response_26.text)} 字符")
print(f"  编码: {response_26.encoding}")

# 测试 04-27
url_27 = 'https://live.500.com/wanchang.php?e=2026-04-27'
response_27 = requests.get(url=url_27, headers=headers, cookies=cookies_27, timeout=15)
print(f"\n04-27 响应:")
print(f"  状态码: {response_27.status_code}")
print(f"  内容长度: {len(response_27.text)} 字符")
print(f"  编码: {response_27.encoding}")

# 检查是否包含特定内容
if 'a1358307' in response_26.text:
    print(f"\n✓ 04-26 包含 a1358307")
else:
    print(f"\n❌ 04-26 不包含 a1358307")

if 'a1358307' in response_27.text:
    print(f"✓ 04-27 包含 a1358307")
else:
    print(f"❌ 04-27 不包含 a1358307")
