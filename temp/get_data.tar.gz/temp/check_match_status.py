"""
检查 match_id=1358307 是否在 BJDC 赛果中应该存在
"""
from app.database import BjdcMatch, League, localdb
from datetime import datetime, timedelta

match = localdb.query(BjdcMatch).filter_by(match_id=1358307).first()

if not match:
    print("未找到比赛")
    exit(1)

# 获取联赛信息
league = localdb.query(League).filter_by(id=match.league_id).first()
league_name = league.league_name if league else '未知'

home_team = match.home_team
away_team = match.away_team

print("="*60)
print("比赛信息:")
print("="*60)
print(f"match_id: {match.match_id}")
print(f"联赛: {league_name}")
print(f"主队: {home_team.team_full_name if home_team else '未知'}")
print(f"客队: {away_team.team_full_name if away_team else '未知'}")
print(f"比赛时间: {match.match_time}")
print(f"期数: {match.issue}")
print(f"场次: {match.match_num_str}")
print(f"状态: {match.status}")

# 检查当前时间
now = datetime.now()
hours_since_match = (now - match.match_time).total_seconds() / 3600

print(f"\n当前时间: {now}")
print(f"距离比赛已过去: {hours_since_match:.1f} 小时")

if hours_since_match < 4:
    print(f"⚠️ 比赛结束不足4小时，不应该获取赛果")
else:
    print(f"✓ 比赛已结束超过4小时，应该获取赛果")

localdb.close()
