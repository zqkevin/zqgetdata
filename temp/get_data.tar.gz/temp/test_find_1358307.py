"""
测试是否能找到 match_id=1358307
"""
from app.crawler.bjdc_result import BjdcResultCollector
from app.common._utils import req_info

url = 'https://live.500.com/wanchang.php?e=2026-04-27'
soup = req_info(url)

collector = BjdcResultCollector()
results = collector._parse_match_results_from_html(soup, '2026-04-27')

print(f"总共解析到 {len(results)} 场比赛\n")

# 查找 match_id=1358307
target_match = None
for result in results:
    if result['matchId'] == '1358307':
        target_match = result
        break

if target_match:
    print("✓ 找到 match_id=1358307!")
    print(f"  联赛: {target_match['leagueName']}")
    print(f"  主队: {target_match['homeTeam']}")
    print(f"  客队: {target_match['awayTeam']}")
    print(f"  时间: {target_match['matchTime']}")
    print(f"  比分: {target_match['homeScore']}-{target_match['awayScore']}")
else:
    print("❌ 未找到 match_id=1358307")
    
    # 显示所有包含"西雅图"或"达拉斯"的比赛
    print("\n包含'西雅图'或'达拉斯'的比赛:")
    for result in results:
        if '西雅图' in result['homeTeam'] or '西雅图' in result['awayTeam'] or \
           '达拉斯' in result['homeTeam'] or '达拉斯' in result['awayTeam']:
            print(f"  matchId={result['matchId']}: {result['homeTeam']} vs {result['awayTeam']}")
