# -*- coding: utf-8 -*-
"""诊断 BJDC 赛果匹配问题"""
import sys
import os
import json
from datetime import timedelta, datetime

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from app.database import localdb, BjdcMatch
from app.common._utils import req_info
from app.crawler.bjdc_result import BjdcResultCollector

def diagnose_bjdc_matching():
    """诊断 BJDC 赛果匹配问题"""
    
    print("=" * 100)
    print("BJDC 赛果匹配诊断")
    print("=" * 100)
    
    # 1. 查询待获取赛果的比赛
    cutoff_time = datetime.now() - timedelta(hours=4)
    pending_matches = localdb.query(BjdcMatch).filter(
        BjdcMatch.match_time < cutoff_time,
        BjdcMatch.status < 3
    ).all()
    
    print(f"\n【步骤1】待获取赛果的比赛数量: {len(pending_matches)} 场")
    
    if not pending_matches:
        print("没有需要获取赛果的比赛")
        return
    
    # 2. 统计待获取比赛的页面日期分布
    page_dates = set()
    for m in pending_matches:
        if m.match_time:
            utc_time = m.match_time - timedelta(hours=8)
            if utc_time.hour < 10:
                pd = utc_time.date() - timedelta(days=1)
            else:
                pd = utc_time.date()
            page_dates.add(pd)
    
    print(f"\n【步骤2】需要爬取的页面日期: {sorted(page_dates)}")
    
    # 3. 爬取网页数据并保存为 JSON
    collector = BjdcResultCollector()
    all_crawled_results = []
    
    for match_date in sorted(page_dates):
        date_str = match_date.strftime('%Y-%m-%d')
        print(f"\n【步骤3】爬取 {date_str} 的赛果...")
        
        url = f'https://live.500.com/wanchang.php?e={date_str}'
        soup = req_info(url)
        
        if not soup:
            print(f"  ❌ 爬取 {date_str} 失败")
            continue
        
        day_results = collector._parse_match_results_from_html(soup, date_str)
        all_crawled_results.extend(day_results)
        print(f"  ✅ 爬取到 {len(day_results)} 场比赛")
    
    print(f"\n【步骤4】总共爬取到 {len(all_crawled_results)} 条比赛结果")
    
    # 4. 保存爬取结果为 JSON
    crawled_json_path = os.path.join(project_root, 'temp', 'bjdc_crawled_results.json')
    with open(crawled_json_path, 'w', encoding='utf-8') as f:
        json.dump(all_crawled_results, f, ensure_ascii=False, indent=2)
    print(f"  💾 爬取结果已保存到: {crawled_json_path}")
    
    # 5. 分析爬取结果的 match_id 范围
    crawled_match_ids = set()
    for result in all_crawled_results:
        try:
            match_id = int(result.get('matchId', 0))
            if match_id > 0:
                crawled_match_ids.add(match_id)
        except:
            pass
    
    print(f"\n【步骤5】爬取结果中的 match_id 统计:")
    if crawled_match_ids:
        print(f"  最小 match_id: {min(crawled_match_ids)}")
        print(f"  最大 match_id: {max(crawled_match_ids)}")
        print(f"  唯一 match_id 数量: {len(crawled_match_ids)}")
    
    # 6. 分析待获取比赛的 match_id
    pending_match_ids = set()
    for m in pending_matches:
        if m.match_id:
            pending_match_ids.add(m.match_id)
    
    print(f"\n【步骤6】待获取比赛的 match_id 统计:")
    if pending_match_ids:
        print(f"  最小 match_id: {min(pending_match_ids)}")
        print(f"  最大 match_id: {max(pending_match_ids)}")
        print(f"  唯一 match_id 数量: {len(pending_match_ids)}")
    
    # 7. 检查 match_id 是否有交集
    matched_ids = crawled_match_ids & pending_match_ids
    print(f"\n【步骤7】match_id 匹配情况:")
    print(f"  交集数量: {len(matched_ids)}")
    if matched_ids:
        print(f"  示例 match_id: {list(matched_ids)[:10]}")
    else:
        print(f"  ❌ 没有 match_id 匹配！")
    
    # 8. 检查前10个待获取比赛的详细信息
    print(f"\n【步骤8】前10个待获取比赛的详细信息:")
    print(f"{'Match ID':<12} {'比赛时间(UTC)':<22} {'北京时间':<22} {'主队':<15} {'客队':<15} {'页面日期'}")
    print("-" * 100)
    
    for i, m in enumerate(pending_matches[:10]):
        if m.match_time:
            utc_time = m.match_time - timedelta(hours=8)
            beijing_time = m.match_time
            
            # 计算页面日期
            if utc_time.hour < 10:
                page_date = (utc_time.date() - timedelta(days=1)).strftime('%Y-%m-%d')
            else:
                page_date = utc_time.date().strftime('%Y-%m-%d')
            
            home_name = m.home_team.team_full_name if m.home_team else 'N/A'
            away_name = m.away_team.team_full_name if m.away_team else 'N/A'
            
            print(f"{m.match_id:<12} {str(utc_time):<22} {str(beijing_time):<22} {home_name:<15} {away_name:<15} {page_date}")
    
    # 9. 检查爬取结果中是否有这些 match_id
    print(f"\n【步骤9】检查前10个待获取比赛是否在爬取结果中:")
    for i, m in enumerate(pending_matches[:10]):
        if m.match_id in crawled_match_ids:
            print(f"  ✅ Match ID {m.match_id}: 在爬取结果中找到")
        else:
            print(f"  ❌ Match ID {m.match_id}: 未在爬取结果中找到")
    
    # 10. 保存待获取比赛信息
    pending_json_path = os.path.join(project_root, 'temp', 'bjdc_pending_matches.json')
    pending_data = []
    for m in pending_matches[:20]:  # 只保存前20个
        pending_data.append({
            'match_id': m.match_id,
            'match_time_utc': str(m.match_time - timedelta(hours=8)),
            'match_time_beijing': str(m.match_time),
            'home_team': m.home_team.team_full_name if m.home_team else None,
            'away_team': m.away_team.team_full_name if m.away_team else None,
            'status': m.status
        })
    
    with open(pending_json_path, 'w', encoding='utf-8') as f:
        json.dump(pending_data, f, ensure_ascii=False, indent=2)
    print(f"\n💾 待获取比赛信息已保存到: {pending_json_path}")
    
    print("\n" + "=" * 100)
    print("诊断完成！请检查上述输出和保存的 JSON 文件")
    print("=" * 100)

if __name__ == '__main__':
    diagnose_bjdc_matching()
