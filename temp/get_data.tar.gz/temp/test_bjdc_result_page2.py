# -*- coding: utf-8 -*-
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.common._utils import req_info

# 获取页面
soup = req_info('https://live.500.com/wanchang.php?e=2026-04-14')

if not soup:
    print("Failed to fetch page")
    sys.exit(1)

# 查找所有包含"比分"或"完场"的元素
print("查找包含比赛信息的元素...\n")

# 查找所有 div
divs = soup.find_all('div', id=True)
print(f"找到 {len(divs)} 个带 ID 的 div")

for div in divs[:10]:
    div_id = div.get('id', '')
    if 'match' in div_id.lower() or 'game' in div_id.lower() or 'list' in div_id.lower():
        print(f"  - {div_id}")

# 查找 tbody（类似 bjdc.py 中的方式）
tbodys = soup.find_all('tbody', id=True)
print(f"\n找到 {len(tbodys)} 个带 ID 的 tbody")

for tbody in tbodys[:5]:
    tbody_id = tbody.get('id', '')
    print(f"  - {tbody_id}")
    
    # 查看第一行
    first_tr = tbody.find('tr')
    if first_tr:
        cells = first_tr.find_all(['td', 'th'])
        cell_texts = [cell.get_text(strip=True)[:50] for cell in cells[:8]]
        print(f"    第一行: {' | '.join(cell_texts)}")
