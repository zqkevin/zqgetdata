# -*- coding: utf-8 -*-
"""通过队名匹配检查爬取结果"""
import json

# 加载爬取结果
with open('temp/bjdc_crawled_results.json', 'r', encoding='utf-8') as f:
    crawled_data = json.load(f)

# 待获取的比赛（前10个）
pending_teams = [
    ('西雅图海湾人', '达拉斯FC'),
    ('温哥华白浪', '科罗拉多急流'),
    ('墨西哥美洲', '阿特拉斯'),
    ('华雷斯', '圣路易斯竞技'),
    ('全北现代', '浦项铁人'),
]

print("=" * 100)
print("通过队名匹配检查")
print("=" * 100)

for home, away in pending_teams:
    print(f"\n查找: {home} vs {away}")
    
    # 在爬取结果中查找
    matched = []
    for m in crawled_data:
        crawled_home = m.get('homeTeam', '')
        crawled_away = m.get('awayTeam', '')
        
        # 模糊匹配
        if (home in crawled_home or crawled_home in home) and (away in crawled_away or crawled_away in away):
            matched.append(m)
    
    if matched:
        print(f"  ✅ 找到 {len(matched)} 场匹配:")
        for m in matched[:3]:
            print(f"     Match ID: {m['matchId']}, {m['homeTeam']} vs {m['awayTeam']}, Time: {m.get('matchTime')}")
    else:
        print(f"  ❌ 未找到匹配")

# 统计爬取结果的日期分布
print("\n" + "=" * 100)
print("爬取结果的日期分布")
print("=" * 100)

date_counts = {}
for m in crawled_data:
    date_str = m.get('matchDate', 'N/A')
    if date_str not in date_counts:
        date_counts[date_str] = 0
    date_counts[date_str] += 1

for date_str in sorted(date_counts.keys()):
    print(f"{date_str}: {date_counts[date_str]} 场")
