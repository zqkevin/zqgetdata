# -*- coding: utf-8 -*-
"""
检查 BJDC 比赛和爬取赛果的联赛差异
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.crawler.bjdc_result import BjdcResultCollector
from app.database import localdb, BjdcMatch, League

print("=" * 80)
print("检查 BJDC 比赛和爬取赛果的联赛")
print("=" * 80)

c = BjdcResultCollector()

# 1. 获取数据
print("\n1. 获取数据...")
results, pending_matches = c.fetch_match_results()

# 2. 查看待匹配比赛的联赛
if pending_matches:
    print(f"\n2. 待匹配比赛的联赛分布:")
    league_counts = {}
    for match in pending_matches:
        league_id = match.league_id
        if league_id:
            league = localdb.query(League).filter_by(id=league_id).first()
            league_name = league.league_name if league else f'ID:{league_id}'
            league_counts[league_name] = league_counts.get(league_name, 0) + 1
    
    for league_name, count in sorted(league_counts.items(), key=lambda x: x[1], reverse=True):
        print(f"   {league_name}: {count} 场")
    
    # 显示前3场比赛的详细信息
    print(f"\n3. 待匹配比赛详情（前3场）:")
    for i, match in enumerate(pending_matches[:3], 1):
        home_name = match.home_team.team_full_name if match.home_team else '未知'
        away_name = match.away_team.team_full_name if match.away_team else '未知'
        match_date = match.match_time.strftime('%Y-%m-%d') if match.match_time else '未知'
        league_id = match.league_id
        league = localdb.query(League).filter_by(id=league_id).first() if league_id else None
        league_name = league.league_name if league else f'ID:{league_id}'
        
        print(f"   {i}. [{league_name}] {match_date} | {home_name} vs {away_name}")

# 4. 查看爬取赛果的联赛分布
if results:
    print(f"\n4. 爬取赛果的联赛分布（前10个）:")
    league_counts_api = {}
    for r in results:
        league_name = r.get('leagueName', '未知')
        league_counts_api[league_name] = league_counts_api.get(league_name, 0) + 1
    
    for league_name, count in sorted(league_counts_api.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"   {league_name}: {count} 场")

print("\n" + "=" * 80)
