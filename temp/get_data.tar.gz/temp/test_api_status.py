# -*- coding: utf-8 -*-
"""
测试API返回的赛果数据结构，特别是status字段
"""
from app.common.req_sporttery_api import SportteryAPI
from datetime import datetime, timedelta
import json

def test_football_result():
    """测试足球赛果API"""
    api = SportteryAPI()
    
    # 获取最近7天的赛果
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    
    print("=" * 80)
    print("测试足球赛果API")
    print("=" * 80)
    
    results = api.get_football_match_result(
        match_begin_date=start_date.strftime('%Y-%m-%d'),
        match_end_date=end_date.strftime('%Y-%m-%d')
    )
    
    if not results:
        print("未获取到数据")
        return
    
    print(f"\n获取到 {len(results)} 条赛果记录\n")
    
    # 分析status字段的值
    status_values = {}
    result_status_values = {}
    match_result_status_values = {}
    
    for i, result in enumerate(results[:10]):  # 只查看前10条
        print(f"--- 赛果 {i+1} ---")
        print(f"比赛: {result.get('homeTeam')} vs {result.get('awayTeam')}")
        print(f"比分: {result.get('homeScore')}-{result.get('awayScore')}")
        
        # 检查各种状态字段
        status = result.get('status')
        result_status = result.get('resultStatus')
        match_result_status = result.get('matchResultStatus')
        
        print(f"status: {status} (类型: {type(status).__name__})")
        print(f"resultStatus: {result_status}")
        print(f"matchResultStatus: {match_result_status}")
        
        # 统计所有可能的值
        if status is not None:
            status_values[status] = status_values.get(status, 0) + 1
        if result_status:
            result_status_values[result_status] = result_status_values.get(result_status, 0) + 1
        if match_result_status:
            match_result_status_values[match_result_status] = match_result_status_values.get(match_result_status, 0) + 1
        
        print()
    
    print("\n" + "=" * 80)
    print("状态值统计（全部数据）")
    print("=" * 80)
    print(f"\nstatus 字段的所有值:")
    for value, count in sorted(status_values.items()):
        print(f"  {value!r}: {count} 次")
    
    print(f"\nresultStatus 字段的所有值:")
    for value, count in sorted(result_status_values.items()):
        print(f"  {value!r}: {count} 次")
    
    print(f"\nmatchResultStatus 字段的所有值:")
    for value, count in sorted(match_result_status_values.items()):
        print(f"  {value!r}: {count} 次")


def test_basketball_result():
    """测试篮球赛果API"""
    api = SportteryAPI()
    
    # 获取最近7天的赛果
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    
    print("\n" + "=" * 80)
    print("测试篮球赛果API")
    print("=" * 80)
    
    results = api.get_basketball_match_results(
        match_begin_date=start_date.strftime('%Y-%m-%d'),
        match_end_date=end_date.strftime('%Y-%m-%d')
    )
    
    if not results:
        print("未获取到数据")
        return
    
    print(f"\n获取到 {len(results)} 条赛果记录\n")
    
    # 分析status字段的值
    status_values = {}
    result_status_values = {}
    match_result_status_values = {}
    pool_status_values = {}
    
    for i, result in enumerate(results[:10]):  # 只查看前10条
        print(f"--- 赛果 {i+1} ---")
        print(f"比赛: {result.get('homeTeam')} vs {result.get('awayTeam')}")
        print(f"比分: {result.get('homeScore')}-{result.get('awayScore')}")
        
        # 检查各种状态字段
        status = result.get('status')
        result_status = result.get('resultStatus')
        match_result_status = result.get('matchResultStatus')
        pool_status = result.get('poolStatus')
        
        print(f"status: {status} (类型: {type(status).__name__})")
        print(f"resultStatus: {result_status}")
        print(f"matchResultStatus: {match_result_status}")
        print(f"poolStatus: {pool_status}")
        
        # 统计所有可能的值
        if status is not None:
            status_values[status] = status_values.get(status, 0) + 1
        if result_status:
            result_status_values[result_status] = result_status_values.get(result_status, 0) + 1
        if match_result_status:
            match_result_status_values[match_result_status] = match_result_status_values.get(match_result_status, 0) + 1
        if pool_status:
            pool_status_values[pool_status] = pool_status_values.get(pool_status, 0) + 1
        
        print()
    
    print("\n" + "=" * 80)
    print("状态值统计（全部数据）")
    print("=" * 80)
    print(f"\nstatus 字段的所有值:")
    for value, count in sorted(status_values.items()):
        print(f"  {value!r}: {count} 次")
    
    print(f"\nresultStatus 字段的所有值:")
    for value, count in sorted(result_status_values.items()):
        print(f"  {value!r}: {count} 次")
    
    print(f"\nmatchResultStatus 字段的所有值:")
    for value, count in sorted(match_result_status_values.items()):
        print(f"  {value!r}: {count} 次")
    
    print(f"\npoolStatus 字段的所有值:")
    for value, count in sorted(pool_status_values.items()):
        print(f"  {value!r}: {count} 次")


if __name__ == '__main__':
    test_football_result()
    test_basketball_result()
