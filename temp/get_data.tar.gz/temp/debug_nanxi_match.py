# -*- coding: utf-8 -*-
"""调试南锡 vs 阿讷西比赛的HTML解析"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.common._utils import req_info
from bs4 import BeautifulSoup

# 爬取网页
url = 'https://live.500.com/wanchang.php?e=2026-04-18'
print(f'爬取: {url}\n')

soup = req_info(url)
if not soup:
    print('爬取失败！')
    sys.exit(1)

# 查找所有包含"南锡"的比赛
home_names = soup.find_all('span', class_='mainName')
away_names = soup.find_all('span', class_='clientName')

print(f'网页中共有 {len(home_names)} 场比赛\n')
print('=' * 120)
print('搜索关键词: 南锡')
print('=' * 120)

for i in range(min(len(home_names), len(away_names))):
    home_span = home_names[i]
    away_span = away_names[i]
    
    web_home = home_span.get_text(strip=True)
    web_away = away_span.get_text(strip=True)
    
    # 检查是否包含"南锡"或"阿讷西"
    if '南锡' in web_home or '阿讷西' in web_away or '阿纳西' in web_away:
        match_row = home_span.find_parent('tr')
        if not match_row:
            continue
        
        tr_id = match_row.get('id', '')
        match_id = tr_id.replace('a', '') if tr_id.startswith('a') else tr_id
        
        # 提取联赛名称
        league_td = match_row.find('td', class_='ssbox_01')
        league_name = league_td.get_text(strip=True) if league_td else ''
        
        # 提取时间
        time_td = match_row.find_all('td')[2] if len(match_row.find_all('td')) > 2 else None
        time_text = time_td.get_text(strip=True) if time_td else ''
        
        # 提取状态
        status_td = match_row.find_all('td')[3] if len(match_row.find_all('td')) > 3 else None
        status_text = status_td.get_text(strip=True) if status_td else ''
        
        # 提取全场比分
        score_td = match_row.find_all('td')[5] if len(match_row.find_all('td')) > 5 else None
        full_score = score_td.get_text(strip=True) if score_td else ''
        
        # 提取半场比分
        half_score_td = match_row.find_all('td')[7] if len(match_row.find_all('td')) > 7 else None
        half_score_text = half_score_td.get_text(strip=True) if half_score_td else ''
        
        print(f'\n找到比赛:')
        print(f'  Match ID (tr id): {tr_id}')
        print(f'  解析后 match_id: {match_id}')
        print(f'  联赛: {league_name}')
        print(f'  时间: {time_text}')
        print(f'  状态: {status_text}')
        print(f'  主队: {web_home}')
        print(f'  客队: {web_away}')
        print(f'  全场比分: "{full_score}"')
        print(f'  半场比分: "{half_score_text}"')
        
        # 打印完整的tr HTML结构
        print(f'\n  完整HTML结构:')
        tds = match_row.find_all('td')
        for idx, td in enumerate(tds):
            print(f'    td[{idx}]: {td.get_text(strip=True)[:50]}')
        
        break
else:
    print('\n❌ 未找到包含"南锡"的比赛')
