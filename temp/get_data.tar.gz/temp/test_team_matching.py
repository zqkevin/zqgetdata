# -*- coding: utf-8 -*-
"""
测试球队名称匹配优化效果
"""
import sys
sys.path.insert(0, r'E:\my_prog\zqgetdata\get_data')

from app.common._utils import handle_team_name
from app.database import localdb, Team, TeamAlias

print("=" * 80)
print("测试球队名称匹配优化")
print("=" * 80)

# 测试用例
test_cases = [
    # (队名, 来源类型, 预期结果)
    ("巴黎圣日耳曼", "tczq", "应该匹配到已有的巴黎圣日尔曼"),
    ("拜仁慕尼黑", "bjdc", "应该匹配到已有的拜仁"),
    ("AIK索尔纳", "bjdc", "应该匹配到已有的索尔纳"),
]

print("\n开始测试...\n")

for team_name, source_type, expected in test_cases:
    print(f"测试: '{team_name}' (来源:{source_type})")
    print(f"  预期: {expected}")
    
    # 调用函数
    team = handle_team_name(team_name, source_type=source_type)
    
    if team:
        print(f"  ✓ 结果: 匹配到 ID={team.id}, 全称='{team.team_full_name}'")
        
        # 检查是否添加了别名
        alias = localdb.query(TeamAlias).filter_by(
            team_id=team.id,
            alias_name=team_name,
            source_type=source_type
        ).first()
        
        if alias:
            print(f"  ✓ 别名已添加/存在")
        else:
            print(f"  ⚠ 别名未添加（可能已存在其他来源的别名）")
    else:
        print(f"  ✗ 结果: 未匹配到球队，将创建新记录")
    
    print()

print("=" * 80)
print("测试完成")
print("=" * 80)

# 清理测试数据（可选）
print("\n提示: 如果创建了新的测试球队，可以手动删除或保留用于观察")

localdb.close()
