# -*- coding: utf-8 -*-
"""对比数据库中的Match ID和完场页面中的Match ID"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, BjdcMatch
from app.common._utils import req_info
from datetime import datetime, timedelta
from bs4 import BeautifulSoup

# 获取待匹配比赛
matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.status == 0,
    BjdcMatch.match_time < datetime.now() - timedelta(hours=4)
).all()

print(f'数据库中有 {len(matches)} 场待匹配比赛\n')

# 提取所有Match ID
db_match_ids = set([str(m.match_id) for m in matches])
print(f'数据库Match IDs (前10个): {list(db_match_ids)[:10]}\n')

# 爬取2026-04-18的完场页面
url = 'https://live.500.com/wanchang.php?e=2026-04-18'
print(f'爬取: {url}\n')

soup = req_info(url)
if not soup:
    print('爬取失败！')
    sys.exit(1)

# 提取完场页面中的所有Match ID
web_match_ids = set()
rows = soup.find_all('tr', id=lambda x: x and x.startswith('a'))
for row in rows:
    match_id = row['id'].replace('a', '')
    web_match_ids.add(match_id)

print(f'完场页面有 {len(web_match_ids)} 场比赛')
print(f'完场页面Match IDs (前10个): {list(web_match_ids)[:10]}\n')

# 找出交集
common_ids = db_match_ids & web_match_ids
print('=' * 80)
print(f'匹配的Match ID数量: {len(common_ids)} / {len(db_match_ids)}')
print('=' * 80)

if common_ids:
    print('\n匹配的Match IDs:')
    for match_id in sorted(common_ids)[:10]:
        # 获取数据库中的比赛信息
        match = localdb.query(BjdcMatch).filter_by(match_id=int(match_id)).first()
        if match:
            home = match.home_team.team_full_name if match.home_team else '未知'
            away = match.away_team.team_full_name if match.away_team else '未知'
            print(f'  {match_id}: {home} vs {away}')
else:
    print('\n❌ 没有匹配的Match ID！')

# 找出数据库中但不在网页中的
missing_in_web = db_match_ids - web_match_ids
if missing_in_web:
    print(f'\n⚠️  数据库中有但网页中没有的Match ID ({len(missing_in_web)}个):')
    for mid in list(missing_in_web)[:5]:
        match = localdb.query(BjdcMatch).filter_by(match_id=int(mid)).first()
        if match:
            home = match.home_team.team_full_name if match.home_team else '未知'
            away = match.away_team.team_full_name if match.away_team else '未知'
            print(f'  {mid}: {home} vs {away}')
