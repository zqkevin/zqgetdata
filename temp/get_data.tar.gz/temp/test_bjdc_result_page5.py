# -*- coding: utf-8 -*-
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.common._utils import req_info

# 获取页面
soup = req_info('https://live.500.com/wanchang.php?e=2026-04-14')

if not soup:
    print("Failed to fetch page")
    sys.exit(1)

# 查找所有比赛行（通过 clientName）
client_names = soup.find_all('span', class_='clientName')

print("详细分析第一场比赛的 HTML 结构:\n")

if client_names:
    # 找到第一个主队
    home_name_span = client_names[0]
    match_row = home_name_span.find_parent('tr')
    
    if match_row:
        print("完整的 tr HTML:")
        print(match_row.prettify()[:2000])
        
        print("\n\n解析各个字段:")
        
        # 查找所有 td
        tds = match_row.find_all('td')
        print(f"共有 {len(tds)} 个 td")
        
        for i, td in enumerate(tds):
            text = td.get_text(strip=True)
            classes = td.get('class', [])
            print(f"\ntd[{i}] class={classes}: {text[:100]}")
            
            # 查看内部结构
            spans = td.find_all('span')
            if spans:
                for j, span in enumerate(spans):
                    span_class = span.get('class', [])
                    span_text = span.get_text(strip=True)
                    print(f"  span[{j}] class={span_class}: {span_text}")
