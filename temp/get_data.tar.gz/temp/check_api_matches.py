# -*- coding: utf-8 -*-
import requests
import json

# TCZQ赛果API
url = "https://webapi.sporttery.cn/gateway/lottery/getHistoryPageListV1.qry"

params = {
    "gameNo": "jc_zq",
    "pageNo": 1,
    "pageSize": 50
}

response = requests.get(url, params=params)
data = response.json()

if data.get('value') and data['value'].get('list'):
    matches = data['value']['list']
    
    # 查找目标比赛
    target_ids = ['2039369', '2039404']
    
    for match in matches:
        match_id = str(match.get('matchId', ''))
        if match_id in target_ids:
            print(f"\nMatch ID: {match_id}")
            print(f"  主队: {match.get('allHomeTeam')} / {match.get('homeTeam')}")
            print(f"  客队: {match.get('allAwayTeam')} / {match.get('awayTeam')}")
            print(f"  比分: {match.get('homeScore')}-{match.get('awayScore')}")
            print(f"  状态: {match.get('matchResultStatus')}")
            print(f"  完整数据: {json.dumps(match, ensure_ascii=False, indent=2)}")
