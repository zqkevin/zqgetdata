# -*- coding: utf-8 -*-
"""在网页中搜索特定比赛"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.common._utils import req_info
from bs4 import BeautifulSoup

# 爬取网页
url = 'https://live.500.com/wanchang.php?e=2026-04-17'
print(f'爬取: {url}\n')

soup = req_info(url)
if not soup:
    print('爬取失败！')
    sys.exit(1)

# 查找所有包含"墨尔本"、"加拉茨"、"吉达"的比赛
keywords = ['墨尔本', '加拉茨', '吉达', '纽卡斯尔', 'UTA', '柔佛']

home_names = soup.find_all('span', class_='mainName')
away_names = soup.find_all('span', class_='clientName')

print(f'网页中共有 {len(home_names)} 场比赛\n')
print('=' * 120)
print('搜索关键词:', ', '.join(keywords))
print('=' * 120)

found_matches = []

for i in range(min(len(home_names), len(away_names))):
    home_span = home_names[i]
    away_span = away_names[i]
    
    match_row = home_span.find_parent('tr')
    if not match_row:
        continue
    
    tr_id = match_row.get('id', '')
    match_id = tr_id.replace('a', '') if tr_id.startswith('a') else tr_id
    
    league_td = match_row.find('td', class_='ssbox_01')
    league_name = league_td.get_text(strip=True) if league_td else ''
    
    web_home = home_span.get_text(strip=True)
    web_away = away_span.get_text(strip=True)
    
    # 检查是否包含关键词
    matched_keywords = [kw for kw in keywords if kw in web_home or kw in web_away]
    
    if matched_keywords:
        found_matches.append({
            'match_id': match_id,
            'league': league_name,
            'home': web_home,
            'away': web_away,
            'keywords': matched_keywords
        })

if found_matches:
    print(f'\n找到 {len(found_matches)} 场相关比赛:\n')
    for idx, match in enumerate(found_matches):
        print(f'{idx+1}. Match ID: {match["match_id"]}')
        print(f'   联赛: {match["league"]}')
        print(f'   主队: {match["home"]}')
        print(f'   客队: {match["away"]}')
        print(f'   匹配关键词: {", ".join(match["keywords"])}')
        print()
else:
    print('\n❌ 未找到任何相关比赛')
    print('\n可能原因:')
    print('  1. 比赛还未结束，不在完场页面')
    print('  2. 队名完全不同（需要查看完整队名列表）')
    print('  3. 比赛被取消或延期')

# 显示前20场比赛供参考
print('=' * 120)
print('网页前20场比赛（供参考）:')
print('=' * 120)
for i in range(min(20, len(home_names))):
    home_span = home_names[i]
    away_span = away_names[i]
    match_row = home_span.find_parent('tr')
    if not match_row:
        continue
    tr_id = match_row.get('id', '')
    match_id = tr_id.replace('a', '') if tr_id.startswith('a') else tr_id
    league_td = match_row.find('td', class_='ssbox_01')
    league_name = league_td.get_text(strip=True) if league_td else ''
    web_home = home_span.get_text(strip=True)
    web_away = away_span.get_text(strip=True)
    print(f'{i+1:2d}. [{match_id:>10}] {league_name:15} {web_home:20} vs {web_away:20}')
