"""
对比两个页面的 script 标签
"""
from app.common._utils import req_info

# 04-26
print("="*60)
print("2026-04-26 页面")
print("="*60)
soup_26 = req_info('https://live.500.com/wanchang.php?e=2026-04-26')
scripts_26 = soup_26.find_all('script', src=True)
print(f"外部 JS 文件数量: {len(scripts_26)}")
for script in scripts_26[:5]:
    print(f"  - {script.get('src')}")

# 04-27
print("\n" + "="*60)
print("2026-04-27 页面")
print("="*60)
soup_27 = req_info('https://live.500.com/wanchang.php?e=2026-04-27')
scripts_27 = soup_27.find_all('script', src=True)
print(f"外部 JS 文件数量: {len(scripts_27)}")
for script in scripts_27[:5]:
    print(f"  - {script.get('src')}")

# 检查内联 script 中是否有数据
print("\n检查内联 script 中的数据:")
inline_scripts_26 = soup_26.find_all('script', src=False)
inline_scripts_27 = soup_27.find_all('script', src=False)

print(f"04-26 内联 script 数量: {len(inline_scripts_26)}")
print(f"04-27 内联 script 数量: {len(inline_scripts_27)}")

# 查找包含比赛数据的 script
for i, script in enumerate(inline_scripts_27):
    content = script.string or ''
    if 'a135' in content or 'match' in content.lower():
        print(f"\n04-27 第 {i} 个内联 script 可能包含数据:")
        print(content[:200])
        break
