# -*- coding: utf-8 -*-
"""
检查特定比赛的爬取结果
"""
import sys
sys.path.insert(0, 'E:\\my_prog\\zqgetdata')

from app.common._utils import req_info
from app.crawler.bjdc_result import BjdcResultCollector
from bs4 import BeautifulSoup

def check_specific_match():
    """检查大阪钢巴 vs 福冈黄蜂的比赛"""
    
    print("=" * 100)
    print("检查特定比赛：大阪钢巴 vs 福冈黄蜂")
    print("=" * 100)
    
    # 爬取2026-04-22的赛果
    date_str = '2026-04-22'
    url = f'https://live.500.com/wanchang.php?e={date_str}'
    
    print(f"\n爬取URL: {url}")
    soup = req_info(url)
    
    if not soup:
        print("爬取失败！")
        return
    
    collector = BjdcResultCollector()
    results = collector._parse_match_results_from_html(soup, date_str)
    
    print(f"\n总共爬取到 {len(results)} 场比赛\n")
    
    # 查找包含"福冈黄蜂"的比赛
    print("查找包含'福冈黄蜂'的比赛：")
    print("-" * 100)
    
    found_matches = []
    for result in results:
        if '福冈黄蜂' in result.get('awayTeam', '') or '福冈黄蜂' in result.get('homeTeam', ''):
            found_matches.append(result)
            print(f"Match ID: {result['matchId']}")
            print(f"联赛: {result['leagueName']}")
            print(f"主队: {result['homeTeam']}")
            print(f"客队: {result['awayTeam']}")
            print(f"比分: {result['homeScore']}-{result['awayScore']}")
            print(f"时间: {result['matchTime']}")
            print(f"状态: {result['status']}")
            print("-" * 100)
    
    # 查找包含"大阪"的比赛
    print("\n查找包含'大阪'的比赛：")
    print("-" * 100)
    
    for result in results:
        if '大阪' in result.get('homeTeam', '') or '大阪' in result.get('awayTeam', ''):
            print(f"Match ID: {result['matchId']}")
            print(f"联赛: {result['leagueName']}")
            print(f"主队: {result['homeTeam']}")
            print(f"客队: {result['awayTeam']}")
            print(f"比分: {result['homeScore']}-{result['awayScore']}")
            print(f"时间: {result['matchTime']}")
            print("-" * 100)
    
    # 查找数据库中的比赛
    print("\n数据库中待匹配的比赛：")
    print("-" * 100)
    
    from app.database import localdb, BjdcMatch, Team, League
    
    match = localdb.query(BjdcMatch).filter_by(match_id=1366368).first()
    if match:
        league = match.league
        home_team = match.home_team
        away_team = match.away_team
        
        print(f"数据库 Match ID: {match.match_id}")
        print(f"联赛: {league.league_name if league else 'N/A'}")
        print(f"主队: {home_team.team_full_name if home_team else 'N/A'} (ID: {match.home_team_id})")
        print(f"客队: {away_team.team_full_name if away_team else 'N/A'} (ID: {match.away_team_id})")
        print(f"比赛时间: {match.match_time}")
        
        # 检查是否有别名
        if home_team:
            from app.database import TeamAlias
            aliases = localdb.query(TeamAlias).filter_by(team_id=home_team.id).all()
            if aliases:
                print(f"主队别名:")
                for alias in aliases:
                    print(f"  - {alias.alias_name} (来源: {alias.source_type})")
        
        if away_team:
            from app.database import TeamAlias
            aliases = localdb.query(TeamAlias).filter_by(team_id=away_team.id).all()
            if aliases:
                print(f"客队别名:")
                for alias in aliases:
                    print(f"  - {alias.alias_name} (来源: {alias.source_type})")
    
    localdb.close()

if __name__ == '__main__':
    check_specific_match()
