# -*- coding: utf-8 -*-
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.database import localdb, BjdcMatch

matches = localdb.query(BjdcMatch).filter_by(status=0).all()

print('待匹配比赛的备注:')
for m in matches[:10]:
    home = m.home_team.team_full_name if m.home_team else "?"
    away = m.away_team.team_full_name if m.away_team else "?"
    print(f'{m.match_id}: {home} vs {away}')
    print(f'  Remark: {m.remark}')
    print()
