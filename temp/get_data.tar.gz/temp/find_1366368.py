# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, 'E:\\my_prog\\zqgetdata')

from app.common._utils import req_info
from app.crawler.bjdc_result import BjdcResultCollector

soup = req_info('https://live.500.com/wanchang.php?e=2026-04-22')
collector = BjdcResultCollector()
results = collector._parse_match_results_from_html(soup, '2026-04-22')

match_1366368 = [r for r in results if str(r['matchId']) == '1366368']
print(f'在2026-04-22页面找到{len(match_1366368)}条')
for m in match_1366368:
    print(f"ID:{m['matchId']}, {m['homeTeam']} vs {m['awayTeam']}, {m['homeScore']}-{m['awayScore']}")
