"""
检查 BJDC ID 匹配问题
"""
from app.database import BjdcMatch, localdb
from sqlalchemy import func
from datetime import datetime, timedelta

# 查询需要获取赛果的比赛
cutoff_time = datetime.now() - timedelta(hours=4)
pending_matches = localdb.query(BjdcMatch).filter(
    BjdcMatch.match_time < cutoff_time,
    BjdcMatch.status < 3
).all()

print(f"待匹配比赛: {len(pending_matches)} 场\n")

# 按页面日期分组
pending_by_date = {}
for match in pending_matches:
    if match.match_time:
        utc_time = match.match_time - timedelta(hours=8)
        if utc_time.hour < 10:
            page_date = (utc_time.date() - timedelta(days=1)).strftime('%Y-%m-%d')
        else:
            page_date = utc_time.date().strftime('%Y-%m-%d')
    else:
        page_date = ''
    
    if page_date not in pending_by_date:
        pending_by_date[page_date] = []
    
    pending_by_date[page_date].append(match)

# 显示每个日期的前5个 match_id
for page_date in sorted(pending_by_date.keys()):
    matches = pending_by_date[page_date]
    print(f"\n{page_date}: {len(matches)} 场")
    print("  前5个 match_id (整数):")
    for match in matches[:5]:
        home_name = match.home_team.team_full_name if match.home_team else '未知'
        away_name = match.away_team.team_full_name if match.away_team else '未知'
        print(f"    {match.match_id} ({type(match.match_id).__name__}): {home_name} vs {away_name}")
        print(f"      转换为字符串: '{str(match.match_id)}'")

localdb.close()
