# -*- coding: utf-8 -*-
"""添加BJDC和完场页面的队名别名映射"""
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, Team, TeamAlias

# 队名映射关系：{完场页面队名: 数据库队名}
team_name_mapping = {
    # 罗甲
    '阿拉德联合': 'UTA阿拉德',
    
    # 波兰甲
    '卡杜华斯': '卡托维兹',
    '摩托鲁宾': '卢布林莫托',
    
    # 奥乙
    '维也纳迅速B队': '维也纳快速二队',
    '弗洛里茨多夫': 'FAC维也纳',
    '阿姆斯特顿': '阿姆施泰滕',
    '卡芬堡': '卡普芬贝格',
    '布雷根茨': '黑白布雷根茨',
    
    # 丹甲
    '靴尔科治': 'HB克厄',
}

print('开始添加队名别名...\n')

added_count = 0
for web_name, db_name in team_name_mapping.items():
    # 查找数据库中的球队
    team = localdb.query(Team).filter(
        (Team.team_full_name == db_name) | 
        (Team.team_short_name == db_name)
    ).first()
    
    if not team:
        print(f'⚠️  未找到球队: {db_name}')
        continue
    
    # 检查是否已存在该别名
    existing_alias = localdb.query(TeamAlias).filter_by(
        team_id=team.id,
        alias_name=web_name,
        source_type='bjdc_result'  # 标记为完场页面的别名
    ).first()
    
    if existing_alias:
        print(f'✓ 别名已存在: {web_name} -> {db_name}')
        continue
    
    # 创建新别名
    new_alias = TeamAlias(
        team_id=team.id,
        alias_name=web_name,
        source_type='bjdc_result',
        is_primary=0
    )
    localdb.add(new_alias, close=False)
    added_count += 1
    print(f'✅ 添加别名: {web_name} -> {db_name}')

localdb.session.commit()
print(f'\n共添加 {added_count} 个别名')
