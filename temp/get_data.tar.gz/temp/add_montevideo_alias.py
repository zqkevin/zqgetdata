# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, '.')
from app.database import localdb, Team, TeamAlias

team = localdb.query(Team).filter_by(team_full_name='蒙得维的亚城力矩').first()
if team:
    print(f'找到球队: {team.team_full_name}')
    alias = TeamAlias(team_id=team.id, alias_name='蒙得维的亚国民', source_type='bjdc')
    localdb.add(alias, close=False)
    localdb.session.commit()
    print('已添加别名: 蒙得维的亚国民')
else:
    print('未找到球队')
