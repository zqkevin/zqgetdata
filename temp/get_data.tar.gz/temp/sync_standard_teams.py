"""
获取并保存标准球队信息到数据库
从 football-data.org API 获取标准化的球队、联赛、国家数据
"""
import requests
import json
from datetime import datetime
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.database.init_db import SessionLocal
from app.database.server_models.team import Team, League, Country
from sqlalchemy.exc import IntegrityError

# API配置
API_TOKEN = "b95b11f44dde401bb5f8de79364f59c6"
BASE_URL = "https://api.football-data.org/v4"
HEADERS = {
    "X-Auth-Token": API_TOKEN
}

def get_all_competitions():
    """获取所有可用竞赛"""
    print("获取所有竞赛...")
    response = requests.get(f"{BASE_URL}/competitions", headers=HEADERS)
    if response.status_code == 200:
        data = response.json()
        return data.get('competitions', [])
    else:
        print(f"获取竞赛失败: {response.status_code}")
        return []

def get_teams_by_competition(comp_code):
    """获取指定竞赛的所有球队"""
    print(f"获取 {comp_code} 的球队...")
    response = requests.get(f"{BASE_URL}/competitions/{comp_code}/teams", headers=HEADERS)
    if response.status_code == 200:
        data = response.json()
        return data.get('teams', [])
    else:
        print(f"获取球队失败: {response.status_code}")
        return []

def save_country(session, area_data):
    """保存国家/区域信息"""
    country = session.query(Country).filter_by(area_id=area_data['id']).first()
    
    if not country:
        country = Country(
            area_id=area_data['id'],
            name=area_data.get('name'),
            code=area_data.get('code'),
            flag=area_data.get('flag')
        )
        session.add(country)
        print(f"  新增国家: {area_data.get('name')}")
    else:
        # 更新信息
        country.name = area_data.get('name')
        country.code = area_data.get('code')
        country.flag = area_data.get('flag')
    
    return country

def save_league(session, comp_data, country_id):
    """保存联赛信息"""
    league = session.query(League).filter_by(competition_id=comp_data['id']).first()
    
    if not league:
        league = League(
            competition_id=comp_data['id'],
            name=comp_data.get('name'),
            code=comp_data.get('code'),
            type=comp_data.get('type'),
            emblem=comp_data.get('emblem'),
            country_id=country_id,
            current_season=json.dumps(comp_data.get('currentSeason', {}))
        )
        session.add(league)
        print(f"  新增联赛: {comp_data.get('name')}")
    else:
        # 更新信息
        league.name = comp_data.get('name')
        league.code = comp_data.get('code')
        league.type = comp_data.get('type')
        league.emblem = comp_data.get('emblem')
        league.country_id = country_id
    
    return league

def save_team(session, team_data, league_id, country_id):
    """保存球队信息"""
    team = session.query(Team).filter_by(team_id=team_data['id']).first()
    
    if not team:
        team = Team(
            team_id=team_data['id'],
            name=team_data.get('name'),
            short_name=team_data.get('shortName'),
            tla=team_data.get('tla'),  # 三字缩写
            crest=team_data.get('crest'),  # 队徽URL
            founded=team_data.get('founded'),
            venue=team_data.get('venue'),
            website=team_data.get('website'),
            club_colors=team_data.get('clubColors'),
            league_id=league_id,
            country_id=country_id,
            squad=json.dumps(team_data.get('squad', [])),  # 球员阵容
            coach=json.dumps(team_data.get('coach', {})),  # 教练信息
            last_updated=datetime.fromisoformat(team_data.get('lastUpdated').replace('Z', '+00:00')) if team_data.get('lastUpdated') else None
        )
        session.add(team)
        print(f"    新增球队: {team_data.get('name')}")
    else:
        # 更新信息
        team.name = team_data.get('name')
        team.short_name = team_data.get('shortName')
        team.tla = team_data.get('tla')
        team.crest = team_data.get('crest')
        team.founded = team_data.get('founded')
        team.venue = team_data.get('venue')
        team.website = team_data.get('website')
        team.club_colors = team_data.get('clubColors')
        team.league_id = league_id
        team.country_id = country_id
        team.squad = json.dumps(team_data.get('squad', []))
        team.coach = json.dumps(team_data.get('coach', {}))
        team.last_updated = datetime.fromisoformat(team_data.get('lastUpdated').replace('Z', '+00:00')) if team_data.get('lastUpdated') else None
    
    return team

def main():
    print("="*60)
    print("开始从 football-data.org 获取标准球队信息")
    print("="*60)
    
    session = SessionLocal()
    
    try:
        # 1. 获取所有竞赛
        competitions = get_all_competitions()
        print(f"\n找到 {len(competitions)} 个竞赛\n")
        
        total_teams = 0
        
        # 2. 遍历每个竞赛
        for comp in competitions:
            print(f"\n处理竞赛: {comp.get('name')} ({comp.get('code')})")
            
            # 保存国家信息
            area = comp.get('area', {})
            if area:
                country = save_country(session, area)
                session.commit()
            else:
                continue
            
            # 保存联赛信息
            league = save_league(session, comp, country.id)
            session.commit()
            
            # 获取该联赛的所有球队
            teams = get_teams_by_competition(comp.get('code'))
            print(f"  找到 {len(teams)} 支球队")
            
            # 保存每支球队
            for team_data in teams:
                # 球队的国家信息（可能与联赛国家不同）
                team_area = team_data.get('area', {})
                if team_area:
                    team_country = save_country(session, team_area)
                    session.commit()
                    team_country_id = team_country.id
                else:
                    team_country_id = country.id
                
                save_team(session, team_data, league.id, team_country_id)
                total_teams += 1
            
            session.commit()
            print(f"  ✓ 完成")
        
        print("\n" + "="*60)
        print(f"同步完成！")
        print(f"总共处理: {len(competitions)} 个联赛, {total_teams} 支球队")
        print("="*60)
        
    except Exception as e:
        print(f"\n错误: {str(e)}")
        import traceback
        traceback.print_exc()
        session.rollback()
    finally:
        session.close()

if __name__ == "__main__":
    main()
