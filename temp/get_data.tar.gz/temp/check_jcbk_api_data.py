# -*- coding: utf-8 -*-
"""检查JCBK API返回的赛果数据结构"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.common.req_sporttery_api import SportteryAPI
from datetime import datetime, timedelta
import json

api = SportteryAPI()

# 获取昨天的日期范围
yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
today = datetime.now().strftime('%Y-%m-%d')

print(f"查询日期范围: {yesterday} 到 {today}")
print("=" * 80)

results = api.get_basketball_match_results(
    match_begin_date=yesterday,
    match_end_date=today
)

if not results:
    print("API未返回任何数据")
else:
    print(f"API返回 {len(results)} 条赛果\n")
    
    # 按status分组
    status_groups = {}
    for result in results:
        status = result.get('status')
        if status not in status_groups:
            status_groups[status] = []
        status_groups[status].append(result)
    
    for status in sorted(status_groups.keys()):
        matches = status_groups[status]
        print(f"\nstatus={status}: {len(matches)} 场")
        
        # 显示前3场的详细信息
        for i, m in enumerate(matches[:3], 1):
            print(f"  {i}. {m.get('homeTeam')} vs {m.get('awayTeam')}")
            print(f"     homeScore={repr(m.get('homeScore'))}, awayScore={repr(m.get('awayScore'))}")
            print(f"     matchResultStatus={repr(m.get('matchResultStatus'))}")
            print(f"     resultStatus={repr(m.get('resultStatus'))}")
            print(f"     poolStatus={repr(m.get('poolStatus'))}")
        
        if len(matches) > 3:
            print(f"  ... 还有 {len(matches) - 3} 场")
    
    # 保存完整数据
    output_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'temp', 'jcbk_api_raw_data.json')
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n完整数据已保存到: {output_file}")
