# -*- coding: utf-8 -*-
"""
调试 BJDC 赛果匹配问题
"""
import sys
import os
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.crawler.bjdc_result import BjdcResultCollector
from app.database import localdb, BjdcMatch

print("=" * 80)
print("调试 BJDC 赛果匹配")
print("=" * 80)

c = BjdcResultCollector()

# 1. 获取赛果和待匹配列表
print("\n1. 获取数据...")
results, pending_matches = c.fetch_match_results()

print(f"   爬取到 {len(results)} 条赛果")
print(f"   待匹配 {len(pending_matches)} 场比赛")

# 2. 查看待匹配比赛的队名
if pending_matches:
    print(f"\n2. 待匹配比赛示例（前3场）:")
    for i, match in enumerate(pending_matches[:3], 1):
        home_name = match.home_team.team_full_name if match.home_team else '未知'
        away_name = match.away_team.team_full_name if match.away_team else '未知'
        match_date = match.match_time.strftime('%Y-%m-%d') if match.match_time else '未知'
        print(f"   {i}. {match_date} | {home_name} vs {away_name}")

# 3. 查看爬取的赛果队名
if results:
    print(f"\n3. 爬取赛果示例（前3场）:")
    for i, r in enumerate(results[:3], 1):
        print(f"   {i}. {r['matchDate']} | {r['homeTeam']} vs {r['awayTeam']}: {r['homeScore']}-{r['awayScore']}")

# 4. 尝试手动匹配一场
if pending_matches and results:
    print(f"\n4. 测试匹配第一场比赛...")
    
    first_match = pending_matches[0]
    db_home = first_match.home_team.team_full_name if first_match.home_team else ''
    db_away = first_match.away_team.team_full_name if first_match.away_team else ''
    db_date = first_match.match_time.strftime('%Y-%m-%d') if first_match.match_time else ''
    
    print(f"   数据库比赛: {db_date} | {db_home} vs {db_away}")
    
    # 在爬取的赛果中查找相同日期的
    same_date_results = [r for r in results if r['matchDate'] == db_date]
    print(f"   同日期赛果: {len(same_date_results)} 场")
    
    if same_date_results:
        print(f"   同日期赛果示例（前5场）:")
        for i, r in enumerate(same_date_results[:5], 1):
            api_home = r['homeTeam']
            api_away = r['awayTeam']
            
            # 测试模糊匹配
            home_similar = c._is_team_name_similar(db_home, api_home)
            away_similar = c._is_team_name_similar(db_away, api_away)
            
            match_str = "MATCH" if (home_similar and away_similar) else "NO"
            print(f"      {i}. {api_home} vs {api_away} - H:{home_similar}, A:{away_similar} [{match_str}]")

print("\n" + "=" * 80)
