# -*- coding: utf-8 -*-
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import localdb, BjdcMatch

match = localdb.query(BjdcMatch).filter_by(match_id=1402349).first()
if match:
    home = match.home_team.team_full_name if match.home_team else '未知'
    away = match.away_team.team_full_name if match.away_team else '未知'
    print(f'Match ID: {match.match_id}')
    print(f'主队: {home}')
    print(f'客队: {away}')
    print(f'比赛时间: {match.match_time}')
    print(f'期数: {match.issue}')
    print(f'场次: {match.match_num_str}')
else:
    print('未找到该比赛')
