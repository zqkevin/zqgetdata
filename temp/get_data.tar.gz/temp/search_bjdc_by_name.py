# -*- coding: utf-8 -*-
"""
通过队名搜索BJDC比赛赛果
"""
import sys
import os
from datetime import timedelta

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from app.crawler.bjdc_result import BjdcResultCollector
from bs4 import BeautifulSoup
from app.common._utils import req_info

def search_by_team_name():
    """通过队名搜索赛果"""
    print("=" * 80)
    print("通过队名搜索BJDC比赛赛果")
    print("=" * 80)
    
    collector = BjdcResultCollector()
    
    # 要搜索的比赛
    matches = [
        {'date': '2026-04-28', 'home': '圣吉罗斯联合', 'away': '哈德斯菲尔德'},
        {'date': '2026-04-28', 'home': '布鲁日', 'away': '比尔森胜利'},
        {'date': '2026-04-28', 'home': '普埃布拉', 'away': '帕尔杜比采'},
        {'date': '2026-04-28', 'home': '瓦路尔', 'away': '莱比锡红牛'},
        {'date': '2026-04-29', 'home': '博塔弗戈SP', 'away': '戈亚尼亚竞技'},
    ]
    
    for match in matches:
        date_str = match['date']
        home_team = match['home']
        away_team = match['away']
        
        print(f"\n搜索: {home_team} vs {away_team} ({date_str})")
        
        try:
            url = f'https://live.500.com/wanchang.php?e={date_str}'
            soup = req_info(url)
            
            if soup:
                results = collector._parse_match_results_from_html(soup, date_str)
                
                # 通过队名查找
                found = False
                for result in results:
                    api_home = result.get('homeTeam', '')
                    api_away = result.get('awayTeam', '')
                    
                    # 模糊匹配
                    if (home_team in api_home or api_home in home_team) and \
                       (away_team in api_away or api_away in away_team):
                        print(f"  [OK] 找到匹配:")
                        print(f"    主队: {api_home}")
                        print(f"    客队: {api_away}")
                        print(f"    比分: {result.get('homeScore')} - {result.get('awayScore')}")
                        print(f"    match_id: {result.get('matchId')}")
                        found = True
                        break
                
                if not found:
                    print(f"  [FAIL] 未找到匹配的比赛")
            else:
                print(f"  [FAIL] 网页请求失败")
        except Exception as e:
            print(f"  [ERROR] 搜索失败: {e}")

if __name__ == '__main__':
    search_by_team_name()
