# -*- coding: utf-8 -*-
"""
测试 BJDC 赛果的别名匹配功能
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__))))

from app.database import localdb, Team, TeamAlias

def test_alias_matching():
    """测试别名匹配"""
    
    print("=" * 80)
    print("测试 BJDC-TCZQ 别名匹配")
    print("=" * 80)
    
    # 测试用例：API 返回的队名 -> 应该匹配到的数据库球队
    test_cases = [
        ("朴次茅斯", "朴茨茅斯"),
        ("南安普敦", "南安普顿"),
        ("巴黎圣日尔曼", "巴黎圣日耳曼"),
        ("葡萄牙体育", "里斯本竞技"),
        ("利勒斯特罗姆", "利勒斯特伦"),
    ]
    
    for api_name, expected_bjdc_name in test_cases:
        print(f"\n测试: API='{api_name}' -> 期望BJDC='{expected_bjdc_name}'")
        
        # 1. 查找 API 队名对应的球队（通过别名）
        alias = localdb.query(TeamAlias).filter(
            TeamAlias.alias_name == api_name
        ).first()
        
        if alias:
            team = localdb.query(Team).filter_by(id=alias.team_id).first()
            if team:
                print(f"  [OK] 通过别名找到: {team.team_full_name} (ID:{team.id})")
                
                # 2. 检查这个球队是否是期望的 BJDC 球队
                bjdc_team = localdb.query(Team).filter(
                    (Team.team_full_name == expected_bjdc_name) | 
                    (Team.team_short_name == expected_bjdc_name)
                ).first()
                
                if bjdc_team:
                    if team.id == bjdc_team.id:
                        print(f"  [MATCH] 正确匹配到 BJDC 球队 ID:{bjdc_team.id}")
                    else:
                        print(f"  [MISMATCH] 匹配到错误的球队!")
                        print(f"           期望 ID:{bjdc_team.id}, 实际 ID:{team.id}")
                else:
                    print(f"  [WARN] 未找到期望的 BJDC 球队: {expected_bjdc_name}")
            else:
                print(f"  [ERROR] 别名存在但找不到球队 (team_id={alias.team_id})")
        else:
            print(f"  [FAIL] 未找到别名: {api_name}")
            
            # 尝试模糊查找
            fuzzy_aliases = localdb.query(TeamAlias).filter(
                TeamAlias.alias_name.like(f'%{api_name[:2]}%')
            ).all()
            
            if fuzzy_aliases:
                print(f"  [HINT] 找到相似别名:")
                for fa in fuzzy_aliases[:3]:
                    t = localdb.query(Team).filter_by(id=fa.team_id).first()
                    if t:
                        print(f"         - {fa.alias_name} -> {t.team_full_name}")
    
    print("\n" + "=" * 80)

if __name__ == '__main__':
    try:
        test_alias_matching()
    except Exception as e:
        print(f"\n[ERROR] 测试失败: {e}")
        import traceback
        traceback.print_exc()
