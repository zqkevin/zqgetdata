import json

data = json.load(open('temp/tczq_api_raw_data.json', encoding='utf-8'))

print("所有字段名:")
print(list(data[0].keys()))

print("\n前5场比赛的时间相关字段:")
for m in data[:5]:
    print(f"matchId={m['matchId']}: matchDate={m.get('matchDate')}, matchTime={m.get('matchTime')}")

print("\n检查 matchResultStatus='1' 的比赛是否有 matchTime:")
status_1_matches = [m for m in data if m.get('matchResultStatus') == '1']
for m in status_1_matches[:5]:
    print(f"  matchId={m['matchId']}, date={m.get('matchDate')}, time={m.get('matchTime')}, homeTeam={m.get('homeTeam')}")

print("\n检查 matchResultStatus='2' 的比赛是否有 matchTime:")
status_2_matches = [m for m in data if m.get('matchResultStatus') == '2']
for m in status_2_matches[:5]:
    print(f"  matchId={m['matchId']}, date={m.get('matchDate')}, time={m.get('matchTime')}, homeTeam={m.get('homeTeam')}, score={m.get('homeScore')}-{m.get('awayScore')}")
